import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"
import { 
  Upload, 
  Brain, 
  FileText, 
  GitBranch,
  Search,
  Layers,
  Shield,
  BarChart3,
  Users
} from "lucide-react"

const features = [
  {
    icon: Upload,
    title: "Ingestion & Detection",
    description: "Accept GitHub repo URL, ZIP upload, or deployed URL. Automatically detect frameworks, hosting platforms, APIs, and dependencies across your entire stack.",
    highlight: "Instant Setup"
  },
  {
    icon: Brain,
    title: "AI-Driven Analysis",
    description: "Static + semantic code parsing with GPT-5. Automatically identify architecture type, evaluate scalability, and detect potential technical debt.",
    highlight: "AI-Powered"
  },
  {
    icon: FileText,
    title: "Human-Readable Reports",
    description: "Generate technical reports with architecture diagrams and executive summaries in plain English. Export as PDF, HTML, or Notion-compatible markdown.",
    highlight: "Most Popular"
  },
  {
    icon: GitBranch,
    title: "Monitoring & Change Tracking",
    description: "Scheduled re-analysis, version comparison, and architecture drift detection. Alert system for code or dependency changes.",
    highlight: "Pro Feature"
  },
  {
    icon: Search,
    title: "Codebase Intelligence",
    description: "Deep analysis of business logic, data flows, and system dependencies. Understand how every component fits together.",
    highlight: ""
  },
  {
    icon: Layers,
    title: "Architecture Mapping",
    description: "Visual architecture diagrams showing monolith, microservices, serverless, or hybrid patterns. See the big picture instantly.",
    highlight: ""
  },
  {
    icon: Shield,
    title: "Security Assessment",
    description: "Comprehensive security vulnerability assessment and risk analysis. Identify potential security issues before they become problems.",
    highlight: ""
  },
  {
    icon: BarChart3,
    title: "Performance Intelligence",
    description: "Scalability analysis and performance bottleneck identification. Get actionable recommendations for optimization.",
    highlight: ""
  },
  {
    icon: Users,
    title: "Team Knowledge Transfer",
    description: "Accelerate onboarding with interactive system walkthroughs, code explanations, and workflow documentation.",
    highlight: ""
  }
]

export function Features() {
  return (
    <section id="features" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <Badge variant="secondary" className="w-fit mx-auto">Features</Badge>
          <h2 className="text-3xl lg:text-5xl">
            Complete SaaS architecture 
            <br />analysis suite
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Everything you need for technical due diligence, acquisition analysis, and system understanding. Replace $25K+ enterprise tools with instant, automated insights.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="relative hover:shadow-lg transition-shadow">
              {feature.highlight && (
                <Badge 
                  variant={feature.highlight === "Most Popular" ? "default" : "secondary"} 
                  className="absolute -top-2 left-4 z-10"
                >
                  {feature.highlight}
                </Badge>
              )}
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <feature.icon className="h-5 w-5 text-primary" />
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <p className="text-muted-foreground mb-6">
            Trusted by SaaS founders, investors, and acquisition teams
          </p>
          <div className="flex justify-center items-center space-x-8 opacity-60">
            <div className="text-lg font-semibold">Sequoia Capital</div>
            <div className="text-lg font-semibold">Andreessen Horowitz</div>
            <div className="text-lg font-semibold">First Round</div>
            <div className="text-lg font-semibold">Bessemer</div>
            <div className="text-lg font-semibold">General Catalyst</div>
          </div>
        </div>
      </div>
    </section>
  )
}