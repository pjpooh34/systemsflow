import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { ArrowRight, CheckCircle, Play, BarChart3, Shield, Zap } from "lucide-react"

interface HeroProps {
  onStartDemo?: () => void
}

export function Hero({ onStartDemo }: HeroProps) {
  return (
    <section className="relative overflow-hidden py-20 lg:py-32">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-2">
              <Badge variant="secondary" className="w-fit">
                🚀 Automated SaaS architecture analysis platform
              </Badge>
              <h1 className="text-4xl lg:text-6xl tracking-tight">
                Understand any SaaS
                <span className="text-primary"> in minutes — not months</span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-lg">
                Upload your codebase and get instant, AI-generated architecture analysis. Built for SaaS founders, buyers, and investors who need deep understanding fast.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="group" onClick={onStartDemo}>
                Start Free Analysis
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button size="lg" variant="outline" className="group" onClick={onStartDemo}>
                <Play className="mr-2 h-4 w-4" />
                View Sample Report
              </Button>
            </div>

            <div className="space-y-3">
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Analysis complete in under 5 minutes</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>90% cheaper than $25K+ enterprise tools</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Trusted by SaaS founders & investors worldwide</span>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="bg-gradient-to-br from-primary/5 to-purple-500/5 rounded-2xl p-8 border">
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="bg-card rounded-lg p-4 border shadow-sm">
                  <BarChart3 className="h-8 w-8 text-primary mb-2" />
                  <div className="text-sm font-medium">Architecture</div>
                  <div className="text-xs text-muted-foreground">312 components</div>
                </div>
                <div className="bg-card rounded-lg p-4 border shadow-sm">
                  <Shield className="h-8 w-8 text-green-600 mb-2" />
                  <div className="text-sm font-medium">Security</div>
                  <div className="text-xs text-muted-foreground">47 checks</div>
                </div>
                <div className="bg-card rounded-lg p-4 border shadow-sm">
                  <Zap className="h-8 w-8 text-yellow-600 mb-2" />
                  <div className="text-sm font-medium">Performance</div>
                  <div className="text-xs text-muted-foreground">8.2/10 score</div>
                </div>
              </div>
              
              <div className="bg-card rounded-lg p-4 border shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Analysis Progress</span>
                  <span className="text-sm text-muted-foreground">100%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div className="bg-primary h-2 rounded-full w-full"></div>
                </div>
                <div className="flex items-center mt-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                  <span className="text-xs text-muted-foreground">Report ready for export</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}