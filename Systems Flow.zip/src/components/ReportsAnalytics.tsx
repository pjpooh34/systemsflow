import { useState, useEffect } from 'react'
import { Button } from './ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Badge } from './ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { Checkbox } from './ui/checkbox'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, LineChart, Line } from 'recharts'
import { FileText, Download, TrendingUp, GitCompare, History, Share, ArrowLeft } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { analysisService, Project, Analysis } from '../services/analysisService'
import { toast } from 'sonner@2.0.3'

interface ReportsAnalyticsProps {
  onBack: () => void
}

export function ReportsAnalytics({ onBack }: ReportsAnalyticsProps) {
  const { user, token } = useAuth()
  const [projects, setProjects] = useState<Project[]>([])
  const [selectedProjects, setSelectedProjects] = useState<string[]>([])
  const [analyses, setAnalyses] = useState<Analysis[]>([])
  const [loading, setLoading] = useState(true)
  const [reportLoading, setReportLoading] = useState(false)
  const [comparison, setComparison] = useState<any>(null)
  const [selectedView, setSelectedView] = useState<'individual' | 'comparison' | 'trends'>('individual')

  useEffect(() => {
    if (token) {
      loadProjects()
    }
  }, [token])

  const loadProjects = async () => {
    try {
      const response = await analysisService.getProjects(token!)
      setProjects(response.projects)
      if (response.projects.length > 0) {
        setSelectedProjects([response.projects[0].id])
        loadProjectAnalyses(response.projects[0].id)
      }
    } catch (error) {
      console.error('Error loading projects:', error)
      toast.error('Failed to load projects')
    } finally {
      setLoading(false)
    }
  }

  const loadProjectAnalyses = async (projectId: string) => {
    try {
      const response = await analysisService.getProjectAnalyses(token!, projectId)
      setAnalyses(response.analyses)
    } catch (error) {
      console.error('Error loading analyses:', error)
      toast.error('Failed to load analyses')
    }
  }

  const generateReport = async (format: 'pdf' | 'json' | 'csv') => {
    if (selectedProjects.length === 0) {
      toast.error('Please select at least one project')
      return
    }

    setReportLoading(true)
    try {
      const response = await analysisService.generateReport(token!, selectedProjects[0], format)
      toast.success(`Report generated successfully! ${response.reportUrl}`)
      // In a real app, you would download the file or open it
    } catch (error) {
      console.error('Error generating report:', error)
      toast.error('Failed to generate report')
    } finally {
      setReportLoading(false)
    }
  }

  const compareProjects = async () => {
    if (selectedProjects.length < 2) {
      toast.error('Please select at least 2 projects for comparison')
      return
    }

    try {
      const response = await analysisService.compareProjects(token!, selectedProjects)
      setComparison(response.comparison)
      setSelectedView('comparison')
      toast.success('Project comparison generated')
    } catch (error) {
      console.error('Error comparing projects:', error)
      toast.error('Failed to compare projects')
    }
  }

  const getScoreData = () => {
    return analyses.map(analysis => ({
      type: analysis.type.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase()),
      score: analysis.analysis.score || analysis.analysis.securityScore || analysis.analysis.performanceScore || 0,
      status: analysis.status
    }))
  }

  const getRadarData = () => {
    const analysisTypes = ['codebase', 'architecture', 'security', 'performance', 'technical-debt']
    return analysisTypes.map(type => {
      const analysis = analyses.find(a => a.type === type)
      const score = analysis?.analysis?.score || analysis?.analysis?.securityScore || analysis?.analysis?.performanceScore || 0
      return {
        subject: type.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase()),
        score,
        fullMark: 10
      }
    })
  }

  const getTrendData = () => {
    // Mock trend data - in a real app this would come from historical analyses
    return [
      { date: '2024-01', security: 6, performance: 7, architecture: 8 },
      { date: '2024-02', security: 7, performance: 7.5, architecture: 8.2 },
      { date: '2024-03', security: 8, performance: 8, architecture: 8.5 },
      { date: '2024-04', security: 8.5, performance: 8.2, architecture: 9 },
    ]
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading reports and analytics...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" onClick={onBack} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
          <div>
            <h1 className="text-3xl font-bold">Reports & Analytics</h1>
            <p className="text-muted-foreground">Generate comprehensive reports and compare project analyses</p>
          </div>
        </div>

        <div className="grid gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Report Generation
              </CardTitle>
              <CardDescription>
                Generate comprehensive reports from your project analyses
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Select Project</label>
                  <Select
                    value={selectedProjects[0] || ''}
                    onValueChange={(value) => {
                      setSelectedProjects([value])
                      loadProjectAnalyses(value)
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a project" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map((project) => (
                        <SelectItem key={project.id} value={project.id}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Export Format</label>
                  <div className="flex gap-2">
                    <Button 
                      onClick={() => generateReport('json')} 
                      disabled={reportLoading || selectedProjects.length === 0}
                      variant="outline"
                      className="flex items-center gap-2"
                    >
                      <Download className="h-4 w-4" />
                      JSON
                    </Button>
                    <Button 
                      onClick={() => generateReport('csv')} 
                      disabled={reportLoading || selectedProjects.length === 0}
                      variant="outline"
                      className="flex items-center gap-2"
                    >
                      <Download className="h-4 w-4" />
                      CSV
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GitCompare className="h-5 w-5" />
                Project Comparison
              </CardTitle>
              <CardDescription>
                Compare multiple projects side by side
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Select Projects to Compare</label>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                  {projects.map((project) => (
                    <div key={project.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={project.id}
                        checked={selectedProjects.includes(project.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedProjects([...selectedProjects, project.id])
                          } else {
                            setSelectedProjects(selectedProjects.filter(id => id !== project.id))
                          }
                        }}
                      />
                      <label htmlFor={project.id} className="text-sm font-medium">
                        {project.name}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              <Button 
                onClick={compareProjects}
                disabled={selectedProjects.length < 2}
                className="flex items-center gap-2"
              >
                <GitCompare className="h-4 w-4" />
                Compare Projects
              </Button>
            </CardContent>
          </Card>
        </div>

        <Tabs value={selectedView} onValueChange={(value) => setSelectedView(value as any)} className="space-y-6">
          <TabsList>
            <TabsTrigger value="individual" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Individual Analysis
            </TabsTrigger>
            <TabsTrigger value="comparison" className="flex items-center gap-2">
              <GitCompare className="h-4 w-4" />
              Project Comparison
            </TabsTrigger>
            <TabsTrigger value="trends" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              Trends
            </TabsTrigger>
          </TabsList>

          <TabsContent value="individual" className="space-y-6">
            {analyses.length > 0 ? (
              <div className="grid gap-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Analysis Scores</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={getScoreData()}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="type" />
                          <YAxis domain={[0, 10]} />
                          <Tooltip />
                          <Bar dataKey="score" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Radar Analysis</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <RadarChart data={getRadarData()}>
                          <PolarGrid />
                          <PolarAngleAxis dataKey="subject" />
                          <PolarRadiusAxis domain={[0, 10]} />
                          <Radar
                            name="Score"
                            dataKey="score"
                            stroke="#8884d8"
                            fill="#8884d8"
                            fillOpacity={0.3}
                          />
                        </RadarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Analysis Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4">
                      {analyses.map((analysis) => (
                        <div key={analysis.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center gap-4">
                            <Badge variant="outline">
                              {analysis.type.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </Badge>
                            <span className="text-sm text-muted-foreground">
                              {new Date(analysis.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={analysis.status === 'completed' ? 'default' : 'secondary'}>
                              {analysis.status}
                            </Badge>
                            <span className="font-medium">
                              Score: {analysis.analysis.score || analysis.analysis.securityScore || analysis.analysis.performanceScore || 'N/A'}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-8">
                  <p className="text-muted-foreground">No analyses found for the selected project</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="comparison" className="space-y-6">
            {comparison ? (
              <div className="grid gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Score Comparison</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {Object.entries(comparison.scoreComparison).map(([analysisType, scores]: [string, any[]]) => (
                        <div key={analysisType}>
                          <h4 className="font-medium mb-2 capitalize">{analysisType.replace('-', ' ')}</h4>
                          <div className="grid gap-2">
                            {scores.map((score, index) => (
                              <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                                <span>{score.projectName}</span>
                                <Badge variant="outline">{score.score}/10</Badge>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-8">
                  <p className="text-muted-foreground">No comparison data available. Select projects and click "Compare Projects" to generate a comparison.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="trends" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Trends Over Time</CardTitle>
                <CardDescription>Track how your project scores evolve</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={getTrendData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis domain={[0, 10]} />
                    <Tooltip />
                    <Line type="monotone" dataKey="security" stroke="#8884d8" strokeWidth={2} />
                    <Line type="monotone" dataKey="performance" stroke="#82ca9d" strokeWidth={2} />
                    <Line type="monotone" dataKey="architecture" stroke="#ffc658" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}