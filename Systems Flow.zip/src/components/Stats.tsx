import { Card, CardContent } from "./ui/card"

const stats = [
  {
    number: "<5min",
    label: "Average analysis time",
    description: "Complete technical due diligence faster than any manual process or enterprise tool"
  },
  {
    number: "90%+",
    label: "Accuracy satisfaction",
    description: "AI-generated reports consistently meet or exceed manual consultant analysis quality"
  },
  {
    number: "90%",
    label: "Cost savings vs alternatives",
    description: "Replace $25K+ enterprise tools and $3K-$5K consultant reports with instant analysis"
  },
  {
    number: "500+",
    label: "SaaS companies analyzed",
    description: "From early-stage startups to enterprise platforms across all industries and tech stacks"
  }
]

export function Stats() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-5xl">
            Instant SaaS intelligence that investors trust
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Systems Flow delivers enterprise-grade technical analysis in minutes, not months. See why leading VCs and acquisition teams choose automated intelligence.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <Card key={index} className="text-center">
              <CardContent className="pt-6">
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-primary">{stat.number}</div>
                  <div className="font-semibold">{stat.label}</div>
                  <p className="text-sm text-muted-foreground">{stat.description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-20 text-center">
          <p className="text-muted-foreground mb-8">
            Trusted by SaaS founders, investors, and acquisition teams worldwide
          </p>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8 items-center justify-items-center opacity-60">
            <div className="text-lg font-semibold">Sequoia Capital</div>
            <div className="text-lg font-semibold">Andreessen Horowitz</div>
            <div className="text-lg font-semibold">First Round</div>
            <div className="text-lg font-semibold">Bessemer</div>
            <div className="text-lg font-semibold">General Catalyst</div>
          </div>
        </div>
      </div>
    </section>
  )
}