import { useState, useEffect } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog'
import { Button } from './ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Badge } from './ui/badge'
import { Separator } from './ui/separator'
import { CheckCircle, CreditCard, Shield, Zap, BarChart3, X } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { paymentService } from '../services/paymentService'
import { toast } from 'sonner'

declare global {
  interface Window {
    Stripe: any
  }
}

interface PaymentModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  selectedPlan?: 'core' | 'pro' | 'portfolio'
}

export function PaymentModal({ open, onOpenChange, selectedPlan = 'core' }: PaymentModalProps) {
  const { user, getAccessToken } = useAuth()
  const [loading, setLoading] = useState(false)
  const [stripe, setStripe] = useState<any>(null)
  const [elements, setElements] = useState<any>(null)
  const [cardElement, setCardElement] = useState<any>(null)
  const [clientSecret, setClientSecret] = useState<string | null>(null)
  const [selectedPaymentPlan, setSelectedPaymentPlan] = useState(selectedPlan)
  const [paymentStep, setPaymentStep] = useState<'select' | 'payment' | 'success'>('select')

  // Product configuration
  const products = {
    core: {
      name: 'Core Report',
      price: 299,
      amount: 29900, // in cents
      description: 'Comprehensive analysis for due diligence',
      features: [
        'Codebase Intelligence',
        'Architecture Mapping',
        'Security Assessment',
        'Performance Analysis',
        'Technical Debt Report',
        'PDF Export',
      ],
      icon: BarChart3,
      badge: 'One-time',
    },
    pro: {
      name: 'Pro Report',
      price: 699,
      amount: 69900, // in cents
      description: 'Advanced analysis with additional insights',
      features: [
        'Everything in Core Report',
        'Advanced Analytics',
        'Custom Metrics',
        'Executive Summary',
        'Risk Assessment',
        'Compliance Analysis',
        'Priority Support',
      ],
      icon: Zap,
      badge: 'One-time',
    },
    portfolio: {
      name: 'Portfolio',
      price: 999,
      amount: 99900, // in cents
      description: 'Monthly subscription for portfolio management',
      features: [
        'Everything in Pro Report',
        'Unlimited Projects',
        'Real-time Monitoring',
        'Team Collaboration',
        'API Access',
        'Custom Integrations',
        'Dedicated Support',
      ],
      icon: Shield,
      badge: 'Monthly',
    },
  }

  // Load Stripe
  useEffect(() => {
    if (open) {
      const loadStripe = async () => {
        if (!window.Stripe) {
          const script = document.createElement('script')
          script.src = 'https://js.stripe.com/v3/'
          script.onload = () => {
            const stripeInstance = window.Stripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY)
            setStripe(stripeInstance)
          }
          document.head.appendChild(script)
        } else {
          const stripeInstance = window.Stripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY)
          setStripe(stripeInstance)
        }
      }

      loadStripe()
    }
  }, [open])

  // Setup Stripe Elements when moving to payment step
  useEffect(() => {
    if (stripe && paymentStep === 'payment' && !elements) {
      const elementsInstance = stripe.elements()
      setElements(elementsInstance)

      const cardElementInstance = elementsInstance.create('card', {
        style: {
          base: {
            fontSize: '16px',
            color: '#424770',
            '::placeholder': {
              color: '#aab7c4',
            },
          },
        },
      })

      cardElementInstance.mount('#card-element')
      setCardElement(cardElementInstance)
    }
  }, [stripe, paymentStep, elements])

  const handlePlanSelection = async (plan: 'core' | 'pro' | 'portfolio') => {
    setSelectedPaymentPlan(plan)
    
    if (plan === 'portfolio') {
      // For subscription, we'll handle this differently
      setPaymentStep('payment')
    } else {
      // For one-time payments, create payment intent
      await createPaymentIntent(plan)
    }
  }

  const createPaymentIntent = async (plan: 'core' | 'pro') => {
    if (!user) return

    setLoading(true)
    try {
      const token = await getAccessToken()
      if (!token) {
        toast.error('Authentication required')
        return
      }

      const product = products[plan]
      const { clientSecret } = await paymentService.createPaymentIntent(
        product.amount,
        `${plan}-report`,
        token
      )

      setClientSecret(clientSecret)
      setPaymentStep('payment')
    } catch (error) {
      console.error('Error creating payment intent:', error)
      toast.error(error instanceof Error ? error.message : 'Failed to create payment')
    } finally {
      setLoading(false)
    }
  }

  const handlePayment = async () => {
    if (!stripe || !elements || !user) return

    setLoading(true)
    try {
      const token = await getAccessToken()
      if (!token) {
        toast.error('Authentication required')
        return
      }

      if (selectedPaymentPlan === 'portfolio') {
        // Handle subscription payment
        const { error: paymentError, paymentMethod } = await stripe.createPaymentMethod({
          type: 'card',
          card: cardElement,
        })

        if (paymentError) {
          toast.error(paymentError.message)
          return
        }

        // You'll need to create price IDs in your Stripe dashboard
        const priceId = import.meta.env.VITE_STRIPE_PORTFOLIO_PRICE_ID || 'price_1234567890'
        
        const { subscriptionId, clientSecret: subClientSecret } = await paymentService.createSubscription(
          priceId,
          paymentMethod.id,
          token
        )

        const { error: confirmError } = await stripe.confirmCardPayment(subClientSecret)

        if (confirmError) {
          toast.error(confirmError.message)
        } else {
          setPaymentStep('success')
          toast.success('Subscription created successfully!')
        }
      } else {
        // Handle one-time payment
        if (!clientSecret) {
          toast.error('Payment setup incomplete')
          return
        }

        const { error } = await stripe.confirmCardPayment(clientSecret, {
          payment_method: {
            card: cardElement,
            billing_details: {
              email: user.email,
              name: user.user_metadata?.name || user.email,
            },
          },
        })

        if (error) {
          toast.error(error.message)
        } else {
          setPaymentStep('success')
          toast.success('Payment successful!')
        }
      }
    } catch (error) {
      console.error('Payment error:', error)
      toast.error(error instanceof Error ? error.message : 'Payment failed')
    } finally {
      setLoading(false)
    }
  }

  const handleClose = () => {
    setPaymentStep('select')
    setClientSecret(null)
    setElements(null)
    setCardElement(null)
    onOpenChange(false)
  }

  const currentProduct = products[selectedPaymentPlan]

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle>
            {paymentStep === 'select' && 'Choose Your Plan'}
            {paymentStep === 'payment' && `Complete Payment - ${currentProduct.name}`}
            {paymentStep === 'success' && 'Payment Successful!'}
          </DialogTitle>
          <Button variant="ghost" size="sm" onClick={handleClose}>
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        {paymentStep === 'select' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {Object.entries(products).map(([key, product]) => {
                const IconComponent = product.icon
                return (
                  <Card 
                    key={key}
                    className={`cursor-pointer transition-all hover:shadow-lg ${
                      selectedPaymentPlan === key ? 'ring-2 ring-primary' : ''
                    }`}
                    onClick={() => setSelectedPaymentPlan(key as 'core' | 'pro' | 'portfolio')}
                  >
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <IconComponent className="h-8 w-8 text-primary" />
                        <Badge variant={key === 'portfolio' ? 'default' : 'secondary'}>
                          {product.badge}
                        </Badge>
                      </div>
                      <CardTitle className="text-xl">{product.name}</CardTitle>
                      <div className="text-3xl font-bold">
                        ${product.price}
                        {key === 'portfolio' && <span className="text-lg font-normal">/month</span>}
                      </div>
                      <CardDescription>{product.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {product.features.map((feature, index) => (
                          <li key={index} className="flex items-center space-x-2">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            <span className="text-sm">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            <div className="flex justify-center">
              <Button 
                onClick={() => handlePlanSelection(selectedPaymentPlan)}
                disabled={loading}
                size="lg"
              >
                {loading ? 'Setting up...' : `Continue with ${currentProduct.name}`}
              </Button>
            </div>
          </div>
        )}

        {paymentStep === 'payment' && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <currentProduct.icon className="h-5 w-5" />
                  <span>{currentProduct.name}</span>
                  <Badge>{currentProduct.badge}</Badge>
                </CardTitle>
                <CardDescription>{currentProduct.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <span className="text-lg">Total:</span>
                  <span className="text-2xl font-bold">
                    ${currentProduct.price}
                    {selectedPaymentPlan === 'portfolio' && '/month'}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CreditCard className="h-5 w-5" />
                  <span>Payment Details</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div id="card-element" className="p-3 border rounded-md">
                  {/* Stripe card element will be mounted here */}
                </div>
                
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <Shield className="h-4 w-4" />
                  <span>Your payment information is secure and encrypted</span>
                </div>
              </CardContent>
            </Card>

            <div className="flex space-x-4">
              <Button variant="outline" onClick={() => setPaymentStep('select')} className="flex-1">
                Back to Plans
              </Button>
              <Button onClick={handlePayment} disabled={loading} className="flex-1">
                {loading ? 'Processing...' : `Pay $${currentProduct.price}`}
              </Button>
            </div>
          </div>
        )}

        {paymentStep === 'success' && (
          <div className="text-center space-y-6">
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="h-10 w-10 text-green-500" />
              </div>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-2xl font-bold">Payment Successful!</h3>
              <p className="text-muted-foreground">
                Thank you for purchasing {currentProduct.name}. You now have access to advanced analysis features.
              </p>
            </div>

            <div className="flex justify-center">
              <Button onClick={handleClose}>
                Continue to Dashboard
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}