import { Button } from "./ui/button"
import { Menu, X, User, LogOut, LayoutDashboard } from "lucide-react"
import { useState } from "react"
import { useAuth } from "../contexts/AuthContext"
import { AuthModal } from "./AuthModal"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"

interface HeaderProps {
  onStartDemo?: () => void
  onOpenDashboard?: () => void
}

export function Header({ onStartDemo, onOpenDashboard }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const { user, loading, signOut } = useAuth()

  const handleAuthSuccess = () => {
    setShowAuthModal(false)
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-8">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <svg className="w-4 h-4 text-primary-foreground" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 9.74s9-4.19 9-9.74V7l-10-5z"/>
                <circle cx="12" cy="12" r="3"/>
                <path d="M12 1v6M12 17v6M6.5 3l6 3M17.5 21l-6-3M2.5 9l6 3M21.5 15l-6-3"/>
              </svg>
            </div>
            <span className="text-xl font-semibold">Systems Flow</span>
          </div>
          
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#features" className="text-muted-foreground hover:text-foreground transition-colors">Features</a>
            <a href="#examples" className="text-muted-foreground hover:text-foreground transition-colors">Examples</a>
            <a href="#pricing" className="text-muted-foreground hover:text-foreground transition-colors">Pricing</a>
            <a href="#about" className="text-muted-foreground hover:text-foreground transition-colors">About</a>
          </nav>
        </div>

        <div className="hidden md:flex items-center space-x-4">
          {loading ? (
            <div className="w-20 h-9 bg-muted animate-pulse rounded"></div>
          ) : user ? (
            <>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="flex items-center space-x-2">
                    <User className="h-4 w-4" />
                    <span>{user.user_metadata?.name || user.email}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onOpenDashboard}>
                    <LayoutDashboard className="mr-2 h-4 w-4" />
                    Dashboard
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={signOut}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <Button onClick={onStartDemo}>Start Analysis</Button>
            </>
          ) : (
            <>
              <Button variant="ghost" onClick={() => setShowAuthModal(true)}>Sign In</Button>
              <Button onClick={onStartDemo}>Start Analysis</Button>
            </>
          )}
        </div>

        <button 
          className="md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {isMenuOpen && (
        <div className="md:hidden border-t bg-background">
          <nav className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <a href="#features" className="hover:text-primary transition-colors">Features</a>
            <a href="#examples" className="hover:text-primary transition-colors">Examples</a>
            <a href="#pricing" className="hover:text-primary transition-colors">Pricing</a>
            <a href="#about" className="hover:text-primary transition-colors">About</a>
            <div className="pt-4 border-t space-y-2">
              {loading ? (
                <div className="w-full h-9 bg-muted animate-pulse rounded"></div>
              ) : user ? (
                <>
                  <div className="px-3 py-2 text-sm text-muted-foreground">
                    Signed in as {user.user_metadata?.name || user.email}
                  </div>
                  <Button variant="ghost" className="w-full justify-start" onClick={onOpenDashboard}>
                    <LayoutDashboard className="mr-2 h-4 w-4" />
                    Dashboard
                  </Button>
                  <Button variant="ghost" className="w-full justify-start" onClick={signOut}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Sign Out
                  </Button>
                </>
              ) : (
                <Button variant="ghost" className="w-full justify-start" onClick={() => setShowAuthModal(true)}>
                  <User className="mr-2 h-4 w-4" />
                  Sign In
                </Button>
              )}
              <Button className="w-full" onClick={onStartDemo}>Start Analysis</Button>
            </div>
          </nav>
        </div>
      )}
      
      <AuthModal 
        open={showAuthModal} 
        onOpenChange={setShowAuthModal}
        onSuccess={handleAuthSuccess}
      />
    </header>
  )
}