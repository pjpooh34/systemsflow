import { Button } from "./ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"
import { Check, ArrowRight } from "lucide-react"
import { useState, useEffect } from "react"
import { PaymentModal } from "./PaymentModal"
import { AuthModal } from "./AuthModal"
import { useAuth } from "../contexts/AuthContext"
import { projectId, publicAnonKey } from "../utils/supabase/info"

const plans = [
  {
    name: "Preview Scan",
    price: "$0",
    period: "— $49",
    description: "Perfect for SaaS founders exploring their options",
    features: [
      "Basic stack detection",
      "Key APIs overview",
      "Framework identification",
      "Short architectural summary",
      "5-minute analysis time",
      "Basic export options"
    ],
    highlighted: false,
    cta: "Try Free Scan"
  },
  {
    name: "Core Report",
    price: "$299",
    period: "per report",
    description: "Ideal for sellers and acquirers needing full analysis",
    features: [
      "Complete architecture mapping",
      "Full dependency analysis",
      "AI-generated technical report",
      "Executive summary in plain English",
      "Exportable PDF & HTML",
      "Security vulnerability assessment",
      "Scalability evaluation",
      "Technical debt quantification"
    ],
    highlighted: true,
    cta: "Get Full Report"
  },
  {
    name: "Pro Report",
    price: "$699",
    period: "per report",
    description: "For investors and SaaS brokers requiring deep insights",
    features: [
      "Everything in Core Report",
      "Extended analysis & insights",
      "Architecture comparison tools",
      "Team skill gap analysis",
      "Integration complexity assessment",
      "Custom branding options",
      "Risk assessment & recommendations",
      "Priority support & consultation"
    ],
    highlighted: false,
    cta: "Upgrade to Pro"
  },
  {
    name: "Portfolio Tier",
    price: "$999",
    period: "— $1,499/mo",
    description: "For agencies, VC & PE firms with multiple projects",
    features: [
      "Unlimited SaaS analyses",
      "Continuous monitoring & alerts",
      "Architecture drift detection",
      "White-label dashboard",
      "Team collaboration features",
      "API access for integration",
      "Dedicated customer success",
      "Custom analysis frameworks"
    ],
    highlighted: false,
    cta: "Book Demo"
  }
]

interface PricingProps {
  onStartDemo?: () => void
  onOpenDashboard?: () => void
}

interface UserTier {
  subscription: any
  purchases: any[]
  hasActiveSubscription: boolean
  hasCoreReport: boolean
  hasProReport: boolean
}

export function Pricing({ onStartDemo, onOpenDashboard }: PricingProps) {
  const { user, session } = useAuth()
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<'core' | 'pro' | 'portfolio'>('core')
  const [userTier, setUserTier] = useState<UserTier | null>(null)
  const [loading, setLoading] = useState(false)

  // Fetch user's current subscription status
  const fetchUserTier = async () => {
    if (!user || !session?.access_token) return
    
    setLoading(true)
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-e90433f1/payments/status`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setUserTier(data)
      }
    } catch (error) {
      console.error('Error fetching user tier:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (user && session?.access_token) {
      fetchUserTier()
    } else {
      setUserTier(null)
    }
  }, [user, session])

  const getUserPlanStatus = (planType: 'free' | 'core' | 'pro' | 'portfolio') => {
    if (!userTier) return 'available'
    
    switch (planType) {
      case 'free':
        return 'available' // Free tier is always available
      case 'core':
        return userTier.hasCoreReport ? 'owned' : 'available'
      case 'pro':
        return userTier.hasProReport ? 'owned' : 'available'
      case 'portfolio':
        return userTier.hasActiveSubscription ? 'active' : 'available'
      default:
        return 'available'
    }
  }

  const getButtonText = (planType: 'free' | 'core' | 'pro' | 'portfolio', originalText: string) => {
    const status = getUserPlanStatus(planType)
    
    switch (status) {
      case 'owned':
        return 'Generate Report'
      case 'active':
        return 'Access Dashboard'
      default:
        return originalText
    }
  }

  const handlePlanSelect = (planType: 'free' | 'core' | 'pro' | 'portfolio') => {
    if (planType === 'free') {
      onStartDemo?.()
      return
    }

    // If user is not authenticated, show auth modal first
    if (!user) {
      setShowAuthModal(true)
      return
    }

    const status = getUserPlanStatus(planType)
    
    // If user already has access to this tier, redirect to dashboard/functionality
    if (status === 'owned' || status === 'active') {
      onOpenDashboard?.()
      return
    }

    // Otherwise, show payment modal for purchase/upgrade
    setSelectedPlan(planType)
    setShowPaymentModal(true)
  }

  const handleAuthSuccess = () => {
    setShowAuthModal(false)
    // After successful auth, fetch user tier
    setTimeout(() => {
      fetchUserTier()
    }, 1000)
  }

  return (
    <section id="pricing" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <Badge variant="secondary" className="w-fit mx-auto">Pricing</Badge>
          <h2 className="text-3xl lg:text-5xl">
            Enterprise clarity without enterprise price tags
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Replace $25K+ enterprise tools and weeks of manual analysis with instant, automated insights. No contracts, no consultants, just clarity.
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6 max-w-7xl mx-auto relative">
          {plans.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative ${plan.highlighted ? 'ring-2 ring-primary shadow-xl' : ''}`}
            >
              {plan.highlighted && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  Most Popular
                </Badge>
              )}
              
              {/* Show current tier status */}
              {(() => {
                let planType: 'free' | 'core' | 'pro' | 'portfolio'
                if (plan.name === 'Preview Scan') planType = 'free'
                else if (plan.name === 'Core Report') planType = 'core'
                else if (plan.name === 'Pro Report') planType = 'pro'
                else planType = 'portfolio'
                
                const status = getUserPlanStatus(planType)
                
                if (status === 'owned') {
                  return (
                    <Badge variant="secondary" className="absolute -top-3 right-4">
                      Purchased
                    </Badge>
                  )
                } else if (status === 'active') {
                  return (
                    <Badge variant="default" className="absolute -top-3 right-4">
                      Active
                    </Badge>
                  )
                }
                return null
              })()}
              
              <CardHeader className="text-center pb-8">
                <CardTitle className="text-xl">{plan.name}</CardTitle>
                <div className="mt-4">
                  <span className="text-3xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground ml-1 text-sm">{plan.period}</span>
                </div>
                <CardDescription className="mt-4 text-sm">
                  {plan.description}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                <ul className="space-y-2">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start space-x-2">
                      <Check className="h-3 w-3 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-xs">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button 
                  className={`w-full group text-sm`}
                  variant={plan.highlighted ? 'default' : 'outline'}
                  disabled={loading}
                  onClick={() => {
                    if (plan.name === 'Preview Scan') {
                      handlePlanSelect('free')
                    } else if (plan.name === 'Core Report') {
                      handlePlanSelect('core')
                    } else if (plan.name === 'Pro Report') {
                      handlePlanSelect('pro')
                    } else if (plan.name === 'Portfolio Tier') {
                      handlePlanSelect('portfolio')
                    }
                  }}
                >
                  {(() => {
                    if (plan.name === 'Preview Scan') {
                      return getButtonText('free', plan.cta)
                    } else if (plan.name === 'Core Report') {
                      return getButtonText('core', plan.cta)
                    } else if (plan.name === 'Pro Report') {
                      return getButtonText('pro', plan.cta)
                    } else if (plan.name === 'Portfolio Tier') {
                      return getButtonText('portfolio', plan.cta)
                    }
                    return plan.cta
                  })()}
                  <ArrowRight className="ml-2 h-3 w-3 group-hover:translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center space-y-8">
          <div className="bg-muted/50 rounded-2xl p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl mb-4">90% cheaper than traditional alternatives</h3>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div className="space-y-2">
                <div className="text-lg font-semibold text-muted-foreground line-through">Enterprise Tools</div>
                <div className="text-sm text-muted-foreground">$25K+/year + setup</div>
              </div>
              <div className="space-y-2">
                <div className="text-lg font-semibold text-muted-foreground line-through">Manual Audits</div>
                <div className="text-sm text-muted-foreground">$3K-$5K per report</div>
              </div>
              <div className="space-y-2">
                <div className="text-lg font-semibold text-primary">Systems Flow</div>
                <div className="text-sm">$299-$699 instant analysis</div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-2xl">Frequently Asked Questions</h3>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto text-left">
              <div className="space-y-2">
                <h4 className="font-semibold">How fast is the analysis?</h4>
                <p className="text-sm text-muted-foreground">
                  Complete technical analysis in under 5 minutes. No waiting weeks for consultant reports.
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">What makes this different from enterprise tools?</h4>
                <p className="text-sm text-muted-foreground">
                  Fully automated, AI-driven analysis with instant results. No setup, no training, no consultants required.
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">How comprehensive is the analysis?</h4>
                <p className="text-sm text-muted-foreground">
                  Complete technical due diligence including architecture, security, scalability, and recommendations.
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold">Is my code secure?</h4>
                <p className="text-sm text-muted-foreground">
                  All code is processed in secure sandboxes and automatically deleted. We never store your source code.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <PaymentModal 
        open={showPaymentModal}
        onOpenChange={setShowPaymentModal}
        selectedPlan={selectedPlan}
      />

      <AuthModal 
        open={showAuthModal}
        onOpenChange={setShowAuthModal}
        onSuccess={handleAuthSuccess}
      />
    </section>
  )
}