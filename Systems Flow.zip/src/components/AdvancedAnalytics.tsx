import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select"
import { AnimatedCard, StaggeredCards } from "./ui/animated-card"
import { motion } from "motion/react"
import {
  TrendingUp, TrendingDown, BarChart3, PieChart, LineChart, Activity, 
  Calendar, Filter, Download, Share, RefreshCw, Target, Award, 
  Zap, Users, Code, Shield, Database, Clock, AlertTriangle, CheckCircle
} from "lucide-react"
import {
  LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart, Area, BarChart, Bar, PieChart as RechartsPieChart, Pie, Cell, Scatter,
  ScatterChart, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
  ComposedChart, Legend
} from 'recharts'

interface AdvancedAnalyticsProps {
  onBack: () => void
}

export function AdvancedAnalytics({ onBack }: AdvancedAnalyticsProps) {
  const [activeTab, setActiveTab] = useState('overview')
  const [timeRange, setTimeRange] = useState('30d')
  const [selectedMetric, setSelectedMetric] = useState('all')

  // Mock data for advanced analytics
  const trendData = [
    { date: 'Jan', codeQuality: 7.2, security: 8.1, performance: 6.8, maintainability: 7.5 },
    { date: 'Feb', codeQuality: 7.4, security: 8.3, performance: 7.1, maintainability: 7.7 },
    { date: 'Mar', codeQuality: 7.8, security: 8.2, performance: 7.5, maintainability: 8.0 },
    { date: 'Apr', codeQuality: 8.1, security: 8.5, performance: 7.8, maintainability: 8.2 },
    { date: 'May', codeQuality: 8.3, security: 8.7, performance: 8.1, maintainability: 8.4 },
    { date: 'Jun', codeQuality: 8.5, security: 8.9, performance: 8.3, maintainability: 8.6 }
  ]

  const projectDistribution = [
    { name: 'Enterprise', value: 45, fill: '#3b82f6' },
    { name: 'SaaS', value: 30, fill: '#10b981' },
    { name: 'Mobile', value: 15, fill: '#f59e0b' },
    { name: 'IoT', value: 10, fill: '#ef4444' }
  ]

  const complexityData = [
    { component: 'Authentication', complexity: 8, maintainability: 7, testCoverage: 85 },
    { component: 'Payment Processing', complexity: 9, maintainability: 6, testCoverage: 78 },
    { component: 'User Management', complexity: 6, maintainability: 8, testCoverage: 92 },
    { component: 'Analytics Engine', complexity: 9, maintainability: 5, testCoverage: 65 },
    { component: 'API Gateway', complexity: 7, maintainability: 7, testCoverage: 88 },
    { component: 'Data Pipeline', complexity: 8, maintainability: 6, testCoverage: 72 }
  ]

  const performanceMetrics = [
    { metric: 'API Response Time', current: 245, target: 200, trend: 'improving' },
    { metric: 'Error Rate', current: 0.8, target: 0.5, trend: 'stable' },
    { metric: 'Uptime', current: 99.7, target: 99.9, trend: 'stable' },
    { metric: 'Throughput', current: 1250, target: 1500, trend: 'improving' },
    { metric: 'Memory Usage', current: 78, target: 70, trend: 'declining' },
    { metric: 'CPU Utilization', current: 65, target: 60, trend: 'stable' }
  ]

  const securityInsights = [
    { category: 'Authentication', score: 9.2, issues: 2, critical: 0 },
    { category: 'Data Protection', score: 8.7, issues: 3, critical: 1 },
    { category: 'API Security', score: 8.9, issues: 1, critical: 0 },
    { category: 'Infrastructure', score: 8.5, issues: 4, critical: 0 },
    { category: 'Dependencies', score: 7.8, issues: 8, critical: 2 },
    { category: 'Code Quality', score: 8.3, issues: 5, critical: 1 }
  ]

  const portfolioData = [
    { name: 'TechCorp CRM', quality: 8.5, security: 9.1, performance: 7.8, size: 'large' },
    { name: 'StartupXYZ Analytics', quality: 7.2, security: 8.3, performance: 8.9, size: 'medium' },
    { name: 'Enterprise ERP', quality: 6.8, security: 7.9, performance: 7.1, size: 'large' },
    { name: 'Mobile Commerce', quality: 8.9, security: 8.7, performance: 9.2, size: 'small' },
    { name: 'IoT Platform', quality: 7.5, security: 8.1, performance: 6.9, size: 'medium' },
    { name: 'Financial Services', quality: 9.1, security: 9.8, performance: 8.3, size: 'large' }
  ]

  const getStatusColor = (score: number) => {
    if (score >= 8.5) return 'text-green-600'
    if (score >= 7.0) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'improving': return <TrendingUp className="h-4 w-4 text-green-600" />
      case 'declining': return <TrendingDown className="h-4 w-4 text-red-600" />
      default: return <Activity className="h-4 w-4 text-gray-600" />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              ← Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold">Advanced Analytics</h1>
              <p className="text-muted-foreground">
                Deep insights and trends across your software portfolio
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">7 days</SelectItem>
                <SelectItem value="30d">30 days</SelectItem>
                <SelectItem value="90d">90 days</SelectItem>
                <SelectItem value="1y">1 year</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </motion.div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
            <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="insights">Insights</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <StaggeredCards className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: 'Portfolio Score', value: '8.2', change: '+0.3', icon: <Award className="h-8 w-8 text-purple-600" /> },
                { title: 'Security Rating', value: '8.7', change: '+0.2', icon: <Shield className="h-8 w-8 text-green-600" /> },
                { title: 'Performance Index', value: '7.9', change: '-0.1', icon: <Zap className="h-8 w-8 text-yellow-600" /> },
                { title: 'Tech Debt Ratio', value: '12%', change: '-2%', icon: <Code className="h-8 w-8 text-blue-600" /> }
              ].map((metric, index) => (
                <AnimatedCard key={metric.title} hoverScale fadeIn delay={index * 0.1}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">{metric.title}</p>
                        <p className="text-2xl font-bold">{metric.value}</p>
                      </div>
                      {metric.icon}
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      {metric.change.startsWith('+') ? '+' : ''}{metric.change} this month
                    </p>
                  </CardContent>
                </AnimatedCard>
              ))}
            </StaggeredCards>

            {/* Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Quality Trends</CardTitle>
                  <CardDescription>Overall quality metrics over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RechartsLineChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis domain={[6, 10]} />
                      <Tooltip />
                      <Line type="monotone" dataKey="codeQuality" stroke="#3b82f6" strokeWidth={2} />
                      <Line type="monotone" dataKey="security" stroke="#10b981" strokeWidth={2} />
                      <Line type="monotone" dataKey="performance" stroke="#f59e0b" strokeWidth={2} />
                      <Line type="monotone" dataKey="maintainability" stroke="#ef4444" strokeWidth={2} />
                    </RechartsLineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Project Distribution</CardTitle>
                  <CardDescription>Portfolio breakdown by project type</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RechartsPieChart>
                      <Pie
                        data={projectDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={120}
                        dataKey="value"
                      >
                        {projectDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `${value}%`} />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                  <div className="flex justify-center space-x-4 mt-4">
                    {projectDistribution.map((entry) => (
                      <div key={entry.name} className="flex items-center space-x-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: entry.fill }}
                        />
                        <span className="text-sm">{entry.name}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Performance Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Performance Summary</CardTitle>
                <CardDescription>Key performance indicators across all projects</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {performanceMetrics.map((metric) => (
                    <div key={metric.metric} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        {getTrendIcon(metric.trend)}
                        <div>
                          <div className="font-medium">{metric.metric}</div>
                          <div className="text-sm text-muted-foreground">
                            Current: {metric.current}{metric.metric.includes('Rate') ? '%' : metric.metric.includes('Time') ? 'ms' : ''}
                          </div>
                        </div>
                      </div>
                      <Badge variant="outline" className={
                        metric.current <= metric.target ? 'text-green-700 bg-green-50' : 'text-yellow-700 bg-yellow-50'
                      }>
                        {metric.current <= metric.target ? 'On Target' : 'Needs Attention'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Trends Tab */}
          <TabsContent value="trends" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Multi-Metric Trend Analysis</CardTitle>
                <CardDescription>Comprehensive view of all quality metrics over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <ComposedChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area type="monotone" dataKey="codeQuality" fill="#dbeafe" stroke="#3b82f6" name="Code Quality" />
                    <Line type="monotone" dataKey="security" stroke="#10b981" strokeWidth={3} name="Security" />
                    <Bar dataKey="performance" fill="#f59e0b" name="Performance" />
                  </ComposedChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Code Complexity Analysis</CardTitle>
                  <CardDescription>Complexity vs maintainability correlation</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <ScatterChart data={complexityData}>
                      <CartesianGrid />
                      <XAxis dataKey="complexity" name="Complexity" />
                      <YAxis dataKey="maintainability" name="Maintainability" />
                      <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                      <Scatter dataKey="testCoverage" fill="#3b82f6" />
                    </ScatterChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Security Radar</CardTitle>
                  <CardDescription>Security assessment across different categories</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RadarChart data={securityInsights}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="category" />
                      <PolarRadiusAxis domain={[0, 10]} />
                      <Radar dataKey="score" stroke="#10b981" fill="#10b981" fillOpacity={0.6} />
                    </RadarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Portfolio Tab */}
          <TabsContent value="portfolio" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Portfolio Matrix</CardTitle>
                <CardDescription>Quality vs Security analysis across all projects</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <ScatterChart data={portfolioData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="quality" name="Quality Score" domain={[6, 10]} />
                    <YAxis dataKey="security" name="Security Score" domain={[6, 10]} />
                    <Tooltip 
                      cursor={{ strokeDasharray: '3 3' }}
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload
                          return (
                            <div className="bg-white p-3 border rounded-lg shadow-md">
                              <p className="font-medium">{data.name}</p>
                              <p className="text-sm">Quality: {data.quality}</p>
                              <p className="text-sm">Security: {data.security}</p>
                              <p className="text-sm">Performance: {data.performance}</p>
                            </div>
                          )
                        }
                        return null
                      }}
                    />
                    <Scatter dataKey="performance" fill="#3b82f6" />
                  </ScatterChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Project Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {portfolioData.map((project, index) => (
                <AnimatedCard key={project.name} hoverScale fadeIn delay={index * 0.1}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{project.name}</CardTitle>
                      <Badge variant="outline" className={
                        project.size === 'large' ? 'bg-red-50 text-red-700' :
                        project.size === 'medium' ? 'bg-yellow-50 text-yellow-700' :
                        'bg-green-50 text-green-700'
                      }>
                        {project.size}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Quality</span>
                        <span className={`text-sm font-medium ${getStatusColor(project.quality)}`}>
                          {project.quality}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Security</span>
                        <span className={`text-sm font-medium ${getStatusColor(project.security)}`}>
                          {project.security}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Performance</span>
                        <span className={`text-sm font-medium ${getStatusColor(project.performance)}`}>
                          {project.performance}
                        </span>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" className="flex-1">
                        <BarChart3 className="h-3 w-3 mr-1" />
                        Details
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1">
                        <RefreshCw className="h-3 w-3 mr-1" />
                        Re-analyze
                      </Button>
                    </div>
                  </CardContent>
                </AnimatedCard>
              ))}
            </div>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {securityInsights.map((category, index) => (
                <AnimatedCard key={category.category} hoverScale fadeIn delay={index * 0.1}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{category.category}</CardTitle>
                      <div className="flex items-center space-x-2">
                        {category.critical > 0 ? (
                          <AlertTriangle className="h-4 w-4 text-red-600" />
                        ) : (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        )}
                        <span className={`text-lg font-bold ${getStatusColor(category.score)}`}>
                          {category.score}
                        </span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Total Issues</span>
                      <Badge variant="outline">{category.issues}</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Critical Issues</span>
                      <Badge variant={category.critical > 0 ? "destructive" : "secondary"}>
                        {category.critical}
                      </Badge>
                    </div>
                    <Button size="sm" className="w-full">
                      <Shield className="h-3 w-3 mr-1" />
                      View Details
                    </Button>
                  </CardContent>
                </AnimatedCard>
              ))}
            </div>
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Trends</CardTitle>
                <CardDescription>Key performance indicators over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <AreaChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="performance" stroke="#f59e0b" fill="#fef3c7" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {performanceMetrics.map((metric, index) => (
                <Card key={metric.metric}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="font-medium">{metric.metric}</h3>
                        <p className="text-2xl font-bold">
                          {metric.current}{metric.metric.includes('Rate') ? '%' : metric.metric.includes('Time') ? 'ms' : ''}
                        </p>
                      </div>
                      {getTrendIcon(metric.trend)}
                    </div>
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>Target: {metric.target}</span>
                      <span className={metric.current <= metric.target ? 'text-green-600' : 'text-yellow-600'}>
                        {metric.current <= metric.target ? 'On Track' : 'Needs Improvement'}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Insights Tab */}
          <TabsContent value="insights" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Key Insights</CardTitle>
                  <CardDescription>AI-generated insights from your portfolio</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 border-l-4 border-green-500 bg-green-50">
                    <div className="flex items-center space-x-2 mb-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="font-medium">Security Improvement</span>
                    </div>
                    <p className="text-sm text-green-700">
                      Your portfolio security score improved by 12% this quarter, primarily due to better dependency management.
                    </p>
                  </div>
                  
                  <div className="p-4 border-l-4 border-yellow-500 bg-yellow-50">
                    <div className="flex items-center space-x-2 mb-2">
                      <AlertTriangle className="h-4 w-4 text-yellow-600" />
                      <span className="font-medium">Performance Bottleneck</span>
                    </div>
                    <p className="text-sm text-yellow-700">
                      Database queries in the Analytics Engine are causing 15% slower response times. Consider optimization.
                    </p>
                  </div>
                  
                  <div className="p-4 border-l-4 border-blue-500 bg-blue-50">
                    <div className="flex items-center space-x-2 mb-2">
                      <Target className="h-4 w-4 text-blue-600" />
                      <span className="font-medium">Optimization Opportunity</span>
                    </div>
                    <p className="text-sm text-blue-700">
                      Implementing code splitting in your React applications could improve performance by 25%.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recommendations</CardTitle>
                  <CardDescription>Actionable steps to improve your portfolio</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { priority: 'High', action: 'Update critical security dependencies', impact: 'Reduces vulnerability risk by 40%' },
                    { priority: 'Medium', action: 'Implement automated testing for API endpoints', impact: 'Improves reliability and reduces bugs' },
                    { priority: 'Medium', action: 'Optimize database indexing strategy', impact: 'Potential 30% performance improvement' },
                    { priority: 'Low', action: 'Standardize code formatting across projects', impact: 'Improves maintainability and team productivity' }
                  ].map((rec, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 border rounded-lg">
                      <Badge variant={
                        rec.priority === 'High' ? 'destructive' :
                        rec.priority === 'Medium' ? 'default' : 'secondary'
                      }>
                        {rec.priority}
                      </Badge>
                      <div className="flex-1">
                        <p className="font-medium">{rec.action}</p>
                        <p className="text-sm text-muted-foreground">{rec.impact}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}