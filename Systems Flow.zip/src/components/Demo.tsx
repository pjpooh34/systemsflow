import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Progress } from "./ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Textarea } from "./ui/textarea"
import { DemoReport } from "./DemoReport"
import { AnalysisTools } from "./AnalysisTools"
import { AdvancedAnalysisTools } from "./AdvancedAnalysisTools"
import { 
  Upload, Github, GitlabIcon as GitLab, Link, 
  ArrowRight, CheckCircle, Clock, Code, Shield, TrendingUp,
  FileText, Zap, Database, Users, Settings
} from "lucide-react"

interface DemoProps {
  onBack: () => void
  onOpenAnalysis?: () => void
}

export function Demo({ onBack, onOpenAnalysis }: DemoProps) {
  const [currentStep, setCurrentStep] = useState<'input' | 'analyzing' | 'tools' | 'advanced' | 'report'>('input')
  const [analysisProgress, setAnalysisProgress] = useState(0)
  const [selectedRepo, setSelectedRepo] = useState('')

  const handleStartAnalysis = () => {
    setCurrentStep('analyzing')
    
    // Simulate analysis progress
    const steps = [
      { label: 'Connecting to repository...', duration: 1000, progress: 15 },
      { label: 'Scanning codebase...', duration: 2000, progress: 35 },
      { label: 'Analyzing architecture...', duration: 1500, progress: 55 },
      { label: 'Checking security vulnerabilities...', duration: 1800, progress: 75 },
      { label: 'Generating insights...', duration: 1200, progress: 90 },
      { label: 'Initializing tools...', duration: 800, progress: 100 }
    ]
    
    let currentProgress = 0
    steps.forEach((step, index) => {
      setTimeout(() => {
        setAnalysisProgress(step.progress)
        if (index === steps.length - 1) {
          setTimeout(() => setCurrentStep('tools'), 500)
        }
      }, steps.slice(0, index + 1).reduce((acc, s) => acc + s.duration, 0))
    })
  }

  const handleOpenTools = () => {
    setCurrentStep('tools')
  }

  const handleOpenAdvancedTools = () => {
    setCurrentStep('advanced')
  }

  const handleGenerateReport = () => {
    setCurrentStep('report')
  }

  if (currentStep === 'report') {
    return <DemoReport onBack={onBack} />
  }

  if (currentStep === 'tools') {
    return <AnalysisTools onBack={() => setCurrentStep('input')} onGenerateReport={handleGenerateReport} />
  }

  if (currentStep === 'advanced') {
    return <AdvancedAnalysisTools onBack={() => setCurrentStep('input')} />
  }

  if (currentStep === 'analyzing') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="container mx-auto px-4 max-w-2xl">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Analyzing Your SaaS Platform</CardTitle>
              <CardDescription>
                Systems Flow is performing comprehensive analysis of TechCorp's customer support platform
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Analysis Progress</span>
                  <span>{analysisProgress}%</span>
                </div>
                <Progress value={analysisProgress} className="h-3" />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <Code className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                  <div className="text-sm font-medium">312 Components</div>
                  <div className="text-xs text-muted-foreground">Analyzed</div>
                </div>
                <div className="text-center">
                  <Shield className="h-8 w-8 mx-auto mb-2 text-green-600" />
                  <div className="text-sm font-medium">47 Vulnerabilities</div>
                  <div className="text-xs text-muted-foreground">Detected</div>
                </div>
                <div className="text-center">
                  <Database className="h-8 w-8 mx-auto mb-2 text-purple-600" />
                  <div className="text-sm font-medium">89 Tables</div>
                  <div className="text-xs text-muted-foreground">Mapped</div>
                </div>
                <div className="text-center">
                  <Users className="h-8 w-8 mx-auto mb-2 text-orange-600" />
                  <div className="text-sm font-medium">12 Developers</div>
                  <div className="text-xs text-muted-foreground">Profiled</div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-sm">Repository access established</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-sm">Codebase structure analyzed</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-sm">Security assessment completed</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Clock className="h-5 w-5 text-blue-600 animate-spin" />
                  <span className="text-sm">Initializing interactive analysis tools...</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-4">Try Systems Flow Demo</h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Experience our AI-powered SaaS analysis platform. Connect your repository or try our sample analysis 
            to see how Systems Flow can accelerate your due diligence process.
          </p>
        </div>

        <Tabs defaultValue="sample" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="sample">Sample Analysis</TabsTrigger>
            <TabsTrigger value="tools">Interactive Tools</TabsTrigger>
            <TabsTrigger value="connect">Connect Your Repo</TabsTrigger>
          </TabsList>

          <TabsContent value="sample" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="h-5 w-5 mr-2" />
                  Pre-built Sample Analysis
                </CardTitle>
                <CardDescription>
                  Explore a comprehensive analysis report of a $45M SaaS acquisition target
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-medium">Analysis Overview</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Platform Type:</span>
                        <span>Customer Support SaaS</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Tech Stack:</span>
                        <span>React + Node.js + PostgreSQL</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Team Size:</span>
                        <span>12 developers</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Analysis Time:</span>
                        <span>35 minutes</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="font-medium">Key Insights</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="bg-green-50 text-green-700">8.2/10</Badge>
                        <span className="text-sm">Overall Quality Score</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="bg-red-50 text-red-700">2 Critical</Badge>
                        <span className="text-sm">Security Issues</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="bg-yellow-50 text-yellow-700">$2.1M</Badge>
                        <span className="text-sm">Technical Debt</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-muted/30 rounded-lg">
                  <div className="text-center">
                    <Code className="h-6 w-6 mx-auto mb-1 text-blue-600" />
                    <div className="text-sm font-medium">312</div>
                    <div className="text-xs text-muted-foreground">Components</div>
                  </div>
                  <div className="text-center">
                    <Shield className="h-6 w-6 mx-auto mb-1 text-green-600" />
                    <div className="text-sm font-medium">47</div>
                    <div className="text-xs text-muted-foreground">Security Checks</div>
                  </div>
                  <div className="text-center">
                    <TrendingUp className="h-6 w-6 mx-auto mb-1 text-purple-600" />
                    <div className="text-sm font-medium">23</div>
                    <div className="text-xs text-muted-foreground">User Journeys</div>
                  </div>
                  <div className="text-center">
                    <Database className="h-6 w-6 mx-auto mb-1 text-orange-600" />
                    <div className="text-sm font-medium">89</div>
                    <div className="text-xs text-muted-foreground">Data Tables</div>
                  </div>
                </div>

                <Button onClick={handleStartAnalysis} size="lg" className="w-full group">
                  <Zap className="h-4 w-4 mr-2" />
                  View Sample Report
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tools" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Settings className="h-5 w-5 mr-2" />
                  Interactive Analysis Tools
                </CardTitle>
                <CardDescription>
                  Explore our real-time analysis capabilities with interactive demonstrations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-medium">Available Tools</h3>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <Code className="h-5 w-5 text-blue-600" />
                        <div>
                          <div className="font-medium text-sm">Codebase Intelligence</div>
                          <div className="text-xs text-muted-foreground">Real-time code analysis and metrics</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <Database className="h-5 w-5 text-green-600" />
                        <div>
                          <div className="font-medium text-sm">Architecture Mapping</div>
                          <div className="text-xs text-muted-foreground">Interactive system visualization</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <Shield className="h-5 w-5 text-red-600" />
                        <div>
                          <div className="font-medium text-sm">Security Scanner</div>
                          <div className="text-xs text-muted-foreground">Live vulnerability assessment</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <TrendingUp className="h-5 w-5 text-purple-600" />
                        <div>
                          <div className="font-medium text-sm">Performance Monitor</div>
                          <div className="text-xs text-muted-foreground">Real-time performance tracking</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="font-medium">Features</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Real-time analysis and updates</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Interactive visualizations</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Drill-down capabilities</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Export and sharing options</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Customizable dashboards</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Integration with CI/CD pipelines</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-muted/30 rounded-lg">
                  <h4 className="font-medium mb-2">Demo Environment</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    Explore our analysis tools with pre-loaded sample data from a production SaaS platform. 
                    All tools are fully interactive and demonstrate real-world scenarios.
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center text-sm">
                    <div>
                      <div className="font-medium">312</div>
                      <div className="text-muted-foreground">Components</div>
                    </div>
                    <div>
                      <div className="font-medium">96k</div>
                      <div className="text-muted-foreground">Lines of Code</div>
                    </div>
                    <div>
                      <div className="font-medium">47</div>
                      <div className="text-muted-foreground">Security Issues</div>
                    </div>
                    <div>
                      <div className="font-medium">89</div>
                      <div className="text-muted-foreground">Dependencies</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <Button onClick={handleOpenTools} size="lg" className="w-full group">
                    <Zap className="h-4 w-4 mr-2" />
                    Launch Interactive Tools
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                  <Button onClick={handleOpenAdvancedTools} variant="outline" size="lg" className="w-full group">
                    <Settings className="h-4 w-4 mr-2" />
                    Advanced Analysis Suite
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                  {onOpenAnalysis && (
                    <Button 
                      onClick={onOpenAnalysis} 
                      variant="default" 
                      size="lg" 
                      className="w-full group bg-purple-600 hover:bg-purple-700"
                    >
                      <Code className="h-4 w-4 mr-2" />
                      Start Real AI Analysis
                      <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="connect" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Github className="h-5 w-5 mr-2" />
                    Connect Repository
                  </CardTitle>
                  <CardDescription>
                    Analyze your own SaaS platform with Systems Flow
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-3 gap-3">
                    <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                      <Github className="h-6 w-6" />
                      <span className="text-xs">GitHub</span>
                    </Button>
                    <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                      <GitLab className="h-6 w-6" />
                      <span className="text-xs">GitLab</span>
                    </Button>
                    <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                      <Upload className="h-6 w-6" />
                      <span className="text-xs">Upload</span>
                    </Button>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="repo-url">Repository URL</Label>
                      <Input 
                        id="repo-url"
                        placeholder="https://github.com/company/repo-name"
                        value={selectedRepo}
                        onChange={(e) => setSelectedRepo(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="access-token">Access Token (Optional)</Label>
                      <Input 
                        id="access-token"
                        type="password"
                        placeholder="ghp_xxxxxxxxxxxx"
                      />
                    </div>

                    <div>
                      <Label htmlFor="analysis-focus">Analysis Focus</Label>
                      <Textarea 
                        id="analysis-focus"
                        placeholder="Describe specific areas you'd like us to focus on (e.g., security, performance, scalability concerns)"
                        rows={3}
                      />
                    </div>
                  </div>

                  <Button 
                    className="w-full" 
                    disabled={!selectedRepo}
                    onClick={handleStartAnalysis}
                  >
                    Start Analysis
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>

                  <div className="text-xs text-muted-foreground space-y-1">
                    <p>• Analysis typically takes 15-45 minutes depending on codebase size</p>
                    <p>• We analyze code structure, not content - your IP stays private</p>
                    <p>• Read-only access required, no modifications made</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>What We Analyze</CardTitle>
                  <CardDescription>
                    Comprehensive insights across all critical dimensions
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <div>
                        <div className="font-medium text-sm">Architecture Mapping</div>
                        <div className="text-xs text-muted-foreground">Component relationships, dependencies, and system boundaries</div>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                      <div>
                        <div className="font-medium text-sm">Security Assessment</div>
                        <div className="text-xs text-muted-foreground">Vulnerability scanning, compliance checks, and risk analysis</div>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                      <div>
                        <div className="font-medium text-sm">Performance Intelligence</div>
                        <div className="text-xs text-muted-foreground">Bottleneck identification and optimization opportunities</div>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
                      <div>
                        <div className="font-medium text-sm">Technical Debt</div>
                        <div className="text-xs text-muted-foreground">Code quality issues and remediation roadmap</div>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-purple-500 rounded-full mt-2"></div>
                      <div>
                        <div className="font-medium text-sm">Team Knowledge</div>
                        <div className="text-xs text-muted-foreground">Contributor analysis and knowledge transfer planning</div>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mt-2"></div>
                      <div>
                        <div className="font-medium text-sm">Data Flow Analysis</div>
                        <div className="text-xs text-muted-foreground">Information flow mapping and privacy compliance</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-8 text-center">
          <Button variant="ghost" onClick={onBack}>
            ← Back to Homepage
          </Button>
        </div>
      </div>
    </div>
  )
}