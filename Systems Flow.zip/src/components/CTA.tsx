import { Button } from "./ui/button"
import { ArrowRight, CheckCircle } from "lucide-react"

interface CTAProps {
  onStartDemo?: () => void
}

export function CTA({ onStartDemo }: CTAProps) {
  return (
    <section className="py-20 bg-primary text-primary-foreground">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h2 className="text-3xl lg:text-5xl">
                Ready to understand any SaaS in minutes?
              </h2>
              <p className="text-xl opacity-90">
                Join leading investors and SaaS founders who trust Systems Flow for instant, automated architecture analysis.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div className="flex flex-col items-center space-y-2">
                <CheckCircle className="h-6 w-6 text-green-400" />
                <span>Analysis complete in under 5 minutes</span>
              </div>
              <div className="flex flex-col items-center space-y-2">
                <CheckCircle className="h-6 w-6 text-green-400" />
                <span>90% cheaper than enterprise alternatives</span>
              </div>
              <div className="flex flex-col items-center space-y-2">
                <CheckCircle className="h-6 w-6 text-green-400" />
                <span>No setup, no consultants required</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" className="group" onClick={onStartDemo}>
                Start Free Analysis
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button size="lg" variant="outline" className="border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground hover:text-primary" onClick={onStartDemo}>
                View Sample Report
              </Button>
            </div>

            <p className="text-sm opacity-75">
              Questions? Email us at hello@systemsflow.app or call (555) 123-4567
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}