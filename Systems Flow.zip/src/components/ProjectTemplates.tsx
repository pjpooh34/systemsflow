import { useState } from 'react'
import { Button } from './ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Badge } from './ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog'
import { Input } from './ui/input'
import { Textarea } from './ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { ArrowLeft, Plus, Code, Database, Globe, Smartphone, Server, Cloud, GitBranch, Zap } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { analysisService } from '../services/analysisService'
import { toast } from 'sonner@2.0.3'

interface ProjectTemplatesProps {
  onBack: () => void
  onProjectCreated: () => void
}

interface ProjectTemplate {
  id: string
  name: string
  description: string
  icon: any
  type: string
  category: string
  tags: string[]
  sampleCodebase: string
  complexity: 'Simple' | 'Moderate' | 'Complex'
  estimatedAnalysisTime: string
}

export function ProjectTemplates({ onBack, onProjectCreated }: ProjectTemplatesProps) {
  const { token } = useAuth()
  const [selectedTemplate, setSelectedTemplate] = useState<ProjectTemplate | null>(null)
  const [projectName, setProjectName] = useState('')
  const [projectDescription, setProjectDescription] = useState('')
  const [customCodebase, setCustomCodebase] = useState('')
  const [loading, setLoading] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)

  const templates: ProjectTemplate[] = [
    {
      id: 'react-spa',
      name: 'React SPA',
      description: 'Single Page Application built with React, TypeScript, and modern tooling',
      icon: Globe,
      type: 'web',
      category: 'Frontend',
      tags: ['React', 'TypeScript', 'SPA', 'Frontend'],
      complexity: 'Simple',
      estimatedAnalysisTime: '5-10 minutes',
      sampleCodebase: `
// React SPA Sample
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Dashboard from './components/Dashboard';
import Login from './components/Login';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
      `
    },
    {
      id: 'nodejs-api',
      name: 'Node.js REST API',
      description: 'RESTful API service with Express, TypeScript, and database integration',
      icon: Server,
      type: 'backend',
      category: 'Backend',
      tags: ['Node.js', 'Express', 'REST API', 'TypeScript'],
      complexity: 'Moderate',
      estimatedAnalysisTime: '10-15 minutes',
      sampleCodebase: `
// Node.js API Sample
import express from 'express';
import cors from 'cors';
import { createConnection } from 'typeorm';
import userRoutes from './routes/users';
import authMiddleware from './middleware/auth';

const app = express();

app.use(cors());
app.use(express.json());
app.use('/api/users', authMiddleware, userRoutes);

createConnection().then(() => {
  app.listen(3000, () => console.log('Server running on port 3000'));
});
      `
    },
    {
      id: 'microservices',
      name: 'Microservices Architecture',
      description: 'Distributed system with multiple services, API gateway, and service mesh',
      icon: Cloud,
      type: 'distributed',
      category: 'Architecture',
      tags: ['Microservices', 'Docker', 'Kubernetes', 'API Gateway'],
      complexity: 'Complex',
      estimatedAnalysisTime: '20-30 minutes',
      sampleCodebase: `
// Microservices Sample
// User Service
const userService = {
  async getUser(id) {
    return await userRepository.findById(id);
  },
  async createUser(userData) {
    return await userRepository.create(userData);
  }
};

// Order Service  
const orderService = {
  async createOrder(orderData) {
    const user = await userService.getUser(orderData.userId);
    return await orderRepository.create(orderData);
  }
};

// API Gateway
const gateway = express();
gateway.use('/users', proxy('http://user-service:3001'));
gateway.use('/orders', proxy('http://order-service:3002'));
      `
    },
    {
      id: 'mobile-app',
      name: 'React Native Mobile App',
      description: 'Cross-platform mobile application with native functionality',
      icon: Smartphone,
      type: 'mobile',
      category: 'Mobile',
      tags: ['React Native', 'Mobile', 'Cross-platform', 'TypeScript'],
      complexity: 'Moderate',
      estimatedAnalysisTime: '15-20 minutes',
      sampleCodebase: `
// React Native Sample
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Provider } from 'react-redux';
import store from './store';
import HomeScreen from './screens/HomeScreen';
import ProfileScreen from './screens/ProfileScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <Provider store={store}>
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="Profile" component={ProfileScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </Provider>
  );
}
      `
    },
    {
      id: 'database-heavy',
      name: 'Database-Heavy Application',
      description: 'Data-intensive application with complex database operations and analytics',
      icon: Database,
      type: 'data',
      category: 'Data',
      tags: ['Database', 'Analytics', 'ETL', 'SQL'],
      complexity: 'Complex',
      estimatedAnalysisTime: '15-25 minutes',
      sampleCodebase: `
// Database-Heavy Sample
class AnalyticsService {
  async generateReport(filters) {
    const query = this.buildComplexQuery(filters);
    const results = await this.database.execute(query);
    return this.processResults(results);
  }

  buildComplexQuery(filters) {
    return \`
      SELECT u.id, u.name, 
             COUNT(o.id) as order_count,
             SUM(o.total) as revenue
      FROM users u
      LEFT JOIN orders o ON u.id = o.user_id
      WHERE o.created_at BETWEEN ? AND ?
      GROUP BY u.id
      HAVING revenue > 1000
      ORDER BY revenue DESC
    \`;
  }
}
      `
    },
    {
      id: 'legacy-system',
      name: 'Legacy System Modernization',
      description: 'Older codebase requiring modernization and technical debt analysis',
      icon: GitBranch,
      type: 'legacy',
      category: 'Legacy',
      tags: ['Legacy', 'Modernization', 'Technical Debt', 'Refactoring'],
      complexity: 'Complex',
      estimatedAnalysisTime: '25-35 minutes',
      sampleCodebase: `
// Legacy System Sample
// Old PHP codebase with mixed concerns
<?php
// user_management.php
if ($_POST['action'] == 'create_user') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    
    // Direct database connection (no abstraction)
    $conn = mysql_connect("localhost", "user", "pass");
    mysql_select_db("mydb");
    
    // No validation or sanitization
    $query = "INSERT INTO users (name, email) VALUES ('$name', '$email')";
    mysql_query($query);
    
    // Mixed HTML and PHP
    echo "<h1>User created successfully!</h1>";
}
?>
      `
    },
    {
      id: 'high-performance',
      name: 'High-Performance System',
      description: 'Performance-critical application with optimization requirements',
      icon: Zap,
      type: 'performance',
      category: 'Performance',
      tags: ['Performance', 'Optimization', 'Caching', 'Scaling'],
      complexity: 'Complex',
      estimatedAnalysisTime: '20-30 minutes',
      sampleCodebase: `
// High-Performance Sample
class CacheService {
  constructor() {
    this.redisClient = new Redis();
    this.memoryCache = new LRUCache({ max: 1000 });
  }

  async get(key) {
    // Multi-level caching strategy
    let value = this.memoryCache.get(key);
    if (value) return value;

    value = await this.redisClient.get(key);
    if (value) {
      this.memoryCache.set(key, value);
      return value;
    }

    return null;
  }

  async batchProcess(items) {
    // Batch processing for efficiency
    const chunks = this.chunkArray(items, 100);
    const results = await Promise.all(
      chunks.map(chunk => this.processChunk(chunk))
    );
    return results.flat();
  }
}
      `
    },
    {
      id: 'startup-mvp',
      name: 'Startup MVP',
      description: 'Minimum viable product for rapid development and validation',
      icon: Code,
      type: 'mvp',
      category: 'Startup',
      tags: ['MVP', 'Rapid Development', 'Startup', 'Validation'],
      complexity: 'Simple',
      estimatedAnalysisTime: '5-15 minutes',
      sampleCodebase: `
// Startup MVP Sample
const express = require('express');
const app = express();

// Simple CRUD operations
app.get('/api/products', async (req, res) => {
  const products = await Product.findAll();
  res.json(products);
});

app.post('/api/products', async (req, res) => {
  const product = await Product.create(req.body);
  res.json(product);
});

// Basic auth
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ where: { email } });
  if (user && bcrypt.compare(password, user.password)) {
    const token = jwt.sign({ id: user.id }, 'secret');
    res.json({ token });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});
      `
    }
  ]

  const createProject = async () => {
    if (!projectName.trim()) {
      toast.error('Please enter a project name')
      return
    }

    if (!selectedTemplate) {
      toast.error('Please select a template')
      return
    }

    setLoading(true)
    try {
      const codebase = customCodebase.trim() || selectedTemplate.sampleCodebase
      
      await analysisService.createProject(token!, {
        name: projectName,
        description: projectDescription || selectedTemplate.description,
        type: selectedTemplate.type,
        codebase
      })

      toast.success('Project created successfully!')
      setDialogOpen(false)
      setProjectName('')
      setProjectDescription('')
      setCustomCodebase('')
      setSelectedTemplate(null)
      onProjectCreated()
    } catch (error) {
      console.error('Error creating project:', error)
      toast.error('Failed to create project')
    } finally {
      setLoading(false)
    }
  }

  const getComplexityColor = (complexity: string) => {
    switch (complexity) {
      case 'Simple': return 'bg-green-100 text-green-800'
      case 'Moderate': return 'bg-yellow-100 text-yellow-800'
      case 'Complex': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const categories = [...new Set(templates.map(t => t.category))]

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" onClick={onBack} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
          <div>
            <h1 className="text-3xl font-bold">Project Templates</h1>
            <p className="text-muted-foreground">Quick start with pre-configured project templates</p>
          </div>
        </div>

        <div className="space-y-8">
          {categories.map(category => {
            const categoryTemplates = templates.filter(t => t.category === category)
            return (
              <div key={category} className="space-y-4">
                <h2 className="text-xl font-semibold">{category}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {categoryTemplates.map((template) => {
                    const Icon = template.icon
                    return (
                      <Card key={template.id} className="cursor-pointer hover:shadow-lg transition-shadow">
                        <CardHeader>
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-primary/10 rounded-lg">
                              <Icon className="h-6 w-6 text-primary" />
                            </div>
                            <div>
                              <CardTitle className="text-lg">{template.name}</CardTitle>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline" className={getComplexityColor(template.complexity)}>
                                  {template.complexity}
                                </Badge>
                                <span className="text-xs text-muted-foreground">
                                  {template.estimatedAnalysisTime}
                                </span>
                              </div>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <CardDescription className="text-sm">
                            {template.description}
                          </CardDescription>
                          <div className="flex flex-wrap gap-1">
                            {template.tags.map((tag) => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                          <Dialog open={dialogOpen && selectedTemplate?.id === template.id} onOpenChange={setDialogOpen}>
                            <DialogTrigger asChild>
                              <Button 
                                className="w-full" 
                                onClick={() => {
                                  setSelectedTemplate(template)
                                  setProjectName(template.name)
                                  setProjectDescription(template.description)
                                }}
                              >
                                <Plus className="h-4 w-4 mr-2" />
                                Use Template
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                              <DialogHeader>
                                <DialogTitle>Create Project from Template</DialogTitle>
                                <DialogDescription>
                                  Configure your new project based on the {template.name} template
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-6">
                                <div className="space-y-2">
                                  <label className="text-sm font-medium">Project Name</label>
                                  <Input
                                    value={projectName}
                                    onChange={(e) => setProjectName(e.target.value)}
                                    placeholder="Enter project name"
                                  />
                                </div>

                                <div className="space-y-2">
                                  <label className="text-sm font-medium">Description</label>
                                  <Textarea
                                    value={projectDescription}
                                    onChange={(e) => setProjectDescription(e.target.value)}
                                    placeholder="Project description (optional)"
                                    rows={3}
                                  />
                                </div>

                                <div className="space-y-2">
                                  <label className="text-sm font-medium">Codebase</label>
                                  <Textarea
                                    value={customCodebase}
                                    onChange={(e) => setCustomCodebase(e.target.value)}
                                    placeholder="Paste your own codebase or use the template sample..."
                                    rows={8}
                                    className="font-mono text-sm"
                                  />
                                  <p className="text-xs text-muted-foreground">
                                    Leave empty to use the template's sample codebase
                                  </p>
                                </div>

                                <div className="space-y-2">
                                  <label className="text-sm font-medium">Template Preview</label>
                                  <div className="p-4 bg-muted rounded-lg">
                                    <pre className="text-xs overflow-x-auto whitespace-pre-wrap">
                                      {template.sampleCodebase.trim()}
                                    </pre>
                                  </div>
                                </div>

                                <div className="flex justify-end gap-3">
                                  <Button
                                    variant="outline"
                                    onClick={() => setDialogOpen(false)}
                                  >
                                    Cancel
                                  </Button>
                                  <Button
                                    onClick={createProject}
                                    disabled={loading || !projectName.trim()}
                                  >
                                    {loading ? 'Creating...' : 'Create Project'}
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}