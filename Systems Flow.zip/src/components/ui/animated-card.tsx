import { motion } from 'motion/react'
import { ReactNode } from 'react'
import { cn } from '../../lib/utils'

interface AnimatedCardProps {
  children: ReactNode
  className?: string
  hoverScale?: boolean
  fadeIn?: boolean
  slideIn?: 'left' | 'right' | 'up' | 'down'
  delay?: number
  duration?: number
  onClick?: () => void
}

export function AnimatedCard({
  children,
  className,
  hoverScale = false,
  fadeIn = false,
  slideIn,
  delay = 0,
  duration = 0.3,
  onClick
}: AnimatedCardProps) {
  let initial = {}
  let animate = {}

  if (fadeIn) {
    initial = { opacity: 0 }
    animate = { opacity: 1 }
  }

  if (slideIn) {
    const directions = {
      left: { x: -50 },
      right: { x: 50 },
      up: { y: -50 },
      down: { y: 50 }
    }
    initial = { ...initial, ...directions[slideIn] }
    animate = { ...animate, x: 0, y: 0 }
  }

  const hoverAnimation = hoverScale ? { scale: 1.02 } : {}

  return (
    <motion.div
      className={cn(
        'rounded-lg border bg-card text-card-foreground shadow-sm',
        onClick && 'cursor-pointer',
        className
      )}
      initial={initial}
      animate={animate}
      whileHover={hoverAnimation}
      whileTap={onClick ? { scale: 0.98 } : {}}
      transition={{ duration, delay, ease: 'easeOut' }}
      onClick={onClick}
    >
      {children}
    </motion.div>
  )
}

export function StaggeredCards({
  children,
  className,
  staggerDelay = 0.1
}: {
  children: ReactNode[]
  className?: string
  staggerDelay?: number
}) {
  return (
    <div className={className}>
      {children.map((child, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.4,
            delay: index * staggerDelay,
            ease: 'easeOut'
          }}
        >
          {child}
        </motion.div>
      ))}
    </div>
  )
}