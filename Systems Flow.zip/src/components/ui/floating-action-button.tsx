import { motion, AnimatePresence } from 'motion/react'
import { useState, ReactNode } from 'react'
import { Button } from './button'
import { Plus, X } from 'lucide-react'
import { cn } from '../../lib/utils'

interface FloatingActionButtonProps {
  children?: ReactNode
  actions?: Array<{
    icon: ReactNode
    label: string
    onClick: () => void
    color?: string
  }>
  className?: string
}

export function FloatingActionButton({ 
  children, 
  actions = [], 
  className 
}: FloatingActionButtonProps) {
  const [isOpen, setIsOpen] = useState(false)

  if (children) {
    return (
      <motion.div
        className={cn(
          'fixed bottom-6 right-6 z-50',
          className
        )}
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 20 }}
      >
        {children}
      </motion.div>
    )
  }

  return (
    <div className={cn('fixed bottom-6 right-6 z-50', className)}>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="absolute bottom-16 right-0 space-y-3"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ type: 'spring', stiffness: 400, damping: 30 }}
          >
            {actions.map((action, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.05 }}
              >
                <Button
                  size="sm"
                  onClick={() => {
                    action.onClick()
                    setIsOpen(false)
                  }}
                  className={cn(
                    'shadow-lg min-w-0 px-3',
                    action.color || 'bg-primary hover:bg-primary/90'
                  )}
                >
                  <span className="flex items-center gap-2">
                    {action.icon}
                    <span className="text-xs">{action.label}</span>
                  </span>
                </Button>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Button
          size="lg"
          onClick={() => setIsOpen(!isOpen)}
          className="h-14 w-14 rounded-full shadow-lg"
        >
          <motion.div
            animate={{ rotate: isOpen ? 45 : 0 }}
            transition={{ duration: 0.2 }}
          >
            {isOpen ? <X className="h-6 w-6" /> : <Plus className="h-6 w-6" />}
          </motion.div>
        </Button>
      </motion.div>
    </div>
  )
}