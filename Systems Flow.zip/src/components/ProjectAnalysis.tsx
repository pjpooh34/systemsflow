import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { Progress } from './ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Textarea } from './ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { Alert, AlertDescription, AlertTitle } from './ui/alert'
import { ScrollArea } from './ui/scroll-area'
import { Separator } from './ui/separator'
import { LoadingSpinner } from './ui/loading-spinner'
import { AnimatedCard, StaggeredCards } from './ui/animated-card'
import { FloatingActionButton } from './ui/floating-action-button'
import { motion, AnimatePresence } from 'motion/react'
import { useAuth } from '../contexts/AuthContext'
import { analysisService, type Project } from '../services/analysisService'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar
} from 'recharts'
import {
  Plus, Upload, Play, CheckCircle, AlertTriangle, Clock, Eye, Download, Share,
  Code, Shield, TrendingUp, Database, Layers, Activity, FileText, Zap,
  GitBranch, Bug, Award, Target, Users, Settings
} from 'lucide-react'

interface ProjectAnalysisProps {
  onBack: () => void
}

export function ProjectAnalysis({ onBack }: ProjectAnalysisProps) {
  const { user, session } = useAuth()
  const [activeTab, setActiveTab] = useState('projects')
  const [projects, setProjects] = useState<Project[]>([])
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [analysisResults, setAnalysisResults] = useState<any>(null)
  const [analysisLoading, setAnalysisLoading] = useState(false)

  // New project form state
  const [newProject, setNewProject] = useState({
    name: '',
    description: '',
    type: 'Core Report',
    codebase: ''
  })

  useEffect(() => {
    if (session?.access_token) {
      loadProjects()
    }
  }, [session])

  const loadProjects = async () => {
    if (!session?.access_token) return

    try {
      setLoading(true)
      const result = await analysisService.getProjects(session.access_token)
      setProjects(result.projects)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load projects')
    } finally {
      setLoading(false)
    }
  }

  const createProject = async () => {
    if (!session?.access_token) return

    try {
      setLoading(true)
      setError(null)

      if (!newProject.name.trim()) {
        setError('Project name is required')
        return
      }

      const result = await analysisService.createProject(session.access_token, newProject)
      setProjects([result.project, ...projects])
      setNewProject({ name: '', description: '', type: 'Core Report', codebase: '' })
      setActiveTab('projects')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create project')
    } finally {
      setLoading(false)
    }
  }

  const runAnalysis = async (project: Project, analysisType: string) => {
    if (!session?.access_token) return

    try {
      setAnalysisLoading(true)
      setError(null)

      let result
      switch (analysisType) {
        case 'comprehensive':
          if (!project.codebase) {
            setError('Codebase is required for analysis')
            return
          }
          result = await analysisService.runComprehensiveAnalysis(session.access_token, project.id, project.codebase)
          break
        case 'codebase':
          result = await analysisService.analyzeCodebase(session.access_token, project.id, project.codebase || '')
          break
        case 'architecture':
          result = await analysisService.analyzeArchitecture(session.access_token, project.id)
          break
        case 'security':
          result = await analysisService.analyzeSecurity(session.access_token, project.id)
          break
        case 'performance':
          result = await analysisService.analyzePerformance(session.access_token, project.id)
          break
        case 'technical-debt':
          result = await analysisService.analyzeTechnicalDebt(session.access_token, project.id)
          break
        default:
          throw new Error('Unknown analysis type')
      }

      setAnalysisResults(result.analysis)
      setSelectedProject(project)
      setActiveTab('results')
      
      // Refresh projects to update status
      await loadProjects()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Analysis failed')
    } finally {
      setAnalysisLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-50 text-green-700'
      case 'analyzing': case 'comprehensive_analysis': return 'bg-blue-50 text-blue-700' 
      case 'initializing': return 'bg-yellow-50 text-yellow-700'
      case 'failed': return 'bg-red-50 text-red-700'
      default: return 'bg-gray-50 text-gray-700'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-600" />
      case 'analyzing': case 'comprehensive_analysis': return <Activity className="h-4 w-4 text-blue-600 animate-spin" />
      case 'initializing': return <Clock className="h-4 w-4 text-yellow-600" />
      case 'failed': return <AlertTriangle className="h-4 w-4 text-red-600" />
      default: return <Clock className="h-4 w-4 text-gray-600" />
    }
  }

  const renderAnalysisResults = () => {
    if (!analysisResults) return null

    if (analysisResults.codebase) {
      // Comprehensive analysis results
      return (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Overall Score</p>
                    <p className="text-2xl font-bold">{analysisResults.codebase.score || 'N/A'}/10</p>
                  </div>
                  <Award className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Security Score</p>
                    <p className="text-2xl font-bold">{analysisResults.security?.securityScore || 'N/A'}/10</p>
                  </div>
                  <Shield className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Performance</p>
                    <p className="text-2xl font-bold">{analysisResults.performance?.performanceScore || 'N/A'}/10</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Tech Debt</p>
                    <p className="text-2xl font-bold">${Math.round((analysisResults['technical-debt']?.totalDebtCost || 0) / 1000)}K</p>
                  </div>
                  <Bug className="h-8 w-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="architecture">Architecture</TabsTrigger>
              <TabsTrigger value="debt">Tech Debt</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Codebase Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  {analysisResults.codebase?.overview && (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Language</p>
                        <p className="font-medium">{analysisResults.codebase.overview.language}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Framework</p>
                        <p className="font-medium">{analysisResults.codebase.overview.framework}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Architecture</p>
                        <p className="font-medium">{analysisResults.codebase.overview.architecture}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Complexity</p>
                        <p className="font-medium">{analysisResults.codebase.overview.complexity}/10</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {analysisResults.codebase?.recommendations && (
                <Card>
                  <CardHeader>
                    <CardTitle>Key Recommendations</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {analysisResults.codebase.recommendations.slice(0, 5).map((rec: string, idx: number) => (
                        <div key={idx} className="flex items-start space-x-2">
                          <Target className="h-4 w-4 mt-0.5 text-blue-600 flex-shrink-0" />
                          <p className="text-sm">{rec}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="security" className="space-y-4">
              {analysisResults.security?.vulnerabilities && (
                <Card>
                  <CardHeader>
                    <CardTitle>Security Vulnerabilities</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {analysisResults.security.vulnerabilities.slice(0, 10).map((vuln: any, idx: number) => (
                        <div key={idx} className="p-3 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium">{vuln.type}</span>
                            <Badge variant="outline" className={
                              vuln.severity === 'critical' ? 'bg-red-100 text-red-800' :
                              vuln.severity === 'high' ? 'bg-orange-100 text-orange-800' :
                              vuln.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-green-100 text-green-800'
                            }>
                              {vuln.severity}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">{vuln.description}</p>
                          <p className="text-sm"><strong>Fix:</strong> {vuln.recommendation}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="performance" className="space-y-4">
              {analysisResults.performance?.bottlenecks && (
                <Card>
                  <CardHeader>
                    <CardTitle>Performance Bottlenecks</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {analysisResults.performance.bottlenecks.slice(0, 8).map((bottleneck: any, idx: number) => (
                        <div key={idx} className="p-3 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium">{bottleneck.component}</span>
                            <Badge variant="outline" className={
                              bottleneck.severity === 'critical' ? 'bg-red-100 text-red-800' :
                              bottleneck.severity === 'high' ? 'bg-orange-100 text-orange-800' :
                              bottleneck.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-green-100 text-green-800'
                            }>
                              {bottleneck.severity}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">{bottleneck.description}</p>
                          <p className="text-sm"><strong>Recommendation:</strong> {bottleneck.recommendation}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="architecture" className="space-y-4">
              {analysisResults.architecture && (
                <Card>
                  <CardHeader>
                    <CardTitle>Architecture Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Architecture Pattern</p>
                        <p className="font-medium">{analysisResults.architecture.architecturePattern}</p>
                      </div>
                      
                      {analysisResults.architecture.layers && (
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">Layers</p>
                          <div className="space-y-2">
                            {analysisResults.architecture.layers.map((layer: any, idx: number) => (
                              <div key={idx} className="p-2 border rounded">
                                <div className="font-medium text-sm">{layer.name}</div>
                                <div className="text-xs text-muted-foreground">
                                  {layer.components} components • Complexity: {layer.complexity}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="debt" className="space-y-4">
              {analysisResults['technical-debt'] && (
                <Card>
                  <CardHeader>
                    <CardTitle>Technical Debt Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {analysisResults['technical-debt'].debtCategories && (
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">Debt Categories</p>
                          <div className="space-y-2">
                            {analysisResults['technical-debt'].debtCategories.map((category: any, idx: number) => (
                              <div key={idx} className="p-3 border rounded">
                                <div className="flex items-center justify-between mb-2">
                                  <span className="font-medium">{category.category}</span>
                                  <Badge variant="outline" className={
                                    category.severity === 'critical' ? 'bg-red-100 text-red-800' :
                                    category.severity === 'high' ? 'bg-orange-100 text-orange-800' :
                                    category.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                    'bg-green-100 text-green-800'
                                  }>
                                    {category.severity}
                                  </Badge>
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  Cost: ${category.cost?.toLocaleString()} • Time: {category.timeToFix}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      )
    }

    // Single analysis type results
    return (
      <Card>
        <CardHeader>
          <CardTitle>Analysis Results</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="text-sm bg-muted p-4 rounded overflow-auto max-h-96">
            {JSON.stringify(analysisResults, null, 2)}
          </pre>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              ← Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold">Project Analysis</h1>
              <p className="text-muted-foreground">
                Create projects and run comprehensive AI-powered analysis
              </p>
            </div>
          </div>
          <Badge variant="outline" className="bg-purple-50 text-purple-700">
            {analysisService.getUserSubscription()}
          </Badge>
        </motion.div>

        {error && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <Alert className="mb-6">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          </motion.div>
        )}

        {loading && (
          <motion.div
            className="mb-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <LoadingSpinner size="lg" text="Processing your analysis..." />
          </motion.div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="new-project">New Project</TabsTrigger>
            <TabsTrigger value="results">Analysis Results</TabsTrigger>
          </TabsList>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium">Your Projects</h3>
                <p className="text-sm text-muted-foreground">Manage and analyze your projects</p>
              </div>
              <Button onClick={() => setActiveTab('new-project')}>
                <Plus className="h-4 w-4 mr-2" />
                New Project
              </Button>
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : projects.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No projects yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Create your first project to start analyzing your codebase
                  </p>
                  <Button onClick={() => setActiveTab('new-project')}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Project
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6">
                {projects.map((project) => (
                  <Card key={project.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h4 className="font-medium">{project.name}</h4>
                          <p className="text-sm text-muted-foreground">{project.description}</p>
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge variant="outline" className={getStatusColor(project.status)}>
                              {getStatusIcon(project.status)}
                              <span className="ml-1">{project.status.replace('_', ' ')}</span>
                            </Badge>
                            <Badge variant="outline">{project.type}</Badge>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {project.status === 'completed' && project.comprehensiveAnalysisId && (
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                // Load existing analysis results
                                setSelectedProject(project)
                                setActiveTab('results')
                              }}
                            >
                              <Eye className="h-4 w-4 mr-2" />
                              View Results
                            </Button>
                          )}
                          <Button 
                            size="sm" 
                            onClick={() => runAnalysis(project, 'comprehensive')}
                            disabled={analysisLoading || !project.codebase}
                          >
                            {analysisLoading ? (
                              <Activity className="h-4 w-4 mr-2 animate-spin" />
                            ) : (
                              <Play className="h-4 w-4 mr-2" />
                            )}
                            Analyze
                          </Button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Created</p>
                          <p>{new Date(project.createdAt).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Last Analysis</p>
                          <p>{project.lastAnalysis ? new Date(project.lastAnalysis).toLocaleDateString() : 'Never'}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Codebase</p>
                          <p>{project.codebase ? 'Provided' : 'Not provided'}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Status</p>
                          <p className="capitalize">{project.status.replace('_', ' ')}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* New Project Tab */}
          <TabsContent value="new-project" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Create New Project</CardTitle>
                <CardDescription>
                  Set up a new project for comprehensive analysis
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="project-name">Project Name *</Label>
                    <Input
                      id="project-name"
                      value={newProject.name}
                      onChange={(e) => setNewProject({...newProject, name: e.target.value})}
                      placeholder="Enter project name"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="project-type">Analysis Type</Label>
                    <Select value={newProject.type} onValueChange={(value) => setNewProject({...newProject, type: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Core Report">Core Report ($299)</SelectItem>
                        <SelectItem value="Pro Report">Pro Report ($699)</SelectItem>
                        <SelectItem value="Portfolio">Portfolio ($999+)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="project-description">Description</Label>
                  <Input
                    id="project-description"
                    value={newProject.description}
                    onChange={(e) => setNewProject({...newProject, description: e.target.value})}
                    placeholder="Brief description of the project"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="codebase">Codebase *</Label>
                  <Textarea
                    id="codebase"
                    value={newProject.codebase}
                    onChange={(e) => setNewProject({...newProject, codebase: e.target.value})}
                    placeholder="Paste your codebase here or provide a description of the system to analyze..."
                    rows={10}
                    className="font-mono text-sm"
                  />
                  <p className="text-sm text-muted-foreground">
                    For best results, include key source files, architecture diagrams, or detailed system descriptions.
                  </p>
                </div>

                <div className="flex items-center space-x-4">
                  <Button 
                    onClick={createProject} 
                    disabled={loading || !newProject.name.trim()}
                  >
                    {loading ? (
                      <Activity className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Plus className="h-4 w-4 mr-2" />
                    )}
                    Create Project
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => setActiveTab('projects')}
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Results Tab */}
          <TabsContent value="results" className="space-y-6">
            {selectedProject ? (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-lg font-medium">Analysis Results</h3>
                    <p className="text-sm text-muted-foreground">
                      {selectedProject.name} • {selectedProject.type}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share className="h-4 w-4 mr-2" />
                      Share
                    </Button>
                  </div>
                </div>
                {renderAnalysisResults()}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <Activity className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No analysis selected</h3>
                  <p className="text-muted-foreground">
                    Run an analysis on a project to view results here
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}