import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { Separator } from './ui/separator'
import { Alert, AlertDescription } from './ui/alert'
import { 
  CreditCard, 
  Calendar, 
  AlertCircle, 
  ExternalLink,
  CheckCircle,
  XCircle,
  Clock,
  Download
} from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { paymentService, PaymentStatus } from '../services/paymentService'
import { toast } from 'sonner'

export function BillingDashboard() {
  const { user, getAccessToken } = useAuth()
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus | null>(null)
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      loadPaymentStatus()
    }
  }, [user])

  const loadPaymentStatus = async () => {
    if (!user) return

    try {
      const token = await getAccessToken()
      if (!token) return

      const status = await paymentService.getPaymentStatus(token)
      setPaymentStatus(status)
    } catch (error) {
      console.error('Error loading payment status:', error)
      toast.error('Failed to load billing information')
    } finally {
      setLoading(false)
    }
  }

  const handleCancelSubscription = async () => {
    if (!paymentStatus?.subscription || !user) return

    setActionLoading('cancel')
    try {
      const token = await getAccessToken()
      if (!token) return

      await paymentService.cancelSubscription(paymentStatus.subscription.subscriptionId, token)
      toast.success('Subscription canceled successfully')
      await loadPaymentStatus()
    } catch (error) {
      console.error('Error canceling subscription:', error)
      toast.error('Failed to cancel subscription')
    } finally {
      setActionLoading(null)
    }
  }

  const handleManageBilling = async () => {
    if (!user) return

    setActionLoading('portal')
    try {
      const token = await getAccessToken()
      if (!token) return

      const { url } = await paymentService.createPortalSession(
        window.location.origin + '/dashboard',
        token
      )
      
      window.open(url, '_blank')
    } catch (error) {
      console.error('Error creating portal session:', error)
      toast.error('Failed to open billing portal')
    } finally {
      setActionLoading(null)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="h-3 w-3 mr-1" />Active</Badge>
      case 'canceled':
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Canceled</Badge>
      case 'past_due':
        return <Badge variant="secondary"><AlertCircle className="h-3 w-3 mr-1" />Past Due</Badge>
      case 'incomplete':
        return <Badge variant="outline"><Clock className="h-3 w-3 mr-1" />Incomplete</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    })
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount / 100)
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[1, 2].map((i) => (
            <Card key={i}>
              <CardHeader>
                <div className="h-4 bg-muted animate-pulse rounded w-1/3"></div>
                <div className="h-6 bg-muted animate-pulse rounded w-2/3"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-4 bg-muted animate-pulse rounded"></div>
                  <div className="h-4 bg-muted animate-pulse rounded w-3/4"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  if (!paymentStatus) {
    return (
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Failed to load billing information. Please try again.
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Billing & Subscriptions</h2>
          <p className="text-muted-foreground">Manage your payments and subscription</p>
        </div>
        <Button 
          onClick={handleManageBilling}
          disabled={actionLoading === 'portal'}
          variant="outline"
        >
          <ExternalLink className="h-4 w-4 mr-2" />
          {actionLoading === 'portal' ? 'Loading...' : 'Manage Billing'}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Current Subscription */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CreditCard className="h-5 w-5" />
              <span>Current Subscription</span>
            </CardTitle>
            <CardDescription>Your active subscription plan</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {paymentStatus.hasActiveSubscription ? (
              <>
                <div className="flex items-center justify-between">
                  <span className="font-medium">Portfolio Plan</span>
                  {getStatusBadge(paymentStatus.subscription.status)}
                </div>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Subscription ID:</span>
                    <span className="font-mono text-xs">{paymentStatus.subscription.subscriptionId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Last Updated:</span>
                    <span>{formatDate(paymentStatus.subscription.updatedAt)}</span>
                  </div>
                </div>
                <Separator />
                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleCancelSubscription}
                    disabled={actionLoading === 'cancel' || paymentStatus.subscription.status === 'canceled'}
                  >
                    {actionLoading === 'cancel' ? 'Canceling...' : 'Cancel Subscription'}
                  </Button>
                </div>
              </>
            ) : (
              <div className="text-center py-4">
                <p className="text-muted-foreground">No active subscription</p>
                <p className="text-sm text-muted-foreground">Upgrade to Portfolio for unlimited access</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Purchase History */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5" />
              <span>Purchase History</span>
            </CardTitle>
            <CardDescription>Your one-time purchases and reports</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {paymentStatus.purchases.length > 0 ? (
              paymentStatus.purchases.map((purchase, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">
                      {purchase.productType === 'core-report' ? 'Core Report' : 'Pro Report'}
                    </span>
                    <span className="font-bold">{formatCurrency(purchase.amount)}</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Purchased on {formatDate(purchase.purchasedAt)}
                  </div>
                  {index < paymentStatus.purchases.length - 1 && <Separator />}
                </div>
              ))
            ) : (
              <div className="text-center py-4">
                <p className="text-muted-foreground">No purchases yet</p>
                <p className="text-sm text-muted-foreground">Purchase a report to get started</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Access Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Your Access</CardTitle>
          <CardDescription>Current features and capabilities you have access to</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-3">
              {paymentStatus.hasCoreReport ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 text-gray-400" />
              )}
              <div>
                <p className="font-medium">Core Report</p>
                <p className="text-sm text-muted-foreground">
                  {paymentStatus.hasCoreReport ? 'Purchased' : 'Not purchased'}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              {paymentStatus.hasProReport ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 text-gray-400" />
              )}
              <div>
                <p className="font-medium">Pro Report</p>
                <p className="text-sm text-muted-foreground">
                  {paymentStatus.hasProReport ? 'Purchased' : 'Not purchased'}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              {paymentStatus.hasActiveSubscription ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 text-gray-400" />
              )}
              <div>
                <p className="font-medium">Portfolio Access</p>
                <p className="text-sm text-muted-foreground">
                  {paymentStatus.hasActiveSubscription ? 'Active subscription' : 'No subscription'}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upgrade CTA */}
      {!paymentStatus.hasActiveSubscription && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Upgrade to Portfolio for unlimited projects, real-time monitoring, and team collaboration features.
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}