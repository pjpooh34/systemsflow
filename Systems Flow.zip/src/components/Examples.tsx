import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"
import { Button } from "./ui/button"
import { 
  ExternalLink, 
  GitBranch, 
  Layers, 
  Database,
  ArrowRight,
  BarChart3,
  Shield,
  Zap
} from "lucide-react"

const examples = [
  {
    title: "$45M SaaS Acquisition",
    description: "Complete due diligence analysis of a customer support platform being acquired by a Fortune 500 company.",
    framework: "React + Node.js + PostgreSQL + Redis",
    components: 312,
    dataFlows: 47,
    userJourneys: 23,
    complexity: "Very High",
    analysisTime: "35 minutes",
    icon: BarChart3,
    iconColor: "text-blue-600",
    highlights: [
      "Identified $2M in hidden technical debt",
      "Discovered critical security vulnerabilities",
      "Mapped complete customer data flow",
      "Quantified scalability limitations"
    ]
  },
  {
    title: "Private Equity Portfolio Analysis",
    description: "Technical assessment of a logistics SaaS platform for portfolio optimization and growth planning.",
    framework: "Vue.js + Python + MongoDB + Kubernetes",
    components: 428,
    dataFlows: 63,
    userJourneys: 31,
    complexity: "Enterprise",
    analysisTime: "42 minutes",
    icon: Shield,
    iconColor: "text-green-600",
    highlights: [
      "Architecture modernization roadmap",
      "Performance optimization opportunities",
      "Team skill gap analysis",
      "Integration complexity assessment"
    ]
  },
  {
    title: "Startup Acquisition Integration",
    description: "Fast-track integration planning for an AI-powered marketing automation platform acquisition.",
    framework: "Next.js + FastAPI + PostgreSQL + AWS",
    components: 186,
    dataFlows: 29,
    userJourneys: 18,
    complexity: "High",
    analysisTime: "22 minutes",
    icon: Zap,
    iconColor: "text-purple-600",
    highlights: [
      "Team onboarding acceleration plan",
      "Data migration strategy development",
      "API consolidation opportunities",
      "Compliance framework assessment"
    ]
  }
]

interface ExamplesProps {
  onStartDemo?: () => void
}

export function Examples({ onStartDemo }: ExamplesProps) {
  return (
    <section id="examples" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <Badge variant="secondary" className="w-fit mx-auto">Analysis Examples</Badge>
          <h2 className="text-3xl lg:text-5xl">
            Real acquisition success stories
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            See how Systems Flow helped investors, private equity firms, and acquirers make confident decisions with complete technical intelligence.
          </p>
        </div>

        <div className="space-y-8">
          {examples.map((example, index) => (
            <Card key={index} className="overflow-hidden">
              <div className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-2xl mb-2">{example.title}</CardTitle>
                        <Badge variant="outline" className="mb-3">
                          {example.framework}
                        </Badge>
                        <CardDescription className="text-base">
                          {example.description}
                        </CardDescription>
                      </div>
                      <Badge 
                        variant={example.complexity === "Very High" ? "destructive" : 
                                example.complexity === "High" ? "default" : "secondary"}
                      >
                        {example.complexity}
                      </Badge>
                    </div>

                    <div className="grid sm:grid-cols-4 gap-4 py-4">
                      <div className="flex items-center space-x-2">
                        <Layers className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <div className="font-semibold">{example.components}</div>
                          <div className="text-xs text-muted-foreground">Components</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <GitBranch className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <div className="font-semibold">{example.dataFlows}</div>
                          <div className="text-xs text-muted-foreground">Services</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Database className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <div className="font-semibold">{example.userJourneys}</div>
                          <div className="text-xs text-muted-foreground">Integrations</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <div className="font-semibold">{example.analysisTime}</div>
                          <div className="text-xs text-muted-foreground">Analysis Time</div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-semibold">Key Insights Discovered:</h4>
                      <ul className="space-y-1">
                        {example.highlights.map((highlight, highlightIndex) => (
                          <li key={highlightIndex} className="flex items-center space-x-2 text-sm">
                            <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                            <span>{highlight}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <Button variant="outline" className="group" onClick={onStartDemo}>
                      View Interactive Demo
                      <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </div>
                </div>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center space-y-6">
          <div className="space-y-2">
            <h3 className="text-2xl">Ready for your next acquisition?</h3>
            <p className="text-muted-foreground">
              Get complete technical due diligence in minutes, not months. Make confident decisions with comprehensive system intelligence.
            </p>
          </div>
          <Button size="lg" className="group" onClick={onStartDemo}>
            Start Free Analysis
            <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </div>
    </section>
  )
}