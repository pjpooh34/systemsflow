import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Progress } from "./ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "./ui/alert"
import { AnimatedCard, StaggeredCards } from "./ui/animated-card"
import { LoadingSpinner } from "./ui/loading-spinner"
import { motion } from "motion/react"
import {
  Activity, AlertTriangle, CheckCircle, Clock, Cpu, Database, Globe,
  HardDrive, MemoryStick, Network, RefreshCw, Server, Shield, TrendingUp,
  TrendingDown, Zap, Settings, Bell, Download, BarChart3, Monitor,
  Wifi, CloudOff, AlertCircle, Info, XCircle, ExternalLink
} from "lucide-react"
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell
} from 'recharts'

interface SystemHealthProps {
  onBack: () => void
}

interface MetricData {
  name: string
  value: number
  unit: string
  status: 'good' | 'warning' | 'critical'
  trend: 'up' | 'down' | 'stable'
  change: number
}

interface ServiceStatus {
  name: string
  status: 'operational' | 'degraded' | 'outage'
  uptime: number
  latency: number
  lastIncident?: string
}

export function SystemHealth({ onBack }: SystemHealthProps) {
  const [activeTab, setActiveTab] = useState('overview')
  const [loading, setLoading] = useState(false)
  const [autoRefresh, setAutoRefresh] = useState(true)
  const [lastUpdated, setLastUpdated] = useState(new Date())

  // Real-time metrics
  const [metrics, setMetrics] = useState<MetricData[]>([
    { name: 'CPU Usage', value: 23, unit: '%', status: 'good', trend: 'stable', change: 0.5 },
    { name: 'Memory Usage', value: 67, unit: '%', status: 'warning', trend: 'up', change: 5.2 },
    { name: 'Disk Usage', value: 45, unit: '%', status: 'good', trend: 'down', change: -2.1 },
    { name: 'Network I/O', value: 156, unit: 'MB/s', status: 'good', trend: 'up', change: 12.3 },
    { name: 'Active Users', value: 1247, unit: 'users', status: 'good', trend: 'up', change: 8.7 },
    { name: 'API Response Time', value: 245, unit: 'ms', status: 'good', trend: 'stable', change: -1.2 }
  ])

  const [services, setServices] = useState<ServiceStatus[]>([
    { name: 'Analysis API', status: 'operational', uptime: 99.97, latency: 234 },
    { name: 'Authentication', status: 'operational', uptime: 99.99, latency: 89 },
    { name: 'Database', status: 'operational', uptime: 99.95, latency: 12 },
    { name: 'File Storage', status: 'degraded', uptime: 98.45, latency: 567, lastIncident: '2 hours ago' },
    { name: 'Notification Service', status: 'operational', uptime: 99.88, latency: 145 },
    { name: 'Webhooks', status: 'operational', uptime: 99.76, latency: 203 }
  ])

  // Performance data for charts
  const performanceData = [
    { time: '00:00', cpu: 20, memory: 65, requests: 120 },
    { time: '04:00', cpu: 18, memory: 62, requests: 89 },
    { time: '08:00', cpu: 35, memory: 78, requests: 245 },
    { time: '12:00', cpu: 42, memory: 85, requests: 312 },
    { time: '16:00', cpu: 38, memory: 82, requests: 298 },
    { time: '20:00', cpu: 25, memory: 71, requests: 167 },
    { time: '24:00', cpu: 23, memory: 67, requests: 134 }
  ]

  const errorData = [
    { name: '2xx Success', value: 92.3, fill: '#10b981' },
    { name: '4xx Client Error', value: 5.2, fill: '#f59e0b' },
    { name: '5xx Server Error', value: 2.5, fill: '#ef4444' }
  ]

  const uptimeData = [
    { service: 'API', uptime: 99.97 },
    { service: 'Auth', uptime: 99.99 },
    { service: 'DB', uptime: 99.95 },
    { service: 'Storage', uptime: 98.45 },
    { service: 'Notifications', uptime: 99.88 },
    { service: 'Webhooks', uptime: 99.76 }
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'operational': case 'good': return 'bg-green-50 text-green-700 border-green-200'
      case 'degraded': case 'warning': return 'bg-yellow-50 text-yellow-700 border-yellow-200'
      case 'outage': case 'critical': return 'bg-red-50 text-red-700 border-red-200'
      default: return 'bg-gray-50 text-gray-700 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'operational': case 'good': return <CheckCircle className="h-4 w-4 text-green-600" />
      case 'degraded': case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-600" />
      case 'outage': case 'critical': return <XCircle className="h-4 w-4 text-red-600" />
      default: return <Info className="h-4 w-4 text-gray-600" />
    }
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-3 w-3 text-green-600" />
      case 'down': return <TrendingDown className="h-3 w-3 text-red-600" />
      default: return <Activity className="h-3 w-3 text-gray-600" />
    }
  }

  const refreshData = async () => {
    setLoading(true)
    try {
      // Simulate API call to refresh metrics
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Update metrics with simulated real-time data
      setMetrics(prev => prev.map(metric => ({
        ...metric,
        value: metric.value + (Math.random() - 0.5) * 10,
        change: (Math.random() - 0.5) * 20
      })))
      
      setLastUpdated(new Date())
    } catch (error) {
      console.error('Failed to refresh data:', error)
    } finally {
      setLoading(false)
    }
  }

  // Auto-refresh functionality
  useEffect(() => {
    if (!autoRefresh) return

    const interval = setInterval(refreshData, 30000) // Refresh every 30 seconds
    return () => clearInterval(interval)
  }, [autoRefresh])

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              ← Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold">System Health</h1>
              <p className="text-muted-foreground">
                Monitor system performance and service status in real-time
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="bg-green-50 text-green-700">
              All Systems Operational
            </Badge>
            <Button
              variant="outline"
              size="sm"
              onClick={refreshData}
              disabled={loading}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </motion.div>

        {/* Status Banner */}
        <motion.div
          className="mb-6"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <Alert className="border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertTitle className="text-green-800">All Systems Operational</AlertTitle>
            <AlertDescription className="text-green-700">
              All services are running normally. Last updated: {lastUpdated.toLocaleTimeString()}
              {autoRefresh && (
                <span className="ml-2 text-xs">• Auto-refresh enabled</span>
              )}
            </AlertDescription>
          </Alert>
        </motion.div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="logs">Logs</TabsTrigger>
            <TabsTrigger value="alerts">Alerts</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <StaggeredCards className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {metrics.map((metric, index) => (
                <AnimatedCard key={metric.name} hoverScale fadeIn delay={index * 0.1}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-sm font-medium text-muted-foreground">
                        {metric.name}
                      </div>
                      {getTrendIcon(metric.trend)}
                    </div>
                    <div className="flex items-baseline justify-between">
                      <div className="text-2xl font-bold">
                        {typeof metric.value === 'number' ? metric.value.toFixed(0) : metric.value}
                        <span className="text-sm text-muted-foreground ml-1">
                          {metric.unit}
                        </span>
                      </div>
                      <Badge variant="outline" className={getStatusColor(metric.status)}>
                        {metric.status}
                      </Badge>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {metric.change > 0 ? '+' : ''}{metric.change.toFixed(1)}% change
                    </div>
                  </CardContent>
                </AnimatedCard>
              ))}
            </StaggeredCards>

            {/* System Overview Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Resource Usage (24h)</CardTitle>
                  <CardDescription>CPU and Memory utilization over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Area 
                        type="monotone" 
                        dataKey="cpu" 
                        stackId="1" 
                        stroke="#3b82f6" 
                        fill="#dbeafe" 
                        name="CPU %"
                      />
                      <Area 
                        type="monotone" 
                        dataKey="memory" 
                        stackId="2" 
                        stroke="#10b981" 
                        fill="#d1fae5" 
                        name="Memory %"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Response Status Distribution</CardTitle>
                  <CardDescription>HTTP response codes over the last 24 hours</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={errorData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={120}
                        dataKey="value"
                      >
                        {errorData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `${value}%`} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex justify-center space-x-4 mt-4">
                    {errorData.map((entry) => (
                      <div key={entry.name} className="flex items-center space-x-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: entry.fill }}
                        />
                        <span className="text-sm">{entry.name}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Service Status Grid */}
            <Card>
              <CardHeader>
                <CardTitle>Service Status</CardTitle>
                <CardDescription>Current status of all system components</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {services.map((service) => (
                    <div 
                      key={service.name}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center space-x-3">
                        {getStatusIcon(service.status)}
                        <div>
                          <div className="font-medium">{service.name}</div>
                          <div className="text-sm text-muted-foreground">
                            {service.uptime}% uptime • {service.latency}ms avg
                          </div>
                        </div>
                      </div>
                      <Badge variant="outline" className={getStatusColor(service.status)}>
                        {service.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Request Volume</CardTitle>
                  <CardDescription>API requests per hour</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="requests" fill="#3b82f6" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Service Uptime</CardTitle>
                  <CardDescription>30-day uptime percentage by service</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={uptimeData} layout="horizontal">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" domain={[95, 100]} />
                      <YAxis dataKey="service" type="category" />
                      <Tooltip formatter={(value) => `${value}%`} />
                      <Bar dataKey="uptime" fill="#10b981" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Performance Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Avg Response Time</p>
                      <p className="text-2xl font-bold">234ms</p>
                    </div>
                    <Clock className="h-8 w-8 text-blue-600" />
                  </div>
                  <Progress value={23} className="mt-3" />
                  <p className="text-xs text-muted-foreground mt-2">-12ms from yesterday</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Throughput</p>
                      <p className="text-2xl font-bold">1.2k</p>
                    </div>
                    <Zap className="h-8 w-8 text-yellow-600" />
                  </div>
                  <Progress value={78} className="mt-3" />
                  <p className="text-xs text-muted-foreground mt-2">req/min peak</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Error Rate</p>
                      <p className="text-2xl font-bold">0.03%</p>
                    </div>
                    <AlertCircle className="h-8 w-8 text-green-600" />
                  </div>
                  <Progress value={3} className="mt-3" />
                  <p className="text-xs text-muted-foreground mt-2">Well within SLA</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Availability</p>
                      <p className="text-2xl font-bold">99.97%</p>
                    </div>
                    <Shield className="h-8 w-8 text-green-600" />
                  </div>
                  <Progress value={99.97} className="mt-3" />
                  <p className="text-xs text-muted-foreground mt-2">30-day average</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Services Tab */}
          <TabsContent value="services" className="space-y-6">
            <div className="space-y-4">
              {services.map((service) => (
                <Card key={service.name}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Server className="h-5 w-5" />
                        <div>
                          <CardTitle>{service.name}</CardTitle>
                          <CardDescription>
                            {service.uptime}% uptime • {service.latency}ms average response time
                          </CardDescription>
                        </div>
                      </div>
                      <Badge variant="outline" className={getStatusColor(service.status)}>
                        {getStatusIcon(service.status)}
                        <span className="ml-1">{service.status}</span>
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Uptime</span>
                        <div className="flex items-center space-x-2">
                          <Progress value={service.uptime} className="w-32" />
                          <span className="text-sm font-medium">{service.uptime}%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Response Time</span>
                        <span className="text-sm font-medium">{service.latency}ms</span>
                      </div>
                      {service.lastIncident && (
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Last Incident</span>
                          <span className="text-sm text-muted-foreground">{service.lastIncident}</span>
                        </div>
                      )}
                    </div>
                    <div className="flex space-x-2 mt-4">
                      <Button size="sm" variant="outline">
                        <Monitor className="h-3 w-3 mr-1" />
                        View Details
                      </Button>
                      <Button size="sm" variant="outline">
                        <BarChart3 className="h-3 w-3 mr-1" />
                        Metrics
                      </Button>
                      <Button size="sm" variant="outline">
                        <Settings className="h-3 w-3 mr-1" />
                        Configure
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Logs Tab */}
          <TabsContent value="logs" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>System Logs</CardTitle>
                <CardDescription>Recent system events and error logs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {[
                    { level: 'info', message: 'Analysis service started successfully', time: '10:23:45' },
                    { level: 'warning', message: 'High memory usage detected on server-02', time: '10:22:12' },
                    { level: 'info', message: 'Database backup completed', time: '10:20:00' },
                    { level: 'error', message: 'Failed to connect to external API endpoint', time: '10:18:33' },
                    { level: 'info', message: 'User authentication successful', time: '10:15:42' },
                    { level: 'warning', message: 'Rate limit threshold reached for API key', time: '10:12:18' },
                    { level: 'info', message: 'Cache cleared successfully', time: '10:10:05' },
                    { level: 'error', message: 'Webhook delivery failed for endpoint', time: '10:08:21' }
                  ].map((log, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 border rounded-lg font-mono text-sm">
                      <div className="flex items-center space-x-2">
                        {log.level === 'error' && <XCircle className="h-4 w-4 text-red-600" />}
                        {log.level === 'warning' && <AlertTriangle className="h-4 w-4 text-yellow-600" />}
                        {log.level === 'info' && <Info className="h-4 w-4 text-blue-600" />}
                        <span className="text-xs text-muted-foreground">{log.time}</span>
                      </div>
                      <div className="flex-1">
                        <span className={`text-xs uppercase px-2 py-1 rounded ${
                          log.level === 'error' ? 'bg-red-100 text-red-800' :
                          log.level === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-blue-100 text-blue-800'
                        }`}>
                          {log.level}
                        </span>
                        <span className="ml-3">{log.message}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Alerts Tab */}
          <TabsContent value="alerts" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Active Alerts</CardTitle>
                  <CardDescription>Current system alerts requiring attention</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Alert className="border-yellow-200 bg-yellow-50">
                      <AlertTriangle className="h-4 w-4 text-yellow-600" />
                      <AlertTitle className="text-yellow-800">High Memory Usage</AlertTitle>
                      <AlertDescription className="text-yellow-700">
                        Server memory usage is at 85%. Consider scaling up resources.
                      </AlertDescription>
                    </Alert>
                    <Alert className="border-blue-200 bg-blue-50">
                      <Info className="h-4 w-4 text-blue-600" />
                      <AlertTitle className="text-blue-800">Scheduled Maintenance</AlertTitle>
                      <AlertDescription className="text-blue-700">
                        Database maintenance window starts in 2 hours.
                      </AlertDescription>
                    </Alert>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Alert Settings</CardTitle>
                  <CardDescription>Configure monitoring thresholds and notifications</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>CPU Usage Threshold</Label>
                    <div className="flex items-center space-x-2">
                      <Progress value={80} className="flex-1" />
                      <span className="text-sm">80%</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Memory Usage Threshold</Label>
                    <div className="flex items-center space-x-2">
                      <Progress value={85} className="flex-1" />
                      <span className="text-sm">85%</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Response Time Threshold</Label>
                    <div className="flex items-center space-x-2">
                      <Progress value={60} className="flex-1" />
                      <span className="text-sm">500ms</span>
                    </div>
                  </div>
                  <Button className="w-full">
                    <Settings className="h-4 w-4 mr-2" />
                    Update Settings
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}