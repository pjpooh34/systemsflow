import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Switch } from "./ui/switch"
import { Alert, AlertDescription } from "./ui/alert"
import { AnimatedCard, StaggeredCards } from "./ui/animated-card"
import { LoadingSpinner } from "./ui/loading-spinner"
import { motion } from "motion/react"
import {
  Github, GitlabIcon as GitLab, Link, CheckCircle, AlertTriangle, Settings,
  Key, Database, Cloud, Webhook, Zap, Shield, Download, Upload, RefreshCw,
  ExternalLink, Copy, Eye, EyeOff, Plus, Trash2, Edit, Save
} from "lucide-react"

interface IntegrationsProps {
  onBack: () => void
}

interface Integration {
  id: string
  name: string
  provider: string
  status: 'connected' | 'disconnected' | 'error'
  description: string
  icon: React.ReactNode
  lastSync?: string
  features: string[]
  config?: Record<string, any>
}

export function Integrations({ onBack }: IntegrationsProps) {
  const [activeTab, setActiveTab] = useState('overview')
  const [loading, setLoading] = useState(false)
  const [showApiKeys, setShowApiKeys] = useState<Record<string, boolean>>({})
  const [newIntegration, setNewIntegration] = useState({
    provider: '',
    name: '',
    apiKey: '',
    url: '',
    webhook: ''
  })

  const [integrations, setIntegrations] = useState<Integration[]>([
    {
      id: '1',
      name: 'GitHub Enterprise',
      provider: 'github',
      status: 'connected',
      description: 'Connected to organization repositories',
      icon: <Github className="h-6 w-6" />,
      lastSync: '2 minutes ago',
      features: ['Repository scanning', 'Pull request analysis', 'Code quality metrics', 'Automated reporting'],
      config: {
        org: 'acme-corp',
        repos: 23,
        webhook: 'https://api.systemsflow.com/webhooks/github'
      }
    },
    {
      id: '2', 
      name: 'GitLab CI/CD',
      provider: 'gitlab',
      status: 'connected',
      description: 'Pipeline integration and analysis',
      icon: <GitLab className="h-6 w-6" />,
      lastSync: '1 hour ago',
      features: ['Pipeline monitoring', 'Build analysis', 'Deployment tracking', 'Performance metrics'],
      config: {
        url: 'https://gitlab.company.com',
        projects: 15
      }
    },
    {
      id: '3',
      name: 'AWS CloudWatch',
      provider: 'aws',
      status: 'error',
      description: 'Infrastructure monitoring and metrics',
      icon: <Cloud className="h-6 w-6" />,
      lastSync: '3 days ago',
      features: ['Performance monitoring', 'Error tracking', 'Resource utilization', 'Cost analysis'],
      config: {
        region: 'us-east-1',
        accounts: 3
      }
    },
    {
      id: '4',
      name: 'Slack Notifications',
      provider: 'slack',
      status: 'disconnected',
      description: 'Team notifications and alerts',
      icon: <Webhook className="h-6 w-6" />,
      features: ['Real-time alerts', 'Report sharing', 'Team collaboration', 'Custom notifications']
    }
  ])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'bg-green-50 text-green-700 border-green-200'
      case 'error': return 'bg-red-50 text-red-700 border-red-200'
      case 'disconnected': return 'bg-gray-50 text-gray-700 border-gray-200'
      default: return 'bg-gray-50 text-gray-700 border-gray-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': return <CheckCircle className="h-4 w-4 text-green-600" />
      case 'error': return <AlertTriangle className="h-4 w-4 text-red-600" />
      case 'disconnected': return <Link className="h-4 w-4 text-gray-600" />
      default: return <Link className="h-4 w-4 text-gray-600" />
    }
  }

  const toggleApiKeyVisibility = (id: string) => {
    setShowApiKeys(prev => ({ ...prev, [id]: !prev[id] }))
  }

  const handleConnect = async (integrationId: string) => {
    setLoading(true)
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      setIntegrations(prev => prev.map(integration => 
        integration.id === integrationId 
          ? { ...integration, status: 'connected', lastSync: 'Just now' }
          : integration
      ))
    } catch (error) {
      console.error('Connection failed:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleDisconnect = async (integrationId: string) => {
    setLoading(true)
    try {
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      setIntegrations(prev => prev.map(integration => 
        integration.id === integrationId 
          ? { ...integration, status: 'disconnected', lastSync: undefined }
          : integration
      ))
    } catch (error) {
      console.error('Disconnection failed:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSync = async (integrationId: string) => {
    setLoading(true)
    try {
      await new Promise(resolve => setTimeout(resolve, 3000))
      
      setIntegrations(prev => prev.map(integration => 
        integration.id === integrationId 
          ? { ...integration, lastSync: 'Just now' }
          : integration
      ))
    } catch (error) {
      console.error('Sync failed:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              ← Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold">Integrations</h1>
              <p className="text-muted-foreground">
                Connect your development tools and services for comprehensive analysis
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="bg-blue-50 text-blue-700">
              {integrations.filter(i => i.status === 'connected').length} Connected
            </Badge>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Integration
            </Button>
          </div>
        </motion.div>

        {loading && (
          <motion.div
            className="mb-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <LoadingSpinner size="lg" text="Processing integration..." />
          </motion.div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="configure">Configure</TabsTrigger>
            <TabsTrigger value="webhooks">Webhooks</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <StaggeredCards className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {integrations.map((integration, index) => (
                <AnimatedCard key={integration.id} hoverScale fadeIn delay={index * 0.1}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-secondary rounded-lg">
                          {integration.icon}
                        </div>
                        <div>
                          <CardTitle className="text-lg">{integration.name}</CardTitle>
                          <CardDescription className="text-sm">
                            {integration.description}
                          </CardDescription>
                        </div>
                      </div>
                      <Badge variant="outline" className={getStatusColor(integration.status)}>
                        {getStatusIcon(integration.status)}
                        <span className="ml-1">{integration.status}</span>
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {integration.lastSync && (
                      <div className="text-sm text-muted-foreground">
                        Last sync: {integration.lastSync}
                      </div>
                    )}

                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Features</h4>
                      <div className="flex flex-wrap gap-1">
                        {integration.features.map((feature, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      {integration.status === 'connected' ? (
                        <>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleSync(integration.id)}
                            disabled={loading}
                          >
                            <RefreshCw className="h-3 w-3 mr-1" />
                            Sync
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDisconnect(integration.id)}
                            disabled={loading}
                          >
                            <Link className="h-3 w-3 mr-1" />
                            Disconnect
                          </Button>
                        </>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => handleConnect(integration.id)}
                          disabled={loading}
                        >
                          <Link className="h-3 w-3 mr-1" />
                          Connect
                        </Button>
                      )}
                      <Button size="sm" variant="ghost">
                        <Settings className="h-3 w-3 mr-1" />
                        Configure
                      </Button>
                    </div>
                  </CardContent>
                </AnimatedCard>
              ))}
            </StaggeredCards>

            {/* Integration Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total Data Sources</p>
                      <p className="text-2xl font-bold">127</p>
                    </div>
                    <Database className="h-8 w-8 text-blue-600" />
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">+23% this month</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">API Calls Today</p>
                      <p className="text-2xl font-bold">2,847</p>
                    </div>
                    <Zap className="h-8 w-8 text-yellow-600" />
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Within limits</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Success Rate</p>
                      <p className="text-2xl font-bold">99.7%</p>
                    </div>
                    <Shield className="h-8 w-8 text-green-600" />
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Excellent</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Configure Tab */}
          <TabsContent value="configure" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Add New Integration</CardTitle>
                <CardDescription>
                  Connect a new service to expand your analysis capabilities
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="provider">Provider</Label>
                    <select 
                      className="w-full p-2 border rounded-md"
                      value={newIntegration.provider}
                      onChange={(e) => setNewIntegration({...newIntegration, provider: e.target.value})}
                    >
                      <option value="">Select provider</option>
                      <option value="github">GitHub</option>
                      <option value="gitlab">GitLab</option>
                      <option value="aws">AWS</option>
                      <option value="azure">Azure</option>
                      <option value="gcp">Google Cloud</option>
                      <option value="slack">Slack</option>
                      <option value="teams">Microsoft Teams</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="name">Integration Name</Label>
                    <Input
                      id="name"
                      value={newIntegration.name}
                      onChange={(e) => setNewIntegration({...newIntegration, name: e.target.value})}
                      placeholder="e.g., Production GitHub"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="api-key">API Key / Token</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="api-key"
                      type={showApiKeys['new'] ? 'text' : 'password'}
                      value={newIntegration.apiKey}
                      onChange={(e) => setNewIntegration({...newIntegration, apiKey: e.target.value})}
                      placeholder="Enter API key or access token"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toggleApiKeyVisibility('new')}
                    >
                      {showApiKeys['new'] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="url">Base URL (if applicable)</Label>
                  <Input
                    id="url"
                    value={newIntegration.url}
                    onChange={(e) => setNewIntegration({...newIntegration, url: e.target.value})}
                    placeholder="https://api.example.com"
                  />
                </div>

                <Button className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Integration
                </Button>
              </CardContent>
            </Card>

            {/* Existing Integration Settings */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Manage Existing Integrations</h3>
              {integrations.map((integration) => (
                <Card key={integration.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        {integration.icon}
                        <div>
                          <CardTitle className="text-lg">{integration.name}</CardTitle>
                          <CardDescription>{integration.provider}</CardDescription>
                        </div>
                      </div>
                      <Badge variant="outline" className={getStatusColor(integration.status)}>
                        {integration.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {integration.config && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        {Object.entries(integration.config).map(([key, value]) => (
                          <div key={key} className="flex justify-between">
                            <span className="font-medium">{key}:</span>
                            <span className="text-muted-foreground">{value}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline">
                        <Edit className="h-3 w-3 mr-1" />
                        Edit
                      </Button>
                      <Button size="sm" variant="outline">
                        <RefreshCw className="h-3 w-3 mr-1" />
                        Test Connection
                      </Button>
                      <Button size="sm" variant="outline">
                        <Trash2 className="h-3 w-3 mr-1" />
                        Remove
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Webhooks Tab */}
          <TabsContent value="webhooks" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Webhook Configuration</CardTitle>
                <CardDescription>
                  Set up real-time notifications and data synchronization
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <Alert>
                  <Webhook className="h-4 w-4" />
                  <AlertDescription>
                    Webhooks allow external services to notify Systems Flow of events in real-time.
                    Use the endpoints below to configure webhooks in your integrated services.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  {integrations.filter(i => i.status === 'connected').map((integration) => (
                    <div key={integration.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-2">
                          {integration.icon}
                          <span className="font-medium">{integration.name}</span>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm">Webhook URL</Label>
                        <div className="flex space-x-2">
                          <Input
                            value={`https://api.systemsflow.com/webhooks/${integration.provider}/${integration.id}`}
                            readOnly
                            className="font-mono text-sm"
                          />
                          <Button variant="outline" size="sm">
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      <div className="text-xs text-muted-foreground mt-2">
                        Last received: {integration.lastSync || 'Never'}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-medium mb-3">Webhook Events</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {[
                      'Repository push',
                      'Pull request created',
                      'Deployment completed',
                      'Build failed',
                      'Security alert',
                      'Performance threshold'
                    ].map((event) => (
                      <div key={event} className="flex items-center space-x-2">
                        <Switch defaultChecked />
                        <span className="text-sm">{event}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Key className="h-5 w-5 mr-2" />
                    API Keys & Tokens
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    {integrations.filter(i => i.status === 'connected').map((integration) => (
                      <div key={integration.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          {integration.icon}
                          <div>
                            <div className="font-medium">{integration.name}</div>
                            <div className="text-sm text-muted-foreground">Last rotated: 30 days ago</div>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline">
                            <RefreshCw className="h-3 w-3 mr-1" />
                            Rotate
                          </Button>
                          <Button size="sm" variant="outline">
                            <Eye className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="h-5 w-5 mr-2" />
                    Security Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">IP Whitelist</div>
                        <div className="text-sm text-muted-foreground">Restrict API access to specific IPs</div>
                      </div>
                      <Switch />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Rate Limiting</div>
                        <div className="text-sm text-muted-foreground">Enable automatic rate limiting</div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Audit Logging</div>
                        <div className="text-sm text-muted-foreground">Log all API access attempts</div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">2FA Required</div>
                        <div className="text-sm text-muted-foreground">Require 2FA for sensitive operations</div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Security Events</CardTitle>
                <CardDescription>Recent security-related activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { event: 'API key rotated for GitHub integration', time: '2 hours ago', type: 'info' },
                    { event: 'Failed authentication attempt from 192.168.1.100', time: '1 day ago', type: 'warning' },
                    { event: 'New webhook endpoint configured', time: '3 days ago', type: 'info' },
                    { event: 'Rate limit exceeded for GitLab integration', time: '1 week ago', type: 'warning' }
                  ].map((event, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        {event.type === 'warning' ? (
                          <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        ) : (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        )}
                        <span className="text-sm">{event.event}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">{event.time}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}