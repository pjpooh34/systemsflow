import { useState, useEffect, useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Progress } from "./ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Textarea } from "./ui/textarea"
import { Separator } from "./ui/separator"
import { Alert, AlertDescription, AlertTitle } from "./ui/alert"
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Area, AreaChart, Treemap
} from 'recharts'
import { 
  Code, Shield, TrendingUp, Database, Users, FileText, Zap,
  Search, Play, RefreshCw, AlertTriangle, CheckCircle, Clock,
  ArrowRight, Settings, Filter, Download, Share, Eye,
  GitBranch, Package, Cpu, HardDrive, Network, Activity,
  DollarSign, TrendingDown, BarChart3, PieChart, LineChart,
  Target, Lightbulb, Calculator, ChevronDown, ChevronRight,
  X, SlidersHorizontal, Calendar, Gauge
} from "lucide-react"

interface AnalysisToolsProps {
  onBack: () => void
  onGenerateReport: () => void
}

// Mock data for different analysis types
const codebaseData = [
  { name: 'Components', value: 312, lines: 45678, complexity: 7.2 },
  { name: 'Services', value: 89, lines: 23456, complexity: 8.1 },
  { name: 'Utils', value: 156, lines: 12345, complexity: 5.9 },
  { name: 'Hooks', value: 67, lines: 8901, complexity: 6.4 },
  { name: 'Types', value: 234, lines: 5670, complexity: 4.2 }
]

const securityVulnerabilities = [
  { id: 1, severity: 'Critical', type: 'SQL Injection', component: 'UserService.js', line: 247, description: 'Unescaped user input in database query' },
  { id: 2, severity: 'Critical', type: 'XSS', component: 'CommentComponent.tsx', line: 89, description: 'Unescaped HTML rendering user content' },
  { id: 3, severity: 'High', type: 'Authentication', component: 'AuthMiddleware.js', line: 156, description: 'JWT token validation bypass possible' },
  { id: 4, severity: 'High', type: 'Data Exposure', component: 'ApiController.js', line: 334, description: 'Sensitive data in error responses' },
  { id: 5, severity: 'Medium', type: 'CSRF', component: 'PaymentForm.tsx', line: 78, description: 'Missing CSRF token validation' }
]

const dependencyData = [
  { name: 'React', version: '18.2.0', latest: '18.2.0', status: 'current', security: 'safe' },
  { name: 'Express', version: '4.18.1', latest: '4.18.2', status: 'minor', security: 'safe' },
  { name: 'Lodash', version: '4.17.20', latest: '4.17.21', status: 'patch', security: 'vulnerable' },
  { name: 'Axios', version: '0.27.2', latest: '1.6.2', status: 'major', security: 'safe' },
  { name: 'Moment.js', version: '2.29.1', latest: '2.29.4', status: 'deprecated', security: 'safe' }
]

const performanceMetrics = [
  { name: 'Bundle Size', current: 2.4, target: 2.0, unit: 'MB', trend: 'increasing' },
  { name: 'Load Time', current: 3.2, target: 2.5, unit: 's', trend: 'stable' },
  { name: 'Memory Usage', current: 145, target: 120, unit: 'MB', trend: 'increasing' },
  { name: 'API Response', current: 245, target: 200, unit: 'ms', trend: 'decreasing' }
]

const architectureNodes = [
  { name: 'Frontend Tier', children: [
    { name: 'React SPA', size: 2400, complexity: 8.2 },
    { name: 'Component Library', size: 1200, complexity: 6.1 },
    { name: 'State Management (Redux)', size: 800, complexity: 7.5 },
    { name: 'Routing & Navigation', size: 400, complexity: 5.3 },
    { name: 'PWA Features', size: 600, complexity: 6.8 }
  ]},
  { name: 'API & Gateway', children: [
    { name: 'Kong API Gateway', size: 1600, complexity: 9.1 },
    { name: 'Rate Limiting', size: 400, complexity: 7.2 },
    { name: 'Auth Middleware', size: 800, complexity: 8.7 },
    { name: 'Request Validation', size: 600, complexity: 6.9 }
  ]},
  { name: 'Core Services', children: [
    { name: 'User Service', size: 2000, complexity: 8.5 },
    { name: 'Billing Service', size: 1800, complexity: 9.2 },
    { name: 'Notification Service', size: 1200, complexity: 7.1 },
    { name: 'Analytics Service', size: 1400, complexity: 8.8 },
    { name: 'File Storage Service', size: 1000, complexity: 6.4 }
  ]},
  { name: 'Data Layer', children: [
    { name: 'PostgreSQL Primary', size: 2200, complexity: 8.9 },
    { name: 'Redis Cache', size: 800, complexity: 6.7 },
    { name: 'Elasticsearch', size: 1400, complexity: 7.8 },
    { name: 'S3 Object Storage', size: 1000, complexity: 5.2 }
  ]},
  { name: 'Infrastructure', children: [
    { name: 'Kubernetes Cluster', size: 1800, complexity: 9.5 },
    { name: 'Load Balancers', size: 600, complexity: 7.3 },
    { name: 'Message Queue (RabbitMQ)', size: 1000, complexity: 8.1 },
    { name: 'Monitoring Stack', size: 800, complexity: 7.6 }
  ]}
]

const microservicesData = [
  { 
    name: 'User Management Service', 
    status: 'healthy', 
    instances: 3,
    cpu: 45, 
    memory: 67, 
    requests: 1247,
    errors: 0.1,
    dependencies: ['Auth Service', 'Notification Service', 'PostgreSQL']
  },
  { 
    name: 'Billing Service', 
    status: 'healthy', 
    instances: 2,
    cpu: 32, 
    memory: 54, 
    requests: 892,
    errors: 0.05,
    dependencies: ['Payment Gateway', 'User Service', 'Analytics Service']
  },
  { 
    name: 'Analytics Service', 
    status: 'warning', 
    instances: 4,
    cpu: 78, 
    memory: 89, 
    requests: 2156,
    errors: 0.8,
    dependencies: ['Elasticsearch', 'Redis Cache', 'Data Pipeline']
  },
  { 
    name: 'Notification Service', 
    status: 'healthy', 
    instances: 2,
    cpu: 23, 
    memory: 41, 
    requests: 567,
    errors: 0.2,
    dependencies: ['Email Service', 'SMS Gateway', 'Push Service']
  },
  { 
    name: 'File Storage Service', 
    status: 'healthy', 
    instances: 3,
    cpu: 56, 
    memory: 72, 
    requests: 1834,
    errors: 0.3,
    dependencies: ['S3', 'CDN', 'Image Processing']
  }
]

const dataFlowPatterns = [
  {
    name: 'User Registration Flow',
    type: 'Synchronous',
    steps: [
      'User Input → Frontend Validation',
      'API Gateway → Rate Limiting',
      'User Service → Data Validation',
      'PostgreSQL → User Creation',
      'Email Service → Welcome Email',
      'Analytics → Event Tracking'
    ],
    volume: '1,247 requests/day',
    latency: '245ms avg',
    compliance: ['GDPR', 'CCPA'],
    security: 'High'
  },
  {
    name: 'Payment Processing Flow',
    type: 'Asynchronous',
    steps: [
      'Payment Form → Stripe Gateway',
      'Webhook → Payment Service',
      'Billing Service → Invoice Generation', 
      'Database → Transaction Record',
      'Queue → Email Notification',
      'Analytics → Revenue Tracking'
    ],
    volume: '342 transactions/day',
    latency: '1.2s avg',
    compliance: ['PCI DSS', 'SOX'],
    security: 'Critical'
  },
  {
    name: 'Data Analytics Pipeline',
    type: 'Batch Processing',
    steps: [
      'Event Collection → Kafka Streams',
      'ETL Pipeline → Data Transformation',
      'Data Warehouse → PostgreSQL',
      'Analytics Engine → Elasticsearch',
      'Dashboard → Real-time Updates',
      'Reporting → Scheduled Exports'
    ],
    volume: '2.3M events/day',
    latency: '15min batch',
    compliance: ['GDPR', 'Data Retention'],
    security: 'Medium'
  },
  {
    name: 'File Upload & Processing',
    type: 'Streaming',
    steps: [
      'File Upload → S3 Direct Upload',
      'Lambda Trigger → Processing Queue',
      'Image Service → Resize & Optimize',
      'CDN → Global Distribution',
      'Database → Metadata Storage',
      'Webhook → Client Notification'
    ],
    volume: '5,678 files/day',
    latency: '3.4s avg',
    compliance: ['GDPR', 'Content Policy'],
    security: 'Medium'
  }
]

const dataPipelineMetrics = [
  { pipeline: 'User Events ETL', processed: 2.3, failed: 0.02, latency: 245, status: 'healthy' },
  { pipeline: 'Financial Data Sync', processed: 0.8, failed: 0.01, latency: 1200, status: 'healthy' },
  { pipeline: 'Analytics Aggregation', processed: 5.7, failed: 0.15, latency: 890, status: 'warning' },
  { pipeline: 'Backup & Archival', processed: 12.4, failed: 0.03, latency: 3600, status: 'healthy' }
]

// Cost analysis data
const costAnalysis = {
  total: 18432,
  breakdown: [
    { category: 'Compute (Kubernetes)', cost: 7823, percentage: 42.4, trend: 'increasing', optimizable: true },
    { category: 'Database & Storage', cost: 4521, percentage: 24.5, trend: 'stable', optimizable: false },
    { category: 'Network & CDN', cost: 2145, percentage: 11.6, trend: 'decreasing', optimizable: true },
    { category: 'External APIs', cost: 1834, percentage: 9.9, trend: 'increasing', optimizable: true },
    { category: 'Monitoring & Observability', cost: 1456, percentage: 7.9, trend: 'stable', optimizable: false },
    { category: 'Security & Compliance', cost: 653, percentage: 3.5, trend: 'stable', optimizable: false }
  ],
  recommendations: [
    {
      area: 'Kubernetes Optimization',
      impact: 'High',
      savings: 2347,
      description: 'Right-size pods and implement cluster autoscaling',
      effort: 'Medium',
      timeframe: '2-4 weeks'
    },
    {
      area: 'CDN Configuration',
      impact: 'Medium',
      savings: 687,
      description: 'Optimize caching rules and reduce origin requests',
      effort: 'Low',
      timeframe: '1-2 weeks'
    },
    {
      area: 'API Rate Optimization',
      impact: 'Medium',
      savings: 445,
      description: 'Implement request batching for external APIs',
      effort: 'High',
      timeframe: '4-6 weeks'
    }
  ]
}

// Predictive analytics data
const predictiveAnalytics = {
  capacity: [
    { month: 'Current', cpu: 65, memory: 72, storage: 68, requests: 100 },
    { month: 'Month 1', cpu: 68, memory: 75, storage: 71, requests: 115 },
    { month: 'Month 2', cpu: 72, memory: 78, storage: 75, requests: 132 },
    { month: 'Month 3', cpu: 76, memory: 82, storage: 79, requests: 152 },
    { month: 'Month 4', cpu: 81, memory: 87, storage: 84, requests: 175 },
    { month: 'Month 5', cpu: 86, memory: 92, storage: 89, requests: 201 },
    { month: 'Month 6', cpu: 92, memory: 97, storage: 95, requests: 231 }
  ],
  scalingRecommendations: [
    {
      component: 'User Service',
      currentCapacity: 3,
      recommendedAction: 'Scale to 5 instances',
      timeline: 'Next 2 months',
      reason: 'CPU utilization trending towards 85%',
      confidence: 'High',
      impact: 'Performance degradation prevention'
    },
    {
      component: 'PostgreSQL Read Replicas',
      currentCapacity: 2,
      recommendedAction: 'Add 1 read replica',
      timeline: 'Next 3 months',
      reason: 'Read query volume increasing 15% monthly',
      confidence: 'Medium',
      impact: 'Improved read performance'
    },
    {
      component: 'Redis Cache Cluster',
      currentCapacity: '16GB',
      recommendedAction: 'Upgrade to 32GB',
      timeline: 'Next 4 months',
      reason: 'Memory usage at 89%, hit rate declining',
      confidence: 'High',
      impact: 'Maintain cache effectiveness'
    }
  ],
  trends: [
    { metric: 'Request Volume', growth: 15.2, period: 'monthly', confidence: 92 },
    { metric: 'Data Storage', growth: 8.7, period: 'monthly', confidence: 89 },
    { metric: 'Active Users', growth: 12.4, period: 'monthly', confidence: 94 },
    { metric: 'API Calls', growth: 18.9, period: 'monthly', confidence: 87 }
  ]
}

export function AnalysisTools({ onBack, onGenerateReport }: AnalysisToolsProps) {
  const [activeTab, setActiveTab] = useState('codebase')
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisProgress, setAnalysisProgress] = useState(0)
  const [selectedFile, setSelectedFile] = useState('')
  const [filterSeverity, setFilterSeverity] = useState('all')
  
  // Interactive filtering states
  const [serviceFilter, setServiceFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [dataFlowFilter, setDataFlowFilter] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedService, setSelectedService] = useState<string | null>(null)
  const [showCostAnalysis, setShowCostAnalysis] = useState(false)
  const [showPredictiveAnalytics, setShowPredictiveAnalytics] = useState(false)

  const startRealTimeAnalysis = () => {
    setIsAnalyzing(true)
    setAnalysisProgress(0)
    
    const interval = setInterval(() => {
      setAnalysisProgress(prev => {
        if (prev >= 100) {
          setIsAnalyzing(false)
          clearInterval(interval)
          return 100
        }
        return prev + Math.random() * 10
      })
    }, 200)
  }

  const filteredVulnerabilities = filterSeverity === 'all' 
    ? securityVulnerabilities 
    : securityVulnerabilities.filter(vuln => vuln.severity.toLowerCase() === filterSeverity)

  // Filtered microservices data
  const filteredMicroservices = useMemo(() => {
    return microservicesData.filter(service => {
      const matchesStatus = statusFilter === 'all' || service.status === statusFilter
      const matchesSearch = searchQuery === '' || 
        service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        service.dependencies.some(dep => dep.toLowerCase().includes(searchQuery.toLowerCase()))
      return matchesStatus && matchesSearch
    })
  }, [statusFilter, searchQuery])

  // Filtered data flows
  const filteredDataFlows = useMemo(() => {
    return dataFlowPatterns.filter(flow => {
      const matchesType = dataFlowFilter === 'all' || flow.type === dataFlowFilter
      const matchesSearch = searchQuery === '' || 
        flow.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        flow.compliance.some(comp => comp.toLowerCase().includes(searchQuery.toLowerCase()))
      return matchesType && matchesSearch
    })
  }, [dataFlowFilter, searchQuery])

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              ← Back to Demo
            </Button>
            <div>
              <h1 className="text-3xl font-bold">Interactive Analysis Tools</h1>
              <p className="text-muted-foreground">Real-time codebase analysis and insights</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={startRealTimeAnalysis}
              disabled={isAnalyzing}
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Run Analysis
                </>
              )}
            </Button>
            <Button size="sm" onClick={onGenerateReport}>
              <FileText className="h-4 w-4 mr-2" />
              Generate Report
            </Button>
          </div>
        </div>

        {/* Analysis Progress */}
        {isAnalyzing && (
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Real-time Analysis Progress</span>
                  <span>{Math.round(analysisProgress)}%</span>
                </div>
                <Progress value={analysisProgress} className="h-2" />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Analysis Tools Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <TabsList className="grid w-full lg:w-auto grid-cols-3 lg:grid-cols-6">
              <TabsTrigger value="codebase">Codebase</TabsTrigger>
              <TabsTrigger value="architecture">Architecture</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
              <TabsTrigger value="dependencies">Dependencies</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="dataflow">Data Flow</TabsTrigger>
            </TabsList>
            
            {/* Interactive controls */}
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-2">
                <Search className="h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search services, flows..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-48"
                />
              </div>
              
              {(activeTab === 'architecture' || activeTab === 'dataflow') && (
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowCostAnalysis(!showCostAnalysis)}
                    className={showCostAnalysis ? "bg-blue-50 text-blue-700" : ""}
                  >
                    <DollarSign className="h-4 w-4 mr-1" />
                    Cost Analysis
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowPredictiveAnalytics(!showPredictiveAnalytics)}
                    className={showPredictiveAnalytics ? "bg-purple-50 text-purple-700" : ""}
                  >
                    <TrendingUp className="h-4 w-4 mr-1" />
                    Predictions
                  </Button>
                </div>
              )}
            </div>
          </div>

          {/* Codebase Intelligence */}
          <TabsContent value="codebase" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Code className="h-5 w-5 mr-2" />
                    Code Analysis
                  </CardTitle>
                  <CardDescription>
                    Analyze code structure, complexity, and quality metrics
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Input 
                        placeholder="Enter file path or pattern (e.g., src/components/*.tsx)"
                        value={selectedFile}
                        onChange={(e) => setSelectedFile(e.target.value)}
                      />
                      <Button size="sm">
                        <Search className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold">858</div>
                        <div className="text-sm text-muted-foreground">Total Files</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold">96,050</div>
                        <div className="text-sm text-muted-foreground">Lines of Code</div>
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-3">
                      {codebaseData.map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <div className="font-medium">{item.name}</div>
                            <div className="text-sm text-muted-foreground">
                              {item.value} files • {item.lines.toLocaleString()} lines
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge 
                              variant="outline" 
                              className={
                                item.complexity > 7 ? "bg-red-50 text-red-700" :
                                item.complexity > 6 ? "bg-yellow-50 text-yellow-700" :
                                "bg-green-50 text-green-700"
                              }
                            >
                              {item.complexity}/10
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Code Quality Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={codebaseData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="complexity" fill="#8884d8" name="Complexity Score" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>File Size Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-lg font-bold text-green-600">672</div>
                    <div className="text-sm text-muted-foreground">Small Files (&lt;100 lines)</div>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-lg font-bold text-blue-600">156</div>
                    <div className="text-sm text-muted-foreground">Medium Files (100-500)</div>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-lg font-bold text-yellow-600">23</div>
                    <div className="text-sm text-muted-foreground">Large Files (500-1000)</div>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <div className="text-lg font-bold text-red-600">7</div>
                    <div className="text-sm text-muted-foreground">Huge Files (&gt;1000)</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Architecture Mapping */}
          <TabsContent value="architecture" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <GitBranch className="h-5 w-5 mr-2" />
                    System Architecture Overview
                  </CardTitle>
                  <CardDescription>
                    Microservices architecture with containerized deployment
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={350}>
                    <Treemap
                      data={architectureNodes}
                      dataKey="size"
                      aspectRatio={4/3}
                      stroke="#fff"
                      fill="#8884d8"
                    />
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Architecture Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center p-3 border rounded-lg">
                      <div className="text-xl font-bold text-blue-600">8.4/10</div>
                      <div className="text-sm text-muted-foreground">Architecture Score</div>
                    </div>
                    <Separator />
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Microservices</span>
                        <Badge variant="outline">12 services</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Load Balancers</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">3 active</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Database Clusters</span>
                        <Badge variant="outline">5 clusters</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Cache Layers</span>
                        <Badge variant="outline">Redis + CDN</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Message Queues</span>
                        <Badge variant="outline">RabbitMQ</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Cpu className="h-5 w-5 mr-2" />
                  Microservices Health & Performance
                </CardTitle>
                <CardDescription>
                  Real-time monitoring of containerized services across Kubernetes cluster
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-medium">Service Monitoring</h4>
                    <div className="flex items-center space-x-2">
                      <select 
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="px-3 py-1 border rounded-md text-sm"
                      >
                        <option value="all">All Status</option>
                        <option value="healthy">Healthy</option>
                        <option value="warning">Warning</option>
                        <option value="error">Error</option>
                      </select>
                    </div>
                  </div>
                  {filteredMicroservices.map((service, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${
                            service.status === 'healthy' ? 'bg-green-500' :
                            service.status === 'warning' ? 'bg-yellow-500' :
                            'bg-red-500'
                          }`}></div>
                          <span className="font-medium">{service.name}</span>
                          <Badge variant="outline">{service.instances} instances</Badge>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline" className="bg-blue-50 text-blue-700">
                            {service.requests} req/min
                          </Badge>
                          <Badge variant="outline" className={
                            service.errors < 0.5 ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                          }>
                            {service.errors}% errors
                          </Badge>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedService(selectedService === service.name ? null : service.name)}
                          >
                            {selectedService === service.name ? 
                              <ChevronDown className="h-4 w-4" /> : 
                              <ChevronRight className="h-4 w-4" />
                            }
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mb-3">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>CPU Usage</span>
                            <span>{service.cpu}%</span>
                          </div>
                          <Progress value={service.cpu} className="h-2" />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Memory Usage</span>
                            <span>{service.memory}%</span>
                          </div>
                          <Progress value={service.memory} className="h-2" />
                        </div>
                      </div>

                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Dependencies:</div>
                        <div className="flex flex-wrap gap-1">
                          {service.dependencies.map((dep, i) => (
                            <Badge key={i} variant="outline" className="text-xs">
                              {dep}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {/* Expandable Service Details */}
                      {selectedService === service.name && (
                        <div className="mt-4 p-3 bg-muted/30 rounded-lg space-y-3">
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                            <div>
                              <div className="text-muted-foreground">Deployment</div>
                              <div className="font-medium">Kubernetes</div>
                            </div>
                            <div>
                              <div className="text-muted-foreground">Version</div>
                              <div className="font-medium">v2.3.1</div>
                            </div>
                            <div>
                              <div className="text-muted-foreground">Namespace</div>
                              <div className="font-medium">production</div>
                            </div>
                            <div>
                              <div className="text-muted-foreground">Replicas</div>
                              <div className="font-medium">{service.instances}/3</div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                              <div className="text-sm font-medium mb-2">Resource Limits</div>
                              <div className="space-y-1 text-xs">
                                <div className="flex justify-between">
                                  <span>CPU Request:</span>
                                  <span>200m</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>CPU Limit:</span>
                                  <span>500m</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>Memory Request:</span>
                                  <span>256Mi</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>Memory Limit:</span>
                                  <span>512Mi</span>
                                </div>
                              </div>
                            </div>
                            
                            <div>
                              <div className="text-sm font-medium mb-2">Health Checks</div>
                              <div className="space-y-1 text-xs">
                                <div className="flex items-center justify-between">
                                  <span>Readiness:</span>
                                  <CheckCircle className="h-3 w-3 text-green-500" />
                                </div>
                                <div className="flex items-center justify-between">
                                  <span>Liveness:</span>
                                  <CheckCircle className="h-3 w-3 text-green-500" />
                                </div>
                                <div className="flex items-center justify-between">
                                  <span>Startup:</span>
                                  <CheckCircle className="h-3 w-3 text-green-500" />
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center justify-between pt-2">
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline">
                                <Eye className="h-3 w-3 mr-1" />
                                View Logs
                              </Button>
                              <Button size="sm" variant="outline">
                                <Settings className="h-3 w-3 mr-1" />
                                Scale
                              </Button>
                            </div>
                            <div className="text-xs text-muted-foreground">
                              Last updated: 2 minutes ago
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Network className="h-5 w-5 mr-2" />
                    Network & Security
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">API Gateway (Kong)</div>
                        <div className="text-sm text-muted-foreground">Rate limiting & auth</div>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700">99.9% uptime</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">Load Balancer (ALB)</div>
                        <div className="text-sm text-muted-foreground">Auto-scaling enabled</div>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700">3 zones</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">Service Mesh (Istio)</div>
                        <div className="text-sm text-muted-foreground">mTLS encryption</div>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700">Enabled</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">WAF Protection</div>
                        <div className="text-sm text-muted-foreground">CloudFlare + custom rules</div>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700">24k blocks/day</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <HardDrive className="h-5 w-5 mr-2" />
                    Data Storage & Caching
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">PostgreSQL Cluster</div>
                        <div className="text-sm text-muted-foreground">Primary + 2 read replicas</div>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700">847GB</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">Redis Cache</div>
                        <div className="text-sm text-muted-foreground">Session & application cache</div>
                      </div>
                      <Badge variant="outline" className="bg-blue-50 text-blue-700">97.2% hit rate</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">Elasticsearch</div>
                        <div className="text-sm text-muted-foreground">Search & analytics</div>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700">3 node cluster</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">S3 Object Storage</div>
                        <div className="text-sm text-muted-foreground">Files & backups</div>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700">2.3TB</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Cost Analysis Section */}
            {showCostAnalysis && (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <DollarSign className="h-5 w-5 mr-2" />
                      Infrastructure Cost Analysis
                    </CardTitle>
                    <CardDescription>
                      Monthly cost breakdown and optimization opportunities
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-green-600">${costAnalysis.total.toLocaleString()}</div>
                        <div className="text-sm text-muted-foreground">Monthly Infrastructure Cost</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">${costAnalysis.recommendations.reduce((sum, rec) => sum + rec.savings, 0).toLocaleString()}</div>
                        <div className="text-sm text-muted-foreground">Potential Monthly Savings</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-purple-600">{Math.round((costAnalysis.recommendations.reduce((sum, rec) => sum + rec.savings, 0) / costAnalysis.total) * 100)}%</div>
                        <div className="text-sm text-muted-foreground">Cost Reduction Potential</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
                      <div>
                        <h4 className="font-medium mb-4">Cost Breakdown by Category</h4>
                        <div className="space-y-3">
                          {costAnalysis.breakdown.map((item, index) => (
                            <div key={index} className="p-3 border rounded-lg">
                              <div className="flex items-center justify-between mb-2">
                                <span className="font-medium text-sm">{item.category}</span>
                                <div className="flex items-center space-x-2">
                                  <Badge variant="outline">${item.cost.toLocaleString()}</Badge>
                                  <Badge variant="outline" className={
                                    item.trend === 'increasing' ? 'bg-red-50 text-red-700' :
                                    item.trend === 'decreasing' ? 'bg-green-50 text-green-700' :
                                    'bg-gray-50 text-gray-700'
                                  }>
                                    {item.trend}
                                  </Badge>
                                </div>
                              </div>
                              <div className="flex justify-between items-center">
                                <Progress value={item.percentage} className="flex-1 mr-3 h-2" />
                                <span className="text-sm text-muted-foreground">{item.percentage}%</span>
                              </div>
                              {item.optimizable && (
                                <div className="flex items-center mt-2">
                                  <Lightbulb className="h-3 w-3 text-yellow-500 mr-1" />
                                  <span className="text-xs text-muted-foreground">Optimization available</span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium mb-4">Optimization Recommendations</h4>
                        <div className="space-y-3">
                          {costAnalysis.recommendations.map((rec, index) => (
                            <div key={index} className="p-4 border rounded-lg">
                              <div className="flex items-center justify-between mb-2">
                                <span className="font-medium text-sm">{rec.area}</span>
                                <Badge variant="outline" className={
                                  rec.impact === 'High' ? 'bg-red-50 text-red-700' :
                                  rec.impact === 'Medium' ? 'bg-yellow-50 text-yellow-700' :
                                  'bg-green-50 text-green-700'
                                }>
                                  {rec.impact} Impact
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mb-3">{rec.description}</p>
                              <div className="grid grid-cols-3 gap-2 text-xs">
                                <div>
                                  <div className="text-muted-foreground">Savings</div>
                                  <div className="font-medium text-green-600">${rec.savings}/mo</div>
                                </div>
                                <div>
                                  <div className="text-muted-foreground">Effort</div>
                                  <div className="font-medium">{rec.effort}</div>
                                </div>
                                <div>
                                  <div className="text-muted-foreground">Timeline</div>
                                  <div className="font-medium">{rec.timeframe}</div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Predictive Analytics Section */}
            {showPredictiveAnalytics && (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <TrendingUp className="h-5 w-5 mr-2" />
                      Capacity Planning & Growth Predictions
                    </CardTitle>
                    <CardDescription>
                      AI-powered forecasting for infrastructure scaling decisions
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                      <div>
                        <h4 className="font-medium mb-4">6-Month Capacity Forecast</h4>
                        <ResponsiveContainer width="100%" height={300}>
                          <LineChart data={predictiveAnalytics.capacity}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="month" />
                            <YAxis />
                            <Tooltip />
                            <Line type="monotone" dataKey="cpu" stroke="#8884d8" name="CPU %" />
                            <Line type="monotone" dataKey="memory" stroke="#82ca9d" name="Memory %" />
                            <Line type="monotone" dataKey="storage" stroke="#ffc658" name="Storage %" />
                            <Line type="monotone" dataKey="requests" stroke="#ff7300" name="Requests (indexed)" />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>

                      <div>
                        <h4 className="font-medium mb-4">Growth Trends</h4>
                        <div className="space-y-3">
                          {predictiveAnalytics.trends.map((trend, index) => (
                            <div key={index} className="p-3 border rounded-lg">
                              <div className="flex items-center justify-between mb-2">
                                <span className="font-medium text-sm">{trend.metric}</span>
                                <Badge variant="outline" className="bg-blue-50 text-blue-700">
                                  {trend.confidence}% confidence
                                </Badge>
                              </div>
                              <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                  <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                                  <span className="text-sm font-medium text-green-600">
                                    +{trend.growth}% {trend.period}
                                  </span>
                                </div>
                                <Progress value={trend.confidence} className="w-16 h-2" />
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-4">Scaling Recommendations</h4>
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        {predictiveAnalytics.scalingRecommendations.map((rec, index) => (
                          <div key={index} className="p-4 border rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium text-sm">{rec.component}</span>
                              <Badge variant="outline" className={
                                rec.confidence === 'High' ? 'bg-green-50 text-green-700' :
                                rec.confidence === 'Medium' ? 'bg-yellow-50 text-yellow-700' :
                                'bg-gray-50 text-gray-700'
                              }>
                                {rec.confidence} Confidence
                              </Badge>
                            </div>
                            
                            <div className="space-y-2 text-sm">
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Current:</span>
                                <span className="font-medium">{rec.currentCapacity}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Recommended:</span>
                                <span className="font-medium text-blue-600">{rec.recommendedAction}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Timeline:</span>
                                <span className="font-medium">{rec.timeline}</span>
                              </div>
                            </div>
                            
                            <div className="mt-3 p-2 bg-muted/30 rounded text-xs">
                              <div className="font-medium text-muted-foreground mb-1">Reason:</div>
                              <div>{rec.reason}</div>
                            </div>
                            
                            <div className="mt-2 text-xs">
                              <span className="text-muted-foreground">Impact: </span>
                              <span className="font-medium">{rec.impact}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          {/* Security Assessment */}
          <TabsContent value="security" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium">Security Vulnerabilities</h3>
                <p className="text-sm text-muted-foreground">Real-time security assessment and threat detection</p>
              </div>
              <div className="flex items-center space-x-2">
                <Label htmlFor="severity-filter" className="text-sm">Filter by severity:</Label>
                <select 
                  id="severity-filter"
                  value={filterSeverity}
                  onChange={(e) => setFilterSeverity(e.target.value)}
                  className="px-3 py-1 border rounded-md text-sm"
                >
                  <option value="all">All Severities</option>
                  <option value="critical">Critical</option>
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="h-5 w-5 mr-2" />
                    Security Score
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center space-y-4">
                    <div className="text-4xl font-bold text-yellow-600">7.2/10</div>
                    <Progress value={72} className="h-3" />
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="text-center">
                        <div className="text-lg font-bold text-red-600">2</div>
                        <div className="text-muted-foreground">Critical</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-orange-600">3</div>
                        <div className="text-muted-foreground">High</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Vulnerability Details</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-80 overflow-y-auto">
                    {filteredVulnerabilities.map((vuln) => (
                      <div key={vuln.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <Badge 
                              variant="outline" 
                              className={
                                vuln.severity === 'Critical' ? "bg-red-50 text-red-700" :
                                vuln.severity === 'High' ? "bg-orange-50 text-orange-700" :
                                vuln.severity === 'Medium' ? "bg-yellow-50 text-yellow-700" :
                                "bg-green-50 text-green-700"
                              }
                            >
                              {vuln.severity}
                            </Badge>
                            <span className="font-medium">{vuln.type}</span>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {vuln.component}:{vuln.line} - {vuln.description}
                          </div>
                        </div>
                        <Button size="sm" variant="outline">Fix</Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Dependencies Analysis */}
          <TabsContent value="dependencies" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Package className="h-5 w-5 mr-2" />
                  Dependency Analysis
                </CardTitle>
                <CardDescription>
                  Track package versions, security issues, and update recommendations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {dependencyData.map((dep, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="font-medium">{dep.name}</span>
                          <Badge variant="outline">{dep.version}</Badge>
                          {dep.version !== dep.latest && (
                            <Badge variant="outline" className="bg-blue-50 text-blue-700">
                              {dep.latest} available
                            </Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Status: {dep.status} • Security: {dep.security}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge 
                          variant="outline" 
                          className={
                            dep.status === 'current' ? "bg-green-50 text-green-700" :
                            dep.status === 'deprecated' ? "bg-red-50 text-red-700" :
                            dep.security === 'vulnerable' ? "bg-red-50 text-red-700" :
                            "bg-yellow-50 text-yellow-700"
                          }
                        >
                          {dep.status === 'current' ? 'Up to date' :
                           dep.status === 'deprecated' ? 'Deprecated' :
                           dep.security === 'vulnerable' ? 'Vulnerable' :
                           'Update available'}
                        </Badge>
                        {dep.status !== 'current' && (
                          <Button size="sm" variant="outline">Update</Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Performance Analysis */}
          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Cpu className="h-5 w-5 mr-2" />
                    Performance Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {performanceMetrics.map((metric, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium">{metric.name}</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-sm">{metric.current}{metric.unit}</span>
                            <Activity className={`h-4 w-4 ${
                              metric.trend === 'increasing' ? 'text-red-500' :
                              metric.trend === 'decreasing' ? 'text-green-500' :
                              'text-gray-500'
                            }`} />
                          </div>
                        </div>
                        <Progress 
                          value={(metric.current / metric.target) * 100} 
                          className="h-2"
                        />
                        <div className="text-xs text-muted-foreground">
                          Target: {metric.target}{metric.unit} • Trend: {metric.trend}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Real-time Monitoring</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="text-center p-3 border rounded-lg">
                      <div className="text-xl font-bold text-green-600">99.2%</div>
                      <div className="text-sm text-muted-foreground">Uptime</div>
                    </div>
                    <div className="text-center p-3 border rounded-lg">
                      <div className="text-xl font-bold text-blue-600">1,247</div>
                      <div className="text-sm text-muted-foreground">Active Users</div>
                    </div>
                  </div>
                  
                  <Alert>
                    <TrendingUp className="h-4 w-4" />
                    <AlertTitle>Performance Alert</AlertTitle>
                    <AlertDescription>
                      Bundle size has increased by 15% in the last week. Consider code splitting.
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Data Flow Analysis */}
          <TabsContent value="dataflow" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-center">Data Flows</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-3xl font-bold text-blue-600">147</div>
                  <div className="text-sm text-muted-foreground">Active flows</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-center">Daily Volume</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-3xl font-bold text-green-600">2.3M</div>
                  <div className="text-sm text-muted-foreground">Events/day</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-center">External APIs</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-3xl font-bold text-purple-600">23</div>
                  <div className="text-sm text-muted-foreground">Integrations</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-center">Compliance</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-3xl font-bold text-orange-600">98.7%</div>
                  <div className="text-sm text-muted-foreground">GDPR score</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="h-5 w-5 mr-2" />
                  Critical Data Flow Patterns
                </CardTitle>
                <CardDescription>
                  Analysis of major data processing pipelines and their compliance status
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-medium">Flow Analysis</h4>
                  <div className="flex items-center space-x-2">
                    <select 
                      value={dataFlowFilter}
                      onChange={(e) => setDataFlowFilter(e.target.value)}
                      className="px-3 py-1 border rounded-md text-sm"
                    >
                      <option value="all">All Types</option>
                      <option value="Synchronous">Synchronous</option>
                      <option value="Asynchronous">Asynchronous</option>
                      <option value="Batch Processing">Batch Processing</option>
                      <option value="Streaming">Streaming</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-6">
                  {filteredDataFlows.map((flow, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <h4 className="font-medium">{flow.name}</h4>
                          <Badge variant="outline" className={
                            flow.type === 'Synchronous' ? 'bg-blue-50 text-blue-700' :
                            flow.type === 'Asynchronous' ? 'bg-green-50 text-green-700' :
                            flow.type === 'Batch Processing' ? 'bg-purple-50 text-purple-700' :
                            'bg-orange-50 text-orange-700'
                          }>
                            {flow.type}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline" className={
                            flow.security === 'Critical' ? 'bg-red-50 text-red-700' :
                            flow.security === 'High' ? 'bg-orange-50 text-orange-700' :
                            'bg-green-50 text-green-700'
                          }>
                            {flow.security} Security
                          </Badge>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
                        <div>
                          <div className="text-sm font-medium mb-2">Data Flow Steps</div>
                          <div className="space-y-1">
                            {flow.steps.map((step, i) => (
                              <div key={i} className="text-sm text-muted-foreground flex items-center">
                                <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                                {step}
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <div className="text-sm font-medium mb-2">Performance Metrics</div>
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <span className="text-sm text-muted-foreground">Volume:</span>
                              <span className="text-sm font-medium">{flow.volume}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-muted-foreground">Latency:</span>
                              <span className="text-sm font-medium">{flow.latency}</span>
                            </div>
                          </div>
                        </div>

                        <div>
                          <div className="text-sm font-medium mb-2">Compliance</div>
                          <div className="flex flex-wrap gap-1">
                            {flow.compliance.map((comp, i) => (
                              <Badge key={i} variant="outline" className="text-xs bg-green-50 text-green-700">
                                {comp}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="h-5 w-5 mr-2" />
                    Data Pipeline Health
                  </CardTitle>
                  <CardDescription>
                    Real-time monitoring of ETL and streaming pipelines
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dataPipelineMetrics.map((pipeline, index) => (
                      <div key={index} className="p-3 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <div className={`w-2 h-2 rounded-full ${
                              pipeline.status === 'healthy' ? 'bg-green-500' :
                              pipeline.status === 'warning' ? 'bg-yellow-500' :
                              'bg-red-500'
                            }`}></div>
                            <span className="font-medium text-sm">{pipeline.pipeline}</span>
                          </div>
                          <Badge variant="outline" className={
                            pipeline.status === 'healthy' ? 'bg-green-50 text-green-700' :
                            'bg-yellow-50 text-yellow-700'
                          }>
                            {pipeline.status}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-xs">
                          <div>
                            <div className="text-muted-foreground">Processed</div>
                            <div className="font-medium">{pipeline.processed}M records</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">Failed</div>
                            <div className="font-medium">{pipeline.failed}%</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">Avg Latency</div>
                            <div className="font-medium">{pipeline.latency}ms</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="h-5 w-5 mr-2" />
                    Data Privacy & Compliance
                  </CardTitle>
                  <CardDescription>
                    Privacy controls and regulatory compliance monitoring
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">GDPR Compliance</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">98.7%</Badge>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Data subject rights, consent tracking, retention policies
                      </div>
                    </div>
                    
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">Data Retention</span>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700">Automated</Badge>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        User data: 7 years, Analytics: 2 years, Logs: 90 days
                      </div>
                    </div>

                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">Data Encryption</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">AES-256</Badge>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        At rest: AES-256, In transit: TLS 1.3, Application: Field-level
                      </div>
                    </div>

                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">Access Controls</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">RBAC</Badge>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Role-based access, audit logging, just-in-time access
                      </div>
                    </div>

                    <Alert>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>Data Lineage Gap</AlertTitle>
                      <AlertDescription className="text-xs">
                        3 data flows missing complete lineage tracking. Recommended: implement data catalog.
                      </AlertDescription>
                    </Alert>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Network className="h-5 w-5 mr-2" />
                  External Integrations & APIs
                </CardTitle>
                <CardDescription>
                  Third-party service integrations and data exchange patterns
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="p-3 border rounded-lg">
                    <div className="font-medium text-sm mb-1">Payment Processing</div>
                    <div className="text-xs text-muted-foreground mb-2">Stripe, PayPal, Bank transfers</div>
                    <div className="flex justify-between">
                      <Badge variant="outline" className="text-xs">342 tx/day</Badge>
                      <Badge variant="outline" className="bg-green-50 text-green-700 text-xs">99.9% uptime</Badge>
                    </div>
                  </div>
                  
                  <div className="p-3 border rounded-lg">
                    <div className="font-medium text-sm mb-1">Email Services</div>
                    <div className="text-xs text-muted-foreground mb-2">SendGrid, Mailgun</div>
                    <div className="flex justify-between">
                      <Badge variant="outline" className="text-xs">15.2k emails/day</Badge>
                      <Badge variant="outline" className="bg-green-50 text-green-700 text-xs">97.1% delivery</Badge>
                    </div>
                  </div>

                  <div className="p-3 border rounded-lg">
                    <div className="font-medium text-sm mb-1">Analytics</div>
                    <div className="text-xs text-muted-foreground mb-2">Google Analytics, Mixpanel</div>
                    <div className="flex justify-between">
                      <Badge variant="outline" className="text-xs">2.3M events/day</Badge>
                      <Badge variant="outline" className="bg-green-50 text-green-700 text-xs">Real-time</Badge>
                    </div>
                  </div>

                  <div className="p-3 border rounded-lg">
                    <div className="font-medium text-sm mb-1">File Storage</div>
                    <div className="text-xs text-muted-foreground mb-2">AWS S3, CloudFront CDN</div>
                    <div className="flex justify-between">
                      <Badge variant="outline" className="text-xs">5.6k files/day</Badge>
                      <Badge variant="outline" className="bg-green-50 text-green-700 text-xs">Global CDN</Badge>
                    </div>
                  </div>

                  <div className="p-3 border rounded-lg">
                    <div className="font-medium text-sm mb-1">CRM Integration</div>
                    <div className="text-xs text-muted-foreground mb-2">Salesforce, HubSpot</div>
                    <div className="flex justify-between">
                      <Badge variant="outline" className="text-xs">Bidirectional</Badge>
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 text-xs">Scheduled sync</Badge>
                    </div>
                  </div>

                  <div className="p-3 border rounded-lg">
                    <div className="font-medium text-sm mb-1">Monitoring</div>
                    <div className="text-xs text-muted-foreground mb-2">DataDog, New Relic</div>
                    <div className="flex justify-between">
                      <Badge variant="outline" className="text-xs">24/7 monitoring</Badge>
                      <Badge variant="outline" className="bg-green-50 text-green-700 text-xs">Active alerts</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}