import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Progress } from "./ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Slider } from "./ui/slider"
import { Switch } from "./ui/switch"
import { Separator } from "./ui/separator"
import { Alert, AlertDescription, AlertTitle } from "./ui/alert"
import { ScrollArea } from "./ui/scroll-area"
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area, ScatterChart, Scatter,
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Treemap,
  Sankey, Network
} from 'recharts'
import {
  Code, Shield, TrendingUp, Database, Users, FileText, Zap, Search, Play,
  RefreshCw, AlertTriangle, CheckCircle, Clock, Settings, Filter, Download,
  Share, Eye, GitBranch, Package, Cpu, HardDrive, Network as NetworkIcon,
  Activity, Monitor, Bug, Key, Lock, Layers, Globe, Terminal, Cloud,
  BarChart3, PieChart as PieChartIcon, LineChart as LineChartIcon,
  Maximize2, Minimize2, RotateCcw, ZoomIn, ZoomOut, Move
} from "lucide-react"

interface AdvancedAnalysisToolsProps {
  onBack: () => void
}

// Enhanced mock data for advanced visualizations
const dependencyGraph = {
  nodes: [
    { id: 'react', group: 'frontend', size: 120, category: 'framework' },
    { id: 'express', group: 'backend', size: 100, category: 'framework' },
    { id: 'postgresql', group: 'database', size: 80, category: 'database' },
    { id: 'redis', group: 'cache', size: 60, category: 'cache' },
    { id: 'stripe', group: 'external', size: 40, category: 'api' },
    { id: 'sendgrid', group: 'external', size: 35, category: 'api' },
    { id: 'aws-s3', group: 'infrastructure', size: 70, category: 'storage' },
    { id: 'cloudflare', group: 'infrastructure', size: 50, category: 'cdn' }
  ],
  links: [
    { source: 'react', target: 'express', value: 10 },
    { source: 'express', target: 'postgresql', value: 8 },
    { source: 'express', target: 'redis', value: 6 },
    { source: 'express', target: 'stripe', value: 4 },
    { source: 'express', target: 'sendgrid', value: 3 },
    { source: 'express', target: 'aws-s3', value: 5 },
    { source: 'react', target: 'cloudflare', value: 7 }
  ]
}

const codeQualityMetrics = [
  { module: 'Authentication', complexity: 8.2, maintainability: 75, testCoverage: 85, bugs: 3, codeSmells: 12 },
  { module: 'Payment', complexity: 9.1, maintainability: 68, testCoverage: 78, bugs: 5, codeSmells: 18 },
  { module: 'UserManagement', complexity: 6.5, maintainability: 82, testCoverage: 92, bugs: 1, codeSmells: 8 },
  { module: 'Reporting', complexity: 7.3, maintainability: 79, testCoverage: 80, bugs: 2, codeSmells: 15 },
  { module: 'Dashboard', complexity: 5.8, maintainability: 88, testCoverage: 88, bugs: 1, codeSmells: 6 },
  { module: 'API Gateway', complexity: 4.9, maintainability: 91, testCoverage: 95, bugs: 0, codeSmells: 4 }
]

const performanceHeatmap = [
  { component: 'LoginForm', loadTime: 120, renderTime: 45, memoryUsage: 2.1 },
  { component: 'Dashboard', loadTime: 340, renderTime: 78, memoryUsage: 5.8 },
  { component: 'ReportViewer', loadTime: 890, renderTime: 156, memoryUsage: 12.3 },
  { component: 'PaymentForm', loadTime: 210, renderTime: 62, memoryUsage: 3.4 },
  { component: 'UserProfile', loadTime: 180, renderTime: 51, memoryUsage: 2.9 },
  { component: 'Analytics', loadTime: 560, renderTime: 123, memoryUsage: 8.7 }
]

const securityFlow = [
  { stage: 'Input Validation', passed: 89, failed: 11, severity: 'medium' },
  { stage: 'Authentication', passed: 95, failed: 5, severity: 'high' },
  { stage: 'Authorization', passed: 92, failed: 8, severity: 'high' },
  { stage: 'Data Encryption', passed: 87, failed: 13, severity: 'critical' },
  { stage: 'Output Encoding', passed: 94, failed: 6, severity: 'medium' },
  { stage: 'Error Handling', passed: 78, failed: 22, severity: 'low' }
]

const architectureLayers = [
  { name: 'Presentation Layer', components: 47, complexity: 6.2, dependencies: 12 },
  { name: 'Business Logic', components: 23, complexity: 8.5, dependencies: 18 },
  { name: 'Data Access', components: 15, complexity: 7.1, dependencies: 8 },
  { name: 'Infrastructure', components: 11, complexity: 4.8, dependencies: 22 }
]

const realTimeMetrics = [
  { time: '00:00', cpu: 45, memory: 62, requests: 120, errors: 2 },
  { time: '00:15', cpu: 52, memory: 65, requests: 145, errors: 1 },
  { time: '00:30', cpu: 48, memory: 68, requests: 138, errors: 3 },
  { time: '00:45', cpu: 61, memory: 71, requests: 167, errors: 2 },
  { time: '01:00', cpu: 55, memory: 64, requests: 152, errors: 1 }
]

export function AdvancedAnalysisTools({ onBack }: AdvancedAnalysisToolsProps) {
  const [activeModule, setActiveModule] = useState('dependency-mapping')
  const [realTimeEnabled, setRealTimeEnabled] = useState(true)
  const [refreshInterval, setRefreshInterval] = useState(30)
  const [filterThreshold, setFilterThreshold] = useState([5])
  const [selectedMetric, setSelectedMetric] = useState('complexity')
  const [zoomLevel, setZoomLevel] = useState(1)
  const [currentTime, setCurrentTime] = useState(new Date())

  // Simulate real-time updates
  useEffect(() => {
    if (realTimeEnabled) {
      const interval = setInterval(() => {
        setCurrentTime(new Date())
      }, refreshInterval * 1000)
      return () => clearInterval(interval)
    }
  }, [realTimeEnabled, refreshInterval])

  const getComplexityColor = (complexity: number) => {
    if (complexity > 8) return '#dc2626'
    if (complexity > 6) return '#ea580c'
    if (complexity > 4) return '#d97706'
    return '#16a34a'
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return '#dc2626'
      case 'high': return '#ea580c'
      case 'medium': return '#d97706'
      case 'low': return '#16a34a'
      default: return '#6b7280'
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              ← Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold">Advanced Analysis Suite</h1>
              <p className="text-muted-foreground">
                Deep architectural insights and real-time monitoring
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Label htmlFor="realtime">Real-time</Label>
              <Switch 
                id="realtime"
                checked={realTimeEnabled}
                onCheckedChange={setRealTimeEnabled}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Label htmlFor="refresh">Refresh (s)</Label>
              <Input
                id="refresh"
                type="number"
                value={refreshInterval}
                onChange={(e) => setRefreshInterval(parseInt(e.target.value))}
                className="w-20"
                min="5"
                max="300"
              />
            </div>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export Data
            </Button>
          </div>
        </div>

        {/* Status Bar */}
        <Card className="mb-6">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm">Live Analysis Active</span>
                </div>
                <div className="text-sm text-muted-foreground">
                  Last Update: {currentTime.toLocaleTimeString()}
                </div>
                <div className="text-sm text-muted-foreground">
                  Components Analyzed: 312 • Issues Tracked: 47 • Performance Monitors: 23
                </div>
              </div>
              <Badge variant="outline" className="bg-green-50 text-green-700">
                All Systems Operational
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Advanced Analysis Modules */}
        <Tabs value={activeModule} onValueChange={setActiveModule} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="dependency-mapping">Dependencies</TabsTrigger>
            <TabsTrigger value="performance-intelligence">Performance</TabsTrigger>
            <TabsTrigger value="technical-debt">Tech Debt</TabsTrigger>
            <TabsTrigger value="security-flow">Security Flow</TabsTrigger>
            <TabsTrigger value="architecture-analysis">Architecture</TabsTrigger>
            <TabsTrigger value="real-time-monitoring">Live Monitor</TabsTrigger>
          </TabsList>

          {/* Dependency Mapping */}
          <TabsContent value="dependency-mapping" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center">
                      <GitBranch className="h-5 w-5 mr-2" />
                      Dependency Network
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm">
                        <ZoomIn className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <ZoomOut className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm">
                        <Move className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-96 border rounded-lg bg-muted/20 relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center space-y-4">
                        <NetworkIcon className="h-16 w-16 mx-auto text-muted-foreground" />
                        <div>
                          <div className="font-medium">Interactive Dependency Graph</div>
                          <div className="text-sm text-muted-foreground">
                            Visualizing {dependencyGraph.nodes.length} nodes and {dependencyGraph.links.length} connections
                          </div>
                        </div>
                        <Button variant="outline">
                          <Play className="h-4 w-4 mr-2" />
                          Launch 3D Visualization
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Dependency Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Filter by complexity threshold</Label>
                      <Slider
                        value={filterThreshold}
                        onValueChange={setFilterThreshold}
                        max={10}
                        min={1}
                        step={1}
                        className="w-full"
                      />
                      <div className="text-sm text-muted-foreground">
                        Showing dependencies with complexity ≥ {filterThreshold[0]}
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-3">
                      <h4 className="font-medium">Critical Dependencies</h4>
                      {dependencyGraph.nodes
                        .filter(node => node.size > 60)
                        .map((node, index) => (
                          <div key={index} className="flex items-center justify-between p-2 border rounded">
                            <div>
                              <div className="font-medium text-sm">{node.id}</div>
                              <div className="text-xs text-muted-foreground">{node.category}</div>
                            </div>
                            <Badge variant="outline" className={
                              node.size > 100 ? "bg-red-50 text-red-700" :
                              node.size > 80 ? "bg-yellow-50 text-yellow-700" :
                              "bg-green-50 text-green-700"
                            }>
                              {node.size > 100 ? 'High' : node.size > 80 ? 'Medium' : 'Low'}
                            </Badge>
                          </div>
                        ))}
                    </div>

                    <Alert>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>Circular Dependencies Detected</AlertTitle>
                      <AlertDescription>
                        Found 3 circular dependency chains that may impact build performance.
                      </AlertDescription>
                    </Alert>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Dependency Health Matrix</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {dependencyGraph.nodes.map((node, index) => (
                    <div key={index} className="p-4 border rounded-lg text-center">
                      <div className="font-medium text-sm mb-2">{node.id}</div>
                      <div 
                        className="w-full h-2 rounded-full mb-2"
                        style={{ 
                          backgroundColor: node.size > 80 ? '#dc2626' : 
                                         node.size > 60 ? '#d97706' : '#16a34a' 
                        }}
                      ></div>
                      <div className="text-xs text-muted-foreground">
                        Impact: {node.size}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Performance Intelligence */}
          <TabsContent value="performance-intelligence" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Cpu className="h-5 w-5 mr-2" />
                    Performance Heatmap
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Label>Metric:</Label>
                      <select 
                        value={selectedMetric}
                        onChange={(e) => setSelectedMetric(e.target.value)}
                        className="px-3 py-1 border rounded text-sm"
                      >
                        <option value="loadTime">Load Time</option>
                        <option value="renderTime">Render Time</option>
                        <option value="memoryUsage">Memory Usage</option>
                      </select>
                    </div>
                    
                    <div className="grid grid-cols-1 gap-2">
                      {performanceHeatmap.map((item, index) => (
                        <div key={index} className="flex items-center space-x-4 p-2 border rounded">
                          <div className="w-24 text-sm font-medium">{item.component}</div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2">
                              <div 
                                className="h-6 rounded flex items-center justify-center text-white text-xs font-medium"
                                style={{ 
                                  width: `${Math.min(100, (item[selectedMetric as keyof typeof item] as number) / 10)}%`,
                                  backgroundColor: (item[selectedMetric as keyof typeof item] as number) > 500 ? '#dc2626' :
                                                 (item[selectedMetric as keyof typeof item] as number) > 200 ? '#d97706' : '#16a34a'
                                }}
                              >
                                {item[selectedMetric as keyof typeof item]}{selectedMetric === 'memoryUsage' ? 'MB' : 'ms'}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Resource Usage Trends</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={realTimeMetrics}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="cpu" stroke="#8884d8" name="CPU %" />
                      <Line type="monotone" dataKey="memory" stroke="#82ca9d" name="Memory %" />
                      <Line type="monotone" dataKey="requests" stroke="#ffc658" name="Requests/min" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Performance Bottlenecks</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Memory Leak Detected</AlertTitle>
                    <AlertDescription>
                      ReportViewer component showing 15% memory increase over 24h
                    </AlertDescription>
                  </Alert>
                  
                  <Alert>
                    <Clock className="h-4 w-4" />
                    <AlertTitle>Slow Query Identified</AlertTitle>
                    <AlertDescription>
                      Database query in Analytics taking avg 2.3s to complete
                    </AlertDescription>
                  </Alert>
                  
                  <Alert>
                    <CheckCircle className="h-4 w-4" />
                    <AlertTitle>CDN Optimization</AlertTitle>
                    <AlertDescription>
                      Static assets cached effectively, 98% hit rate achieved
                    </AlertDescription>
                  </Alert>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Technical Debt Analysis */}
          <TabsContent value="technical-debt" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Bug className="h-5 w-5 mr-2" />
                    Code Quality Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <ScatterChart data={codeQualityMetrics}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="complexity" name="Complexity" />
                      <YAxis dataKey="maintainability" name="Maintainability" />
                      <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                      <Scatter dataKey="maintainability" fill="#8884d8" />
                    </ScatterChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Technical Debt Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {codeQualityMetrics.map((metric, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{metric.module}</span>
                          <Badge 
                            variant="outline" 
                            style={{ 
                              backgroundColor: getComplexityColor(metric.complexity) + '20',
                              color: getComplexityColor(metric.complexity)
                            }}
                          >
                            {metric.complexity.toFixed(1)}
                          </Badge>
                        </div>
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span>Maintainability</span>
                            <span>{metric.maintainability}%</span>
                          </div>
                          <Progress value={metric.maintainability} className="h-1" />
                        </div>
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Bugs: {metric.bugs}</span>
                          <span>Code Smells: {metric.codeSmells}</span>
                          <span>Coverage: {metric.testCoverage}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Debt Remediation Roadmap</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">Critical Issues</h4>
                        <Badge className="bg-red-100 text-red-800">High Priority</Badge>
                      </div>
                      <div className="text-2xl font-bold mb-2">$340K</div>
                      <div className="text-sm text-muted-foreground">
                        Estimated technical debt requiring immediate attention
                      </div>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">Medium Priority</h4>
                        <Badge className="bg-yellow-100 text-yellow-800">Medium Priority</Badge>
                      </div>
                      <div className="text-2xl font-bold mb-2">$180K</div>
                      <div className="text-sm text-muted-foreground">
                        Technical debt to address in next quarter
                      </div>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">Future Optimization</h4>
                        <Badge className="bg-green-100 text-green-800">Low Priority</Badge>
                      </div>
                      <div className="text-2xl font-bold mb-2">$95K</div>
                      <div className="text-sm text-muted-foreground">
                        Long-term improvements and optimizations
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security Flow Analysis */}
          <TabsContent value="security-flow" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="h-5 w-5 mr-2" />
                  Security Pipeline Analysis
                </CardTitle>
                <CardDescription>
                  Real-time security validation across the entire application flow
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {securityFlow.map((stage, index) => (
                      <Card key={index}>
                        <CardContent className="pt-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-sm">{stage.stage}</span>
                            <Badge 
                              variant="outline"
                              style={{
                                backgroundColor: getSeverityColor(stage.severity) + '20',
                                color: getSeverityColor(stage.severity)
                              }}
                            >
                              {stage.severity}
                            </Badge>
                          </div>
                          
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>Passed: {stage.passed}%</span>
                              <span>Failed: {stage.failed}%</span>
                            </div>
                            <Progress value={stage.passed} className="h-2" />
                          </div>
                          
                          <div className="mt-3 text-xs text-muted-foreground">
                            {stage.failed > 15 ? '⚠️ Requires immediate attention' :
                             stage.failed > 10 ? '⚡ Monitor closely' :
                             '✅ Within acceptable range'}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  <Alert>
                    <Lock className="h-4 w-4" />
                    <AlertTitle>Security Recommendation</AlertTitle>
                    <AlertDescription>
                      Data Encryption stage showing 13% failure rate. Consider implementing additional encryption layers for sensitive data paths.
                    </AlertDescription>
                  </Alert>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Threat Detection Timeline</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={[
                      { time: '6h ago', threats: 12, blocked: 11, investigated: 1 },
                      { time: '5h ago', threats: 8, blocked: 7, investigated: 1 },
                      { time: '4h ago', threats: 15, blocked: 14, investigated: 1 },
                      { time: '3h ago', threats: 6, blocked: 6, investigated: 0 },
                      { time: '2h ago', threats: 23, blocked: 21, investigated: 2 },
                      { time: '1h ago', threats: 11, blocked: 10, investigated: 1 },
                      { time: 'now', threats: 4, blocked: 4, investigated: 0 }
                    ]}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Area type="monotone" dataKey="threats" stackId="1" stroke="#dc2626" fill="#dc2626" fillOpacity={0.3} />
                      <Area type="monotone" dataKey="blocked" stackId="1" stroke="#16a34a" fill="#16a34a" fillOpacity={0.3} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Vulnerability Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        dataKey="count"
                        data={[
                          { name: 'Injection', count: 8, color: '#dc2626' },
                          { name: 'Auth Issues', count: 12, color: '#ea580c' },
                          { name: 'Data Exposure', count: 15, color: '#d97706' },
                          { name: 'Config Issues', count: 6, color: '#65a30d' },
                          { name: 'Other', count: 6, color: '#6b7280' }
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                      >
                        {[
                          { name: 'Injection', count: 8, color: '#dc2626' },
                          { name: 'Auth Issues', count: 12, color: '#ea580c' },
                          { name: 'Data Exposure', count: 15, color: '#d97706' },
                          { name: 'Config Issues', count: 6, color: '#65a30d' },
                          { name: 'Other', count: 6, color: '#6b7280' }
                        ].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Architecture Analysis */}
          <TabsContent value="architecture-analysis" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Layers className="h-5 w-5 mr-2" />
                  Architectural Layer Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {architectureLayers.map((layer, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium">{layer.name}</h4>
                          <div className="text-sm text-muted-foreground">
                            {layer.components} components • {layer.dependencies} dependencies
                          </div>
                        </div>
                        <Badge 
                          variant="outline"
                          style={{
                            backgroundColor: getComplexityColor(layer.complexity) + '20',
                            color: getComplexityColor(layer.complexity)
                          }}
                        >
                          Complexity: {layer.complexity}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 text-center text-sm">
                        <div>
                          <div className="font-medium">{layer.components}</div>
                          <div className="text-muted-foreground">Components</div>
                        </div>
                        <div>
                          <div className="font-medium">{layer.complexity}</div>
                          <div className="text-muted-foreground">Complexity</div>
                        </div>
                        <div>
                          <div className="font-medium">{layer.dependencies}</div>
                          <div className="text-muted-foreground">Dependencies</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Component Coupling Matrix</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 border rounded-lg bg-muted/20 flex items-center justify-center">
                    <div className="text-center">
                      <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                      <div className="font-medium">Interactive Coupling Matrix</div>
                      <div className="text-sm text-muted-foreground">
                        Hover to explore component relationships
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Architectural Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <RadarChart data={architectureLayers}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="name" />
                      <PolarRadiusAxis angle={90} domain={[0, 10]} />
                      <Radar 
                        name="Complexity" 
                        dataKey="complexity" 
                        stroke="#8884d8" 
                        fill="#8884d8" 
                        fillOpacity={0.3} 
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Real-time Monitoring */}
          <TabsContent value="real-time-monitoring" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">CPU Usage</p>
                      <p className="text-2xl font-bold">
                        {realTimeMetrics[realTimeMetrics.length - 1]?.cpu}%
                      </p>
                    </div>
                    <Cpu className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Memory</p>
                      <p className="text-2xl font-bold">
                        {realTimeMetrics[realTimeMetrics.length - 1]?.memory}%
                      </p>
                    </div>
                    <HardDrive className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Requests/min</p>
                      <p className="text-2xl font-bold">
                        {realTimeMetrics[realTimeMetrics.length - 1]?.requests}
                      </p>
                    </div>
                    <Activity className="h-8 w-8 text-purple-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Errors</p>
                      <p className="text-2xl font-bold">
                        {realTimeMetrics[realTimeMetrics.length - 1]?.errors}
                      </p>
                    </div>
                    <AlertTriangle className="h-8 w-8 text-red-600" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Monitor className="h-5 w-5 mr-2" />
                  Live System Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={realTimeMetrics}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="cpu" stroke="#3b82f6" strokeWidth={2} name="CPU %" />
                    <Line type="monotone" dataKey="memory" stroke="#10b981" strokeWidth={2} name="Memory %" />
                    <Line type="monotone" dataKey="requests" stroke="#8b5cf6" strokeWidth={2} name="Requests" />
                    <Line type="monotone" dataKey="errors" stroke="#ef4444" strokeWidth={2} name="Errors" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>System Health Alerts</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <div className="flex-1">
                          <div className="text-sm font-medium">Database Connection Pool Healthy</div>
                          <div className="text-xs text-muted-foreground">All connections active, 5% utilization</div>
                        </div>
                        <span className="text-xs text-muted-foreground">2min ago</span>
                      </div>
                      
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        <div className="flex-1">
                          <div className="text-sm font-medium">High Memory Usage Detected</div>
                          <div className="text-xs text-muted-foreground">Memory usage at 78%, consider investigation</div>
                        </div>
                        <span className="text-xs text-muted-foreground">5min ago</span>
                      </div>
                      
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <div className="flex-1">
                          <div className="text-sm font-medium">CDN Cache Hit Rate Optimal</div>
                          <div className="text-xs text-muted-foreground">98.2% cache hit rate maintained</div>
                        </div>
                        <span className="text-xs text-muted-foreground">8min ago</span>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Performance Predictions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">Next Hour Forecast</span>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700">Normal</Badge>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Expected CPU: 52-58% • Memory: 65-72% • Requests: 140-160/min
                      </div>
                    </div>
                    
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">Peak Traffic Window</span>
                        <Badge variant="outline" className="bg-yellow-50 text-yellow-700">Monitor</Badge>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        2:00-4:00 PM predicted 40% traffic increase
                      </div>
                    </div>
                    
                    <div className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">Resource Scaling</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">Ready</Badge>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Auto-scaling configured for 75% threshold
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}