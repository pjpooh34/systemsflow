import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Badge } from "./ui/badge"
import { Button } from "./ui/button"
import { Progress } from "./ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "./ui/alert"
import { Separator } from "./ui/separator"
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Area, AreaChart
} from 'recharts'
import { 
  Shield, AlertTriangle, CheckCircle, Clock, Users, Code, 
  Database, Server, Lock, TrendingUp, FileText, GitBranch,
  ArrowLeft, Download, Share, Eye
} from "lucide-react"

const performanceData = [
  { name: 'API Response', current: 245, target: 200, unit: 'ms' },
  { name: 'Database Query', current: 89, target: 100, unit: 'ms' },
  { name: 'Memory Usage', current: 78, target: 80, unit: '%' },
  { name: 'CPU Usage', current: 65, target: 70, unit: '%' },
]

const complexityData = [
  { name: 'Authentication', complexity: 8, maintainability: 7 },
  { name: 'Payment Processing', complexity: 9, maintainability: 6 },
  { name: 'User Management', complexity: 6, maintainability: 8 },
  { name: 'Reporting', complexity: 7, maintainability: 7 },
  { name: 'API Gateway', complexity: 5, maintainability: 9 },
]

const securityData = [
  { severity: 'Critical', count: 2, color: '#dc2626' },
  { severity: 'High', count: 7, color: '#ea580c' },
  { severity: 'Medium', count: 15, color: '#d97706' },
  { severity: 'Low', count: 23, color: '#65a30d' },
]

const techDebtData = [
  { month: 'Jan', debt: 45, velocity: 12 },
  { month: 'Feb', debt: 52, velocity: 11 },
  { month: 'Mar', debt: 48, velocity: 13 },
  { month: 'Apr', debt: 44, velocity: 14 },
  { month: 'May', debt: 39, velocity: 15 },
  { month: 'Jun', debt: 35, velocity: 16 },
]

interface DemoReportProps {
  onBack: () => void
}

export function DemoReport({ onBack }: DemoReportProps) {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Landing
            </Button>
            <div>
              <h1 className="text-3xl font-bold">TechCorp SaaS Analysis Report</h1>
              <p className="text-muted-foreground">Customer Support Platform • Generated: Dec 15, 2024</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Share className="h-4 w-4 mr-2" />
              Share
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export PDF
            </Button>
            <Button size="sm">
              <Eye className="h-4 w-4 mr-2" />
              Live Demo
            </Button>
          </div>
        </div>

        {/* Executive Summary */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Executive Summary
            </CardTitle>
            <CardDescription>
              Comprehensive analysis of a $45M customer support SaaS platform acquisition target
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">8.2/10</div>
                <div className="text-sm text-muted-foreground">Overall Score</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">$2.1M</div>
                <div className="text-sm text-muted-foreground">Hidden Tech Debt</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">6-8 months</div>
                <div className="text-sm text-muted-foreground">Integration Timeline</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">312</div>
                <div className="text-sm text-muted-foreground">Components Analyzed</div>
              </div>
            </div>
            
            <Alert className="mb-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Key Findings</AlertTitle>
              <AlertDescription>
                Strong architecture with modern tech stack. Critical security vulnerabilities require immediate attention. 
                Performance optimization needed for scale. Well-documented codebase facilitates team transition.
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span className="text-sm">Modern React/Node.js stack</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span className="text-sm">Comprehensive test coverage</span>
              </div>
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-4 w-4 text-yellow-600" />
                <span className="text-sm">2 critical security issues</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Detailed Analysis Tabs */}
        <Tabs defaultValue="architecture" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="architecture">Architecture</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="techdebt">Tech Debt</TabsTrigger>
            <TabsTrigger value="team">Team Insights</TabsTrigger>
            <TabsTrigger value="dataflow">Data Flow</TabsTrigger>
          </TabsList>

          {/* Architecture Analysis */}
          <TabsContent value="architecture" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Server className="h-5 w-5 mr-2" />
                    Architecture Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Frontend (React)</span>
                      <Badge variant="secondary">47 components</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Backend (Node.js)</span>
                      <Badge variant="secondary">23 services</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Database (PostgreSQL)</span>
                      <Badge variant="secondary">89 tables</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Cache Layer (Redis)</span>
                      <Badge variant="secondary">12 cache keys</Badge>
                    </div>
                    <Separator />
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Modularity Score</span>
                        <span className="text-sm font-medium">8.5/10</span>
                      </div>
                      <Progress value={85} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Scalability Rating</span>
                        <span className="text-sm font-medium">7.8/10</span>
                      </div>
                      <Progress value={78} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Component Complexity Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={complexityData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="complexity" fill="#8884d8" name="Complexity" />
                      <Bar dataKey="maintainability" fill="#82ca9d" name="Maintainability" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Dependencies & Integration Points</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-medium">External APIs</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>Stripe Payments</span>
                        <Badge variant="outline">Critical</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>SendGrid Email</span>
                        <Badge variant="outline">High</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Twilio SMS</span>
                        <Badge variant="outline">Medium</Badge>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-medium">Third-party Libraries</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>React 18.2.0</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">Current</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Express 4.18.1</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">Current</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Lodash 4.17.20</span>
                        <Badge variant="outline" className="bg-yellow-50 text-yellow-700">Outdated</Badge>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-medium">Infrastructure</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>AWS EC2</span>
                        <Badge variant="outline">Production</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>RDS PostgreSQL</span>
                        <Badge variant="outline">Production</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>CloudFront CDN</span>
                        <Badge variant="outline">Production</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security Analysis */}
          <TabsContent value="security" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="h-5 w-5 mr-2" />
                    Security Assessment
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Overall Security Score</span>
                        <span className="text-sm font-medium">7.2/10</span>
                      </div>
                      <Progress value={72} className="h-2" />
                    </div>
                    
                    <Alert>
                      <Lock className="h-4 w-4" />
                      <AlertTitle>Critical Issues Found</AlertTitle>
                      <AlertDescription>
                        2 critical vulnerabilities require immediate attention before acquisition.
                      </AlertDescription>
                    </Alert>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                          <span className="text-sm">SQL Injection Vulnerability</span>
                        </div>
                        <Badge variant="destructive">Critical</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                          <span className="text-sm">Exposed API Keys</span>
                        </div>
                        <Badge variant="destructive">Critical</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                          <span className="text-sm">Missing CSRF Protection</span>
                        </div>
                        <Badge className="bg-orange-100 text-orange-800">High</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Vulnerability Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        dataKey="count"
                        data={securityData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ severity, count }) => `${severity}: ${count}`}
                        outerRadius={100}
                        fill="#8884d8"
                      >
                        {securityData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Compliance & Best Practices</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <h4 className="font-medium">Compliance Status</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">GDPR Compliance</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">Compliant</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">SOC 2 Type II</span>
                        <Badge variant="outline" className="bg-yellow-50 text-yellow-700">In Progress</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">CCPA Compliance</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">Compliant</Badge>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-medium">Security Practices</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Code Scanning</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">Automated</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Dependency Scanning</span>
                        <Badge variant="outline" className="bg-red-50 text-red-700">Missing</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Penetration Testing</span>
                        <Badge variant="outline" className="bg-yellow-50 text-yellow-700">Annual</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Performance Analysis */}
          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2" />
                    Performance Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {performanceData.map((metric, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm">{metric.name}</span>
                          <span className="text-sm font-medium">
                            {metric.current}{metric.unit}
                          </span>
                        </div>
                        <Progress 
                          value={(metric.current / metric.target) * 100} 
                          className="h-2"
                        />
                        <div className="text-xs text-muted-foreground">
                          Target: {metric.target}{metric.unit}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Load Testing Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold">1,250</div>
                        <div className="text-sm text-muted-foreground">Concurrent Users</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold">99.2%</div>
                        <div className="text-sm text-muted-foreground">Uptime</div>
                      </div>
                    </div>
                    <Separator />
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">P95 Response Time</span>
                        <span className="text-sm font-medium">340ms</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Error Rate</span>
                        <span className="text-sm font-medium">0.8%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Throughput</span>
                        <span className="text-sm font-medium">450 req/s</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Performance Optimization Opportunities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium mb-2">Database Optimization</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Query optimization could reduce response times by 30%
                    </p>
                    <Badge variant="outline" className="bg-green-50 text-green-700">High Impact</Badge>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium mb-2">CDN Implementation</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Global CDN for static assets could improve load times
                    </p>
                    <Badge variant="outline" className="bg-blue-50 text-blue-700">Medium Impact</Badge>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium mb-2">Code Splitting</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Bundle optimization for faster initial page loads
                    </p>
                    <Badge variant="outline" className="bg-blue-50 text-blue-700">Medium Impact</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Technical Debt */}
          <TabsContent value="techdebt" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Code className="h-5 w-5 mr-2" />
                    Technical Debt Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-red-600">$2.1M</div>
                      <div className="text-sm text-muted-foreground">Estimated Technical Debt</div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Code Duplication</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm">23%</span>
                          <Badge variant="outline" className="bg-yellow-50 text-yellow-700">High</Badge>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Outdated Dependencies</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm">15%</span>
                          <Badge variant="outline" className="bg-orange-50 text-orange-700">Medium</Badge>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Missing Documentation</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm">31%</span>
                          <Badge variant="outline" className="bg-red-50 text-red-700">Critical</Badge>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Test Coverage Gaps</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm">18%</span>
                          <Badge variant="outline" className="bg-yellow-50 text-yellow-700">Medium</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Debt Trend Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={techDebtData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Area 
                        type="monotone" 
                        dataKey="debt" 
                        stroke="#dc2626" 
                        fill="#dc2626" 
                        fillOpacity={0.3}
                        name="Tech Debt (days)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Remediation Roadmap</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">Phase 1: Critical Issues (Months 1-2)</h4>
                      <Badge className="bg-red-100 text-red-800">High Priority</Badge>
                    </div>
                    <ul className="text-sm text-muted-foreground space-y-1 ml-4">
                      <li>• Fix security vulnerabilities</li>
                      <li>• Update critical dependencies</li>
                      <li>• Add missing API documentation</li>
                    </ul>
                    <div className="mt-2 text-sm">
                      <span className="font-medium">Estimated effort:</span> 180 developer hours
                    </div>
                  </div>
                  
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">Phase 2: Code Quality (Months 3-4)</h4>
                      <Badge className="bg-yellow-100 text-yellow-800">Medium Priority</Badge>
                    </div>
                    <ul className="text-sm text-muted-foreground space-y-1 ml-4">
                      <li>• Refactor duplicated code</li>
                      <li>• Improve test coverage to 85%</li>
                      <li>• Implement code quality gates</li>
                    </ul>
                    <div className="mt-2 text-sm">
                      <span className="font-medium">Estimated effort:</span> 320 developer hours
                    </div>
                  </div>
                  
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">Phase 3: Optimization (Months 5-6)</h4>
                      <Badge className="bg-green-100 text-green-800">Low Priority</Badge>
                    </div>
                    <ul className="text-sm text-muted-foreground space-y-1 ml-4">
                      <li>• Performance optimizations</li>
                      <li>• Architecture modernization</li>
                      <li>• Advanced monitoring setup</li>
                    </ul>
                    <div className="mt-2 text-sm">
                      <span className="font-medium">Estimated effort:</span> 240 developer hours
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Team Insights */}
          <TabsContent value="team" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="h-5 w-5 mr-2" />
                    Team Knowledge Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold">12</div>
                        <div className="text-sm text-muted-foreground">Developers</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold">8.5/10</div>
                        <div className="text-sm text-muted-foreground">Knowledge Score</div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Frontend (React)</span>
                          <span className="text-sm">9 developers</span>
                        </div>
                        <Progress value={90} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Backend (Node.js)</span>
                          <span className="text-sm">7 developers</span>
                        </div>
                        <Progress value={85} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Database (PostgreSQL)</span>
                          <span className="text-sm">4 developers</span>
                        </div>
                        <Progress value={60} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">DevOps (AWS)</span>
                          <span className="text-sm">2 developers</span>
                        </div>
                        <Progress value={40} className="h-2" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Key Contributors</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">Sarah Chen</div>
                        <div className="text-sm text-muted-foreground">Lead Frontend Developer</div>
                      </div>
                      <Badge variant="outline">Core contributor</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">Mark Rodriguez</div>
                        <div className="text-sm text-muted-foreground">Backend Architect</div>
                      </div>
                      <Badge variant="outline">Core contributor</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">Alex Kim</div>
                        <div className="text-sm text-muted-foreground">DevOps Engineer</div>
                      </div>
                      <Badge variant="outline">Infrastructure</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">Emma Thompson</div>
                        <div className="text-sm text-muted-foreground">QA Lead</div>
                      </div>
                      <Badge variant="outline">Quality assurance</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Integration Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <h4 className="font-medium">Retention Strategy</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Retain all core contributors for 12+ months</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Provide growth opportunities and training</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span>Establish mentorship programs</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-medium">Knowledge Transfer</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-blue-600" />
                        <span>4-week structured handover period</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-blue-600" />
                        <span>Comprehensive documentation review</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-blue-600" />
                        <span>Cross-training sessions with acquiring team</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Data Flow Analysis */}
          <TabsContent value="dataflow" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Database className="h-5 w-5 mr-2" />
                    Data Architecture
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold">47</div>
                        <div className="text-sm text-muted-foreground">Data Flows</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold">89</div>
                        <div className="text-sm text-muted-foreground">Database Tables</div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Customer Data</span>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700">GDPR Compliant</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Payment Information</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">PCI DSS Level 1</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Analytics Data</span>
                        <Badge variant="outline" className="bg-yellow-50 text-yellow-700">Anonymized</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Audit Logs</span>
                        <Badge variant="outline" className="bg-purple-50 text-purple-700">Immutable</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Data Privacy & Compliance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Alert>
                      <Shield className="h-4 w-4" />
                      <AlertTitle>Privacy Assessment</AlertTitle>
                      <AlertDescription>
                        All customer data handling complies with GDPR, CCPA, and SOX requirements.
                      </AlertDescription>
                    </Alert>
                    
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Data Encryption</span>
                          <span className="text-sm font-medium">AES-256</span>
                        </div>
                        <Progress value={100} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Access Controls</span>
                          <span className="text-sm font-medium">RBAC Enabled</span>
                        </div>
                        <Progress value={95} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">Audit Trail</span>
                          <span className="text-sm font-medium">Complete</span>
                        </div>
                        <Progress value={100} className="h-2" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Critical Data Flows</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">User Registration Flow</h4>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <div>1. Email validation & verification</div>
                        <div>2. Password hashing (bcrypt)</div>
                        <div>3. Profile data encryption</div>
                        <div>4. Welcome email trigger</div>
                      </div>
                      <Badge variant="outline" className="mt-2 bg-green-50 text-green-700">Secure</Badge>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Payment Processing</h4>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <div>1. Stripe tokenization</div>
                        <div>2. Transaction logging</div>
                        <div>3. Invoice generation</div>
                        <div>4. Revenue recognition</div>
                      </div>
                      <Badge variant="outline" className="mt-2 bg-green-50 text-green-700">PCI Compliant</Badge>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Support Ticket System</h4>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <div>1. Ticket creation & assignment</div>
                        <div>2. SLA tracking</div>
                        <div>3. Customer communication log</div>
                        <div>4. Resolution & feedback</div>
                      </div>
                      <Badge variant="outline" className="mt-2 bg-blue-50 text-blue-700">Optimized</Badge>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Analytics Pipeline</h4>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <div>1. Event collection</div>
                        <div>2. Data transformation</div>
                        <div>3. Real-time dashboards</div>
                        <div>4. Scheduled reports</div>
                      </div>
                      <Badge variant="outline" className="mt-2 bg-purple-50 text-purple-700">Real-time</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}