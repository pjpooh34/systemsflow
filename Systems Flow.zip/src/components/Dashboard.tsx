import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Badge } from "./ui/badge"
import { Progress } from "./ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar"
import { Separator } from "./ui/separator"
import { Alert, AlertDescription, AlertTitle } from "./ui/alert"
import { AnimatedCard, StaggeredCards } from "./ui/animated-card"
import { LoadingSpinner } from "./ui/loading-spinner"
import { FloatingActionButton } from "./ui/floating-action-button"
import { motion } from "motion/react"
import { useAuth } from "../contexts/AuthContext"
import { ReportsAnalytics } from "./ReportsAnalytics"
import { ProjectTemplates } from "./ProjectTemplates"
import { BillingDashboard } from "./BillingDashboard"
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts'
import {
  FileText, Plus, Download, Share, Eye, Settings, Bell, CreditCard,
  Calendar, Clock, CheckCircle, AlertTriangle, TrendingUp, Users, Zap,
  Github, GitlabIcon as GitLab, Upload, Star, Award, Target, Database,
  Shield, Code, Activity, Filter, Search, MoreVertical, BookTemplate, BarChart3
} from "lucide-react"

interface DashboardProps {
  onBack: () => void
  onOpenAnalysis?: () => void
  onOpenReports?: () => void
  onOpenTemplates?: () => void
  onOpenIntegrations?: () => void
  onOpenSystemHealth?: () => void
}

// Mock data for dashboard
const recentProjects = [
  {
    id: 1,
    name: "TechCorp Customer Platform",
    status: "completed",
    type: "Core Report",
    date: "2024-12-10",
    score: 8.2,
    issues: 12,
    size: "Large"
  },
  {
    id: 2,
    name: "StartupXYZ Analytics Engine",
    status: "in_progress",
    type: "Pro Report",
    date: "2024-12-14",
    score: null,
    issues: null,
    size: "Medium"
  },
  {
    id: 3,
    name: "Enterprise CRM System",
    status: "pending",
    type: "Portfolio",
    date: "2024-12-15",
    score: null,
    issues: null,
    size: "Enterprise"
  }
]

const usageData = [
  { month: 'Aug', reports: 4, hours: 12 },
  { month: 'Sep', reports: 7, hours: 18 },
  { month: 'Oct', reports: 12, hours: 28 },
  { month: 'Nov', reports: 8, hours: 22 },
  { month: 'Dec', reports: 15, hours: 35 }
]

const securityTrends = [
  { name: 'Critical', current: 2, previous: 5, color: '#dc2626' },
  { name: 'High', current: 8, previous: 12, color: '#ea580c' },
  { name: 'Medium', current: 15, previous: 18, color: '#d97706' },
  { name: 'Low', current: 23, previous: 28, color: '#65a30d' }
]

const activityFeed = [
  { type: 'report_completed', project: 'TechCorp Customer Platform', time: '2 hours ago' },
  { type: 'analysis_started', project: 'StartupXYZ Analytics Engine', time: '5 hours ago' },
  { type: 'subscription_renewed', project: 'Pro Plan', time: '1 day ago' },
  { type: 'team_member_added', project: 'Development Team', time: '2 days ago' },
  { type: 'report_shared', project: 'Enterprise CRM System', time: '3 days ago' }
]

export function Dashboard({ 
  onBack, 
  onOpenAnalysis, 
  onOpenReports, 
  onOpenTemplates,
  onOpenIntegrations,
  onOpenSystemHealth 
}: DashboardProps) {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState('overview')
  const [currentView, setCurrentView] = useState<'main' | 'reports' | 'templates' | 'billing'>('main')

  if (currentView === 'reports') {
    return <ReportsAnalytics onBack={() => setCurrentView('main')} />
  }

  if (currentView === 'templates') {
    return <ProjectTemplates 
      onBack={() => setCurrentView('main')} 
      onProjectCreated={() => setCurrentView('main')}
    />
  }

  if (currentView === 'billing') {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" onClick={() => setCurrentView('main')}>
                ← Back to Dashboard
              </Button>
              <div>
                <h1 className="text-3xl font-bold">Billing & Payments</h1>
                <p className="text-muted-foreground">Manage your subscription and billing information</p>
              </div>
            </div>
          </div>
          <BillingDashboard />
        </div>
      </div>
    )
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-50 text-green-700'
      case 'in_progress': return 'bg-blue-50 text-blue-700'
      case 'pending': return 'bg-yellow-50 text-yellow-700'
      case 'failed': return 'bg-red-50 text-red-700'
      default: return 'bg-gray-50 text-gray-700'
    }
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'report_completed': return <CheckCircle className="h-4 w-4 text-green-600" />
      case 'analysis_started': return <Activity className="h-4 w-4 text-blue-600" />
      case 'subscription_renewed': return <CreditCard className="h-4 w-4 text-purple-600" />
      case 'team_member_added': return <Users className="h-4 w-4 text-orange-600" />
      case 'report_shared': return <Share className="h-4 w-4 text-gray-600" />
      default: return <Bell className="h-4 w-4 text-gray-600" />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              ← Back to Home
            </Button>
            <div>
              <h1 className="text-3xl font-bold">Dashboard</h1>
              <p className="text-muted-foreground">Welcome back, {user?.user_metadata?.name || 'User'}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Bell className="h-4 w-4 mr-2" />
              Notifications
            </Button>
            <Button variant="outline" size="sm" onClick={() => setCurrentView('billing')}>
              <CreditCard className="h-4 w-4 mr-2" />
              Billing
            </Button>
            <Button variant="outline" size="sm" onClick={() => setCurrentView('templates')}>
              <BookTemplate className="h-4 w-4 mr-2" />
              Templates
            </Button>
            <Button variant="outline" size="sm" onClick={() => setCurrentView('reports')}>
              <BarChart3 className="h-4 w-4 mr-2" />
              Reports
            </Button>
            <Button size="sm" onClick={onOpenAnalysis}>
              <Plus className="h-4 w-4 mr-2" />
              New Analysis
            </Button>
          </div>
        </div>

        {/* Quick Stats */}
        <StaggeredCards className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {[
            {
              title: "Total Reports",
              value: "46",
              change: "+12% from last month",
              icon: <FileText className="h-8 w-8 text-blue-600" />,
              color: "text-blue-600"
            },
            {
              title: "Active Projects", 
              value: "8",
              change: "3 in progress",
              icon: <Activity className="h-8 w-8 text-green-600" />,
              color: "text-green-600"
            },
            {
              title: "Analysis Hours",
              value: "143", 
              change: "This month",
              icon: <Clock className="h-8 w-8 text-purple-600" />,
              color: "text-purple-600"
            },
            {
              title: "Team Members",
              value: "12",
              change: "+2 this week", 
              icon: <Users className="h-8 w-8 text-orange-600" />,
              color: "text-orange-600"
            }
          ].map((stat, index) => (
            <AnimatedCard key={index} hoverScale fadeIn delay={index * 0.1}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                  </div>
                  {stat.icon}
                </div>
                <p className="text-xs text-muted-foreground mt-2">{stat.change}</p>
              </CardContent>
            </AnimatedCard>
          ))}
        </StaggeredCards>

        {/* Main Dashboard Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Recent Activity */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="h-5 w-5 mr-2" />
                    Recent Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {activityFeed.map((activity, index) => (
                      <div key={index} className="flex items-center space-x-3 p-3 border rounded-lg">
                        {getActivityIcon(activity.type)}
                        <div className="flex-1">
                          <div className="text-sm font-medium">
                            {activity.type.replace('_', ' ').split(' ').map(word => 
                              word.charAt(0).toUpperCase() + word.slice(1)
                            ).join(' ')}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {activity.project} • {activity.time}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Security Trends */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="h-5 w-5 mr-2" />
                    Security Trends
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {securityTrends.map((trend, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <div 
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: trend.color }}
                          ></div>
                          <span className="text-sm">{trend.name}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium">{trend.current}</span>
                          <span className={`text-xs ${
                            trend.current < trend.previous ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {trend.current < trend.previous ? '↓' : '↑'}
                            {Math.abs(trend.current - trend.previous)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Usage Analytics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Usage Analytics
                </CardTitle>
                <CardDescription>
                  Monthly reports and analysis hours
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={usageData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey="reports" 
                      stroke="#8884d8" 
                      fill="#8884d8" 
                      fillOpacity={0.3}
                      name="Reports"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="hours" 
                      stroke="#82ca9d" 
                      fill="#82ca9d" 
                      fillOpacity={0.3}
                      name="Hours"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium">Your Projects</h3>
                <p className="text-sm text-muted-foreground">Manage and track your analysis projects</p>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
                <Button size="sm" onClick={onOpenAnalysis}>
                  <Plus className="h-4 w-4 mr-2" />
                  New Analysis
                </Button>
              </div>
            </div>

            <div className="grid gap-6">
              {recentProjects.map((project) => (
                <Card key={project.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-4">
                        <div>
                          <h4 className="font-medium">{project.name}</h4>
                          <div className="flex items-center space-x-2 mt-1">
                            <Badge variant="outline" className={getStatusColor(project.status)}>
                              {project.status.replace('_', ' ')}
                            </Badge>
                            <Badge variant="outline">{project.type}</Badge>
                            <Badge variant="outline">{project.size}</Badge>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {project.status === 'completed' && (
                          <>
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4 mr-2" />
                              View
                            </Button>
                            <Button variant="outline" size="sm">
                              <Download className="h-4 w-4 mr-2" />
                              Export
                            </Button>
                          </>
                        )}
                        <Button variant="outline" size="sm">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Date</p>
                        <p className="text-sm font-medium">{project.date}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Score</p>
                        <p className="text-sm font-medium">
                          {project.score ? `${project.score}/10` : 'Pending'}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Issues Found</p>
                        <p className="text-sm font-medium">
                          {project.issues !== null ? project.issues : 'In Progress'}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Progress</p>
                        <Progress 
                          value={
                            project.status === 'completed' ? 100 :
                            project.status === 'in_progress' ? 65 :
                            10
                          } 
                          className="h-2 mt-1"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium">Analysis Reports</h3>
                <p className="text-sm text-muted-foreground">Generated reports and documentation</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search reports..."
                    className="pl-10 pr-4 py-2 border rounded-md text-sm w-64"
                  />
                </div>
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recentProjects.filter(p => p.status === 'completed').map((project) => (
                <Card key={project.id}>
                  <CardHeader>
                    <CardTitle className="text-base">{project.name}</CardTitle>
                    <CardDescription>{project.type} • {project.date}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Overall Score</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">
                          {project.score}/10
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="text-center p-2 border rounded">
                          <div className="font-medium">312</div>
                          <div className="text-muted-foreground">Components</div>
                        </div>
                        <div className="text-center p-2 border rounded">
                          <div className="font-medium">{project.issues}</div>
                          <div className="text-muted-foreground">Issues</div>
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        <Button size="sm" className="flex-1">
                          <Eye className="h-4 w-4 mr-2" />
                          View
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Share className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Report Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        dataKey="value"
                        data={[
                          { name: 'Core Report', value: 15, color: '#8884d8' },
                          { name: 'Pro Report', value: 22, color: '#82ca9d' },
                          { name: 'Portfolio', value: 9, color: '#ffc658' }
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, value }) => `${name}: ${value}`}
                        outerRadius={100}
                        fill="#8884d8"
                      >
                        {[
                          { name: 'Core Report', value: 15, color: '#8884d8' },
                          { name: 'Pro Report', value: 22, color: '#82ca9d' },
                          { name: 'Portfolio', value: 9, color: '#ffc658' }
                        ].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quality Score Trends</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={[
                      { month: 'Aug', score: 7.2 },
                      { month: 'Sep', score: 7.5 },
                      { month: 'Oct', score: 7.8 },
                      { month: 'Nov', score: 7.6 },
                      { month: 'Dec', score: 8.1 }
                    ]}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis domain={[6, 10]} />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="score" 
                        stroke="#8884d8" 
                        strokeWidth={2}
                        name="Quality Score"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Performance Insights</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">35min</div>
                    <div className="text-sm text-muted-foreground">Avg. Analysis Time</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">94%</div>
                    <div className="text-sm text-muted-foreground">Success Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">4.8</div>
                    <div className="text-sm text-muted-foreground">Satisfaction Score</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Settings className="h-5 w-5 mr-2" />
                    Account Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <Avatar>
                      <AvatarImage src="/api/placeholder/40/40" />
                      <AvatarFallback>
                        {user?.user_metadata?.name?.charAt(0) || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{user?.user_metadata?.name || 'User'}</div>
                      <div className="text-sm text-muted-foreground">{user?.email}</div>
                    </div>
                    <Button variant="outline" size="sm">Edit Profile</Button>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Email Notifications</span>
                      <Button variant="outline" size="sm">Configure</Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">API Access</span>
                      <Button variant="outline" size="sm">Manage Keys</Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Team Management</span>
                      <Button variant="outline" size="sm">Invite Members</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CreditCard className="h-5 w-5 mr-2" />
                    Subscription
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">Pro Plan</span>
                      <Badge variant="outline" className="bg-purple-50 text-purple-700">Active</Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Unlimited reports • Advanced analytics • Team collaboration
                    </div>
                    <div className="text-sm mt-2">
                      Next billing: January 15, 2025 • $699/month
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Button variant="outline" className="w-full">
                      <CreditCard className="h-4 w-4 mr-2" />
                      Manage Billing
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Target className="h-4 w-4 mr-2" />
                      Upgrade Plan
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Floating Action Button */}
      <FloatingActionButton
        actions={[
          {
            icon: <Plus className="h-4 w-4" />,
            label: "New Analysis",
            onClick: () => onOpenAnalysis?.()
          },
          {
            icon: <BookTemplate className="h-4 w-4" />,
            label: "Templates",
            onClick: () => setCurrentView('templates')
          },
          {
            icon: <BarChart3 className="h-4 w-4" />,
            label: "Reports",
            onClick: () => setCurrentView('reports')
          },
          {
            icon: <Upload className="h-4 w-4" />,
            label: "Upload",
            onClick: () => {
              // Add upload functionality
              console.log('Upload clicked')
            }
          },
          {
            icon: <Settings className="h-4 w-4" />,
            label: "Integrations",
            onClick: () => onOpenIntegrations?.()
          },
          {
            icon: <Activity className="h-4 w-4" />,
            label: "System Health",
            onClick: () => onOpenSystemHealth?.()
          }
        ]}
      />
    </div>
  )
}