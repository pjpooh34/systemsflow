import { useState, useEffect } from "react"
import { Header } from "./components/Header"
import { Hero } from "./components/Hero"
import { Features } from "./components/Features"
import { Stats } from "./components/Stats"
import { Examples } from "./components/Examples"
import { Pricing } from "./components/Pricing"
import { CTA } from "./components/CTA"
import { Footer } from "./components/Footer"
import { Demo } from "./components/Demo"
import { Dashboard } from "./components/Dashboard"
import { ProjectAnalysis } from "./components/ProjectAnalysis"
import { ReportsAnalytics } from "./components/ReportsAnalytics"
import { ProjectTemplates } from "./components/ProjectTemplates"
import { Integrations } from "./components/Integrations"
import { SystemHealth } from "./components/SystemHealth"
import { AuthProvider } from "./contexts/AuthContext"

export default function App() {
  const [currentView, setCurrentView] = useState<'landing' | 'demo' | 'dashboard' | 'analysis' | 'reports' | 'templates' | 'integrations' | 'health'>('landing')

  // Set favicon on app load
  useEffect(() => {
    const setFavicon = () => {
      // Remove all existing favicons
      const existingFavicons = document.querySelectorAll('link[rel*="icon"]')
      existingFavicons.forEach(favicon => favicon.remove())

      // Create and add new favicon with cache busting
      const timestamp = new Date().getTime()
      const favicon = document.createElement('link')
      favicon.rel = 'icon'
      favicon.type = 'image/svg+xml'
      favicon.href = `/favicon.svg?v=${timestamp}`
      document.head.appendChild(favicon)

      // Add fallback PNG favicon for older browsers
      const pngFavicon = document.createElement('link')
      pngFavicon.rel = 'icon'
      pngFavicon.type = 'image/png'
      pngFavicon.sizes = '32x32'
      pngFavicon.href = `/favicon.svg?v=${timestamp}`
      document.head.appendChild(pngFavicon)

      // Also set the page title
      document.title = 'Systems Flow - SaaS Architecture Analysis Platform'
    }

    setFavicon()
  }, [])

  if (currentView === 'demo') {
    return (
      <AuthProvider>
        <Demo 
          onBack={() => setCurrentView('landing')} 
          onOpenAnalysis={() => setCurrentView('analysis')}
        />
      </AuthProvider>
    )
  }

  if (currentView === 'dashboard') {
    return (
      <AuthProvider>
        <Dashboard 
          onBack={() => setCurrentView('landing')}
          onOpenAnalysis={() => setCurrentView('analysis')}
          onOpenReports={() => setCurrentView('reports')}
          onOpenTemplates={() => setCurrentView('templates')}
          onOpenIntegrations={() => setCurrentView('integrations')}
          onOpenSystemHealth={() => setCurrentView('health')}
        />
      </AuthProvider>
    )
  }

  if (currentView === 'analysis') {
    return (
      <AuthProvider>
        <ProjectAnalysis onBack={() => setCurrentView('dashboard')} />
      </AuthProvider>
    )
  }

  if (currentView === 'reports') {
    return (
      <AuthProvider>
        <ReportsAnalytics onBack={() => setCurrentView('dashboard')} />
      </AuthProvider>
    )
  }

  if (currentView === 'templates') {
    return (
      <AuthProvider>
        <ProjectTemplates 
          onBack={() => setCurrentView('dashboard')} 
          onProjectCreated={() => setCurrentView('dashboard')}
        />
      </AuthProvider>
    )
  }

  if (currentView === 'integrations') {
    return (
      <AuthProvider>
        <Integrations onBack={() => setCurrentView('dashboard')} />
      </AuthProvider>
    )
  }

  if (currentView === 'health') {
    return (
      <AuthProvider>
        <SystemHealth onBack={() => setCurrentView('dashboard')} />
      </AuthProvider>
    )
  }

  return (
    <AuthProvider>
      <div className="min-h-screen bg-background">
        <Header 
          onStartDemo={() => setCurrentView('demo')} 
          onOpenDashboard={() => setCurrentView('dashboard')}
        />
        <main className="space-y-0">
          <Hero onStartDemo={() => setCurrentView('demo')} />
          <Features />
          <Examples onStartDemo={() => setCurrentView('demo')} />
          <Stats />
          <Pricing 
            onStartDemo={() => setCurrentView('demo')} 
            onOpenDashboard={() => setCurrentView('dashboard')}
          />
          <CTA onStartDemo={() => setCurrentView('demo')} />
        </main>
        <Footer />
      </div>
    </AuthProvider>
  )
}