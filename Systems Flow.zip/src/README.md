# Systems Flow 🔄

A comprehensive platform for analyzing and optimizing software systems, specifically positioned as the perfect solution for SaaS acquisition due diligence.

## 🚀 Overview

Systems Flow helps teams analyze and optimize software systems with a full suite of analysis tools:

- **Codebase Intelligence** - Deep code analysis and quality metrics
- **Architecture Mapping** - Visual system architecture and dependencies
- **Security Assessment** - Vulnerability scanning and compliance tracking
- **Data Flow Analysis** - Data pipeline monitoring and optimization
- **Dependency Mapping** - Package and service dependency tracking
- **Business Logic Documentation** - Automated workflow documentation
- **Performance Intelligence** - Real-time performance monitoring
- **Team Knowledge Transfer** - Collaborative analysis and reporting
- **Technical Debt Analysis** - Code health and maintenance recommendations

## 🎯 Target Audience

- **Development Teams** - Understand and optimize codebases
- **Corporate Development Groups** - Due diligence for acquisitions
- **Private Equity Firms** - Technical assessment for SaaS investments

## 💰 Pricing Tiers

- **Free** - $0 (Basic analysis)
- **Core Report** - $299 (Standard due diligence)
- **Pro Report** - $699 (Advanced analysis)
- **Portfolio** - $999-$1,499/mo (Enterprise features)

## 🛠 Tech Stack

- **Frontend** - React + TypeScript
- **Styling** - Tailwind CSS v4
- **UI Components** - shadcn/ui
- **Charts** - Recharts
- **Icons** - Lucide React
- **Backend** - Supabase (Database, Auth, Edge Functions)
- **Server** - Hono.js on Supabase Edge Functions

## 🏗 Project Structure

```
├── App.tsx                 # Main application entry point
├── components/             # React components
│   ├── ui/                # shadcn/ui components
│   ├── figma/             # Figma import components
│   ├── Demo.tsx           # Interactive demo experience
│   ├── Dashboard.tsx      # User dashboard
│   ├── AnalysisTools.tsx  # Advanced analysis tools
│   └── ...               # Other components
├── contexts/              # React contexts (Auth, etc.)
├── services/              # API services
├── supabase/              # Supabase configuration
│   └── functions/         # Edge functions
├── styles/                # Global CSS and themes
└── utils/                 # Utility functions
```

## 🚦 Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Supabase account (for backend features)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/pjpooh34/systemsflow.git
   cd systemsflow
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env.local
   # Add your Supabase credentials
   ```

4. **Start the development server**
   ```bash
   npm run dev
   ```

5. **Open your browser**
   Navigate to `http://localhost:3000`

## 🔧 Features

### ✅ Implemented
- Interactive demo experience with realistic data
- User authentication and dashboard
- Advanced analysis tools with real AI integration
- Cost analysis and optimization recommendations
- Predictive analytics for capacity planning
- Interactive filtering and drill-down capabilities
- Responsive design for mobile and desktop

### 🚧 In Development
- Additional integrations (GitHub, GitLab, etc.)
- Advanced reporting templates
- Team collaboration features
- API for third-party integrations

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is proprietary software. All rights reserved.

## 📞 Contact

For questions, feedback, or support:
- GitHub Issues: [https://github.com/pjpooh34/systemsflow/issues](https://github.com/pjpooh34/systemsflow/issues)
- Email: [Your contact email]

---

Built with ❤️ for the developer community