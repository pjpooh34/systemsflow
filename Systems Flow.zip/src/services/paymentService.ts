import { projectId, publicAnonKey } from '../utils/supabase/info'

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-e90433f1`

export interface PaymentIntent {
  clientSecret: string
  paymentIntentId: string
}

export interface Subscription {
  subscriptionId: string
  clientSecret: string
}

export interface PaymentStatus {
  subscription: any
  purchases: any[]
  hasActiveSubscription: boolean
  hasCoreReport: boolean
  hasProReport: boolean
}

export const paymentService = {
  async createPaymentIntent(amount: number, productType: string, token: string): Promise<PaymentIntent> {
    const response = await fetch(`${API_BASE}/payments/create-intent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({
        amount,
        productType,
      }),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to create payment intent')
    }

    return response.json()
  },

  async createSubscription(priceId: string, paymentMethodId: string, token: string): Promise<Subscription> {
    const response = await fetch(`${API_BASE}/payments/create-subscription`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({
        priceId,
        paymentMethodId,
      }),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to create subscription')
    }

    return response.json()
  },

  async getPaymentMethods(token: string) {
    const response = await fetch(`${API_BASE}/payments/payment-methods`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to fetch payment methods')
    }

    return response.json()
  },

  async getSubscriptions(token: string) {
    const response = await fetch(`${API_BASE}/payments/subscriptions`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to fetch subscriptions')
    }

    return response.json()
  },

  async cancelSubscription(subscriptionId: string, token: string) {
    const response = await fetch(`${API_BASE}/payments/cancel-subscription`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({
        subscriptionId,
      }),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to cancel subscription')
    }

    return response.json()
  },

  async createPortalSession(returnUrl: string, token: string) {
    const response = await fetch(`${API_BASE}/payments/create-portal-session`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({
        returnUrl,
      }),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to create portal session')
    }

    return response.json()
  },

  async getPaymentStatus(token: string): Promise<PaymentStatus> {
    const response = await fetch(`${API_BASE}/payments/status`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to fetch payment status')
    }

    return response.json()
  },
}