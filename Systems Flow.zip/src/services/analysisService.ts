import { projectId, publicAnonKey } from '../utils/supabase/info'

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-e90433f1`

export interface Project {
  id: string
  name: string
  description?: string
  type: string
  userId: string
  status: string
  createdAt: string
  lastAnalysis?: string
  codebase?: string
  comprehensiveAnalysisId?: string
}

export interface Analysis {
  id: string
  projectId: string
  type: string
  analysis: any
  createdAt: string
  status: string
}

class AnalysisService {
  private getAuthHeaders(token: string) {
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    }
  }

  private async makeRequest(endpoint: string, options: RequestInit = {}) {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        ...options.headers,
      }
    })

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Network error' }))
      throw new Error(error.error || `HTTP ${response.status}`)
    }

    return response.json()
  }

  // Project Management
  async createProject(token: string, data: { name: string; description?: string; type: string; codebase?: string }): Promise<{ project: Project }> {
    return this.makeRequest('/projects', {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify(data)
    })
  }

  async getProjects(token: string): Promise<{ projects: Project[] }> {
    return this.makeRequest('/projects', {
      method: 'GET',
      headers: this.getAuthHeaders(token)
    })
  }

  // Analysis Methods
  async analyzeCodebase(token: string, projectId: string, codebase: string): Promise<{ analysis: any; analysisId: string }> {
    return this.makeRequest('/analyze/codebase', {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify({ projectId, codebase })
    })
  }

  async analyzeArchitecture(token: string, projectId: string, codebase?: string): Promise<{ analysis: any; analysisId: string }> {
    return this.makeRequest('/analyze/architecture', {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify({ projectId, codebase })
    })
  }

  async analyzeSecurity(token: string, projectId: string, codebase?: string): Promise<{ analysis: any; analysisId: string }> {
    return this.makeRequest('/analyze/security', {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify({ projectId, codebase })
    })
  }

  async analyzePerformance(token: string, projectId: string, codebase?: string): Promise<{ analysis: any; analysisId: string }> {
    return this.makeRequest('/analyze/performance', {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify({ projectId, codebase })
    })
  }

  async analyzeTechnicalDebt(token: string, projectId: string, codebase?: string): Promise<{ analysis: any; analysisId: string }> {
    return this.makeRequest('/analyze/technical-debt', {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify({ projectId, codebase })
    })
  }

  async analyzeDataFlow(token: string, projectId: string, codebase?: string): Promise<{ analysis: any; analysisId: string }> {
    return this.makeRequest('/analyze/data-flow', {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify({ projectId, codebase })
    })
  }

  async analyzeDependencies(token: string, projectId: string, codebase?: string): Promise<{ analysis: any; analysisId: string }> {
    return this.makeRequest('/analyze/dependencies', {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify({ projectId, codebase })
    })
  }

  async analyzeBusinessLogic(token: string, projectId: string, codebase?: string): Promise<{ analysis: any; analysisId: string }> {
    return this.makeRequest('/analyze/business-logic', {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify({ projectId, codebase })
    })
  }

  async analyzeKnowledgeTransfer(token: string, projectId: string, codebase?: string): Promise<{ analysis: any; analysisId: string }> {
    return this.makeRequest('/analyze/knowledge-transfer', {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify({ projectId, codebase })
    })
  }

  async runComprehensiveAnalysis(token: string, projectId: string, codebase: string): Promise<{ analysis: any; analysisId: string }> {
    return this.makeRequest('/analyze/comprehensive', {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify({ projectId, codebase })
    })
  }

  async getAnalysis(token: string, analysisId: string): Promise<{ analysis: Analysis }> {
    return this.makeRequest(`/analysis/${analysisId}`, {
      method: 'GET',
      headers: this.getAuthHeaders(token)
    })
  }

  async getProjectAnalyses(token: string, projectId: string): Promise<{ analyses: Analysis[] }> {
    return this.makeRequest(`/projects/${projectId}/analyses`, {
      method: 'GET',
      headers: this.getAuthHeaders(token)
    })
  }

  async generateReport(token: string, projectId: string, format: 'pdf' | 'json' | 'csv'): Promise<{ reportUrl: string }> {
    return this.makeRequest(`/reports/generate`, {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify({ projectId, format })
    })
  }

  async compareProjects(token: string, projectIds: string[]): Promise<{ comparison: any }> {
    return this.makeRequest('/analyze/compare', {
      method: 'POST',
      headers: this.getAuthHeaders(token),
      body: JSON.stringify({ projectIds })
    })
  }

  // Utility method to check if user has access to advanced features
  isAdvancedUser(userPlan?: string): boolean {
    return ['Pro Report', 'Portfolio'].includes(userPlan || '')
  }

  // Mock subscription check - in real app this would check Supabase or payment provider
  getUserSubscription(): string {
    // For demo purposes, return 'Pro Report' - in real app this would be fetched from user data
    return 'Pro Report'
  }
}

export const analysisService = new AnalysisService()