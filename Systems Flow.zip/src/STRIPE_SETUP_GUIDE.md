# 🏦 Stripe Payment Integration Setup Guide

## 📋 **Complete Setup Checklist**

### **Step 1: Stripe Dashboard Configuration**

1. **Login to your Stripe Dashboard**: https://dashboard.stripe.com

2. **Get your API Keys**:
   - Go to **Developers** → **API keys**
   - Copy your **Publishable key** (starts with `pk_`)
   - Copy your **Secret key** (starts with `sk_`)

3. **Create Products and Prices**:
   
   **A. Core Report Product**:
   - Go to **Products** → **+ Add product**
   - Name: `Core Report`
   - Description: `Comprehensive analysis for due diligence`
   - Pricing: **One-time** payment of **$299.00**
   - Copy the **Price ID** (starts with `price_`)

   **B. Pro Report Product**:
   - Go to **Products** → **+ Add product**
   - Name: `Pro Report`
   - Description: `Advanced analysis with additional insights`
   - Pricing: **One-time** payment of **$699.00**
   - Copy the **Price ID** (starts with `price_`)

   **C. Portfolio Subscription**:
   - Go to **Products** → **+ Add product**
   - Name: `Portfolio`
   - Description: `Monthly subscription for portfolio management`
   - Pricing: **Recurring** monthly subscription of **$999.00**
   - Copy the **Price ID** (starts with `price_`)

4. **Configure Webhooks**:
   - Go to **Developers** → **Webhooks**
   - Click **+ Add endpoint**
   - Endpoint URL: `https://YOUR_PROJECT_ID.supabase.co/functions/v1/make-server-e90433f1/webhooks/stripe`
   - Events to send:
     - `payment_intent.succeeded`
     - `customer.subscription.created`
     - `customer.subscription.updated`
     - `customer.subscription.deleted`
   - Copy the **Webhook signing secret** (starts with `whsec_`)

5. **Enable Customer Portal**:
   - Go to **Settings** → **Billing** → **Customer portal**
   - Click **Activate test link** or **Activate** for live mode
   - Configure the settings as needed (default settings work fine)

### **Step 2: Environment Variables Setup**

Add these environment variables to your `.env.local file`:

```bash
# Stripe Configuration
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key_here
STRIPE_SECRET_KEY=sk_test_your_secret_key_here
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret_here

# Product Price IDs (update with your actual Price IDs)
VITE_STRIPE_CORE_REPORT_PRICE_ID=price_your_core_report_price_id
VITE_STRIPE_PRO_REPORT_PRICE_ID=price_your_pro_report_price_id  
VITE_STRIPE_PORTFOLIO_PRICE_ID=price_your_portfolio_price_id
```

### **Step 3: Update Supabase Environment Variables**

1. Go to your **Supabase Dashboard**
2. Navigate to **Settings** → **Environment Variables**
3. Add these variables:
   - `STRIPE_SECRET_KEY`: Your Stripe secret key
   - `STRIPE_WEBHOOK_SECRET`: Your webhook signing secret

### **Step 4: Update PaymentModal Component**

The PaymentModal component needs the actual Price IDs. Update it:

```typescript
// In components/PaymentModal.tsx, replace the hardcoded price ID:

// You'll need to create price IDs in your Stripe dashboard
const priceId = import.meta.env.VITE_STRIPE_PORTFOLIO_PRICE_ID || 'price_1234567890'
```

## 🧪 **Testing the Integration**

### **Test Cards for Development:**

```bash
# Successful payment
4242424242424242

# Declined payment  
4000000000000002

# Requires authentication (3D Secure)
4000002500003155

# Insufficient funds
4000000000009995
```

### **Test Flow:**

1. **One-time Payments (Core/Pro Reports)**:
   - Click "Core Report" or "Pro Report" in pricing
   - Fill in test card details
   - Complete payment
   - Check webhook logs in Stripe dashboard
   - Verify purchase appears in user's billing dashboard

2. **Subscription (Portfolio)**:
   - Click "Portfolio" in pricing  
   - Fill in test card details
   - Complete subscription setup
   - Check subscription status in billing dashboard
   - Test cancellation flow

3. **Customer Portal**:
   - Go to billing dashboard
   - Click "Manage Billing"
   - Verify portal opens with subscription details
   - Test updating payment methods

## 🚀 **Go Live Checklist**

When ready for production:

1. **Switch to Live Mode**:
   - Toggle **View test data** OFF in Stripe dashboard
   - Get live API keys (pk_live_, sk_live_)
   - Update environment variables

2. **Update Webhook Endpoint**:
   - Update webhook URL to production domain
   - Regenerate webhook secret for live mode

3. **Business Verification**:
   - Complete Stripe account verification
   - Provide business details and bank account

4. **Test in Production**:
   - Make small test purchases
   - Verify webhooks work correctly
   - Test customer portal

## 🛠 **Troubleshooting**

### **Common Issues:**

1. **"No such price" error**:
   - Verify Price IDs in environment variables
   - Check you're using the correct mode (test vs live)

2. **Webhook not receiving events**:
   - Verify webhook URL is correct
   - Check webhook signing secret
   - Look at Stripe logs for delivery attempts

3. **Payment Modal not opening**:
   - Check browser console for Stripe.js loading errors
   - Verify publishable key is set correctly

4. **3D Secure authentication fails**:
   - Use test cards that support 3DS
   - Ensure proper error handling in payment flow

### **Debug Commands:**

```bash
# Check webhook deliveries
curl -H "Authorization: Bearer sk_test_..." \
  https://api.stripe.com/v1/webhook_endpoints

# Test webhook locally (if using ngrok)
stripe listen --forward-to localhost:3000/api/webhooks/stripe
```

## 📞 **Support Resources**

- **Stripe Documentation**: https://stripe.com/docs
- **Stripe Dashboard**: https://dashboard.stripe.com
- **Supabase Edge Functions**: https://supabase.com/docs/guides/functions
- **Test Cards**: https://stripe.com/docs/testing#cards

---

## 🎉 **What's Included in This Integration**

✅ **One-time Payments**: Core ($299) and Pro ($699) reports  
✅ **Subscriptions**: Portfolio tier ($999/month)  
✅ **Customer Portal**: Manage billing and subscriptions  
✅ **Webhook Handling**: Automatic payment processing  
✅ **Security**: PCI-compliant payment processing  
✅ **Mobile Support**: Responsive payment forms  
✅ **Error Handling**: Comprehensive error management  
✅ **Receipt Emails**: Automatic Stripe receipts  

Your Stripe integration is now ready for production! 🚀