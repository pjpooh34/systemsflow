# Systems Flow - File Copy Manifest

## 📋 Files to Copy from Figma Make to Local

### **Priority 1: Core Application Files**
- [ ] `App.tsx` 
- [ ] `styles/globals.css`
- [ ] `favicon.svg`

### **Priority 2: Components**
- [ ] `components/Header.tsx`
- [ ] `components/Hero.tsx`
- [ ] `components/Features.tsx`
- [ ] `components/Stats.tsx`
- [ ] `components/Examples.tsx`
- [ ] `components/Pricing.tsx`
- [ ] `components/CTA.tsx`
- [ ] `components/Footer.tsx`
- [ ] `components/Demo.tsx`
- [ ] `components/Dashboard.tsx`
- [ ] `components/ProjectAnalysis.tsx`
- [ ] `components/ReportsAnalytics.tsx`
- [ ] `components/ProjectTemplates.tsx`
- [ ] `components/Integrations.tsx`
- [ ] `components/SystemHealth.tsx`
- [ ] `components/AuthModal.tsx`
- [ ] `components/DemoReport.tsx`
- [ ] `components/AnalysisTools.tsx`
- [ ] `components/AdvancedAnalysisTools.tsx`
- [ ] `components/AdvancedAnalytics.tsx`

### **Priority 3: UI Components**
- [ ] `components/ui/button.tsx`
- [ ] `components/ui/card.tsx`
- [ ] `components/ui/dialog.tsx`
- [ ] `components/ui/dropdown-menu.tsx`
- [ ] `components/ui/input.tsx`
- [ ] `components/ui/label.tsx`
- [ ] `components/ui/select.tsx`
- [ ] `components/ui/tabs.tsx`
- [ ] `components/ui/badge.tsx`
- [ ] `components/ui/separator.tsx`
- [ ] `components/ui/skeleton.tsx`
- [ ] `components/ui/progress.tsx`
- [ ] `components/ui/chart.tsx`
- [ ] `components/ui/table.tsx`
- [ ] `components/ui/accordion.tsx`
- [ ] `components/ui/alert.tsx`
- [ ] `components/ui/avatar.tsx`
- [ ] `components/ui/checkbox.tsx`
- [ ] `components/ui/form.tsx`
- [ ] `components/ui/popover.tsx`
- [ ] `components/ui/scroll-area.tsx`
- [ ] `components/ui/sheet.tsx`
- [ ] `components/ui/slider.tsx`
- [ ] `components/ui/switch.tsx`
- [ ] `components/ui/textarea.tsx`
- [ ] `components/ui/tooltip.tsx`
- [ ] `components/ui/sonner.tsx`
- [ ] `components/ui/utils.ts`

### **Priority 4: Contexts & Services**
- [ ] `contexts/AuthContext.tsx`
- [ ] `services/analysisService.ts`

### **Priority 5: Utils & Config**
- [ ] `utils/supabase/client.ts`
- [ ] `utils/supabase/info.tsx`
- [ ] `lib/utils.ts`

### **Priority 6: Backend (Supabase)**
- [ ] `supabase/functions/server/index.tsx`
- [ ] `supabase/functions/server/kv_store.tsx`

### **Priority 7: Documentation**
- [ ] `README.md`
- [ ] `.gitignore`
- [ ] `guidelines/Guidelines.md`

## 🔄 Copy Process:

For each file:
1. Open the file in Figma Make
2. Select all content (Ctrl/Cmd + A)
3. Copy (Ctrl/Cmd + C)
4. Create the file locally: `touch filename.tsx`
5. Open in your editor and paste
6. Save the file
7. Check this item off the list ✅

## 🚨 Important Notes:

- **Do NOT copy** `components/figma/ImageWithFallback.tsx` - this is Figma-specific
- **Environment variables** will need to be set up separately
- **Dependencies** are handled by the package.json created by the setup script
- Make sure to maintain the exact file structure shown above