import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js";
import * as kv from "./kv_store.tsx";
import Stripe from "npm:stripe";

const app = new Hono();

// Enhanced logging for better debugging
app.use('*', logger((message, ...rest) => {
  console.log(`[${new Date().toISOString()}] ${message}`, ...rest);
}));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Global error handler
app.onError((err, c) => {
  console.error('Server error:', err);
  return c.json({ 
    error: 'Internal server error', 
    message: err.message,
    timestamp: new Date().toISOString()
  }, 500);
});

// Request ID middleware for better tracing
app.use('*', async (c, next) => {
  const requestId = crypto.randomUUID();
  c.set('requestId', requestId);
  c.header('X-Request-ID', requestId);
  console.log(`[${requestId}] ${c.req.method} ${c.req.url}`);
  await next();
});

// Health check endpoint
app.get("/make-server-e90433f1/health", (c) => {
  return c.json({ status: "ok" });
});

// Helper function to authenticate user
async function authenticateUser(authHeader: string | null) {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }

  const token = authHeader.split(' ')[1];
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
  );

  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    return null;
  }

  return user;
}

// Initialize Stripe
const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
  apiVersion: '2024-06-20',
});

// Helper function to get or create Stripe customer
async function getOrCreateStripeCustomer(user: any) {
  try {
    // Check if customer already exists in our KV store
    const existingCustomer = await kv.get(`stripe_customer:${user.id}`);
    if (existingCustomer && existingCustomer.stripeCustomerId) {
      return existingCustomer.stripeCustomerId;
    }

    // Create new Stripe customer
    const customer = await stripe.customers.create({
      email: user.email,
      name: user.user_metadata?.name || user.email,
      metadata: {
        supabase_user_id: user.id,
      },
    });

    // Store customer ID in KV store
    await kv.set(`stripe_customer:${user.id}`, {
      stripeCustomerId: customer.id,
      createdAt: new Date().toISOString(),
    });

    return customer.id;
  } catch (error) {
    console.error('Error creating Stripe customer:', error);
    throw error;
  }
}

// Helper function to call OpenAI API
async function callOpenAI(messages: any[], model = "gpt-4") {
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.3,
      max_tokens: 4000,
    }),
  });

  if (!response.ok) {
    throw new Error(`OpenAI API error: ${response.statusText}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

// Cache helper functions for better performance
const CACHE_TTL = 3600; // 1 hour in seconds

async function getCachedAnalysis(cacheKey: string) {
  try {
    const cached = await kv.get(`analysis_cache:${cacheKey}`);
    if (cached && cached.expires > Date.now()) {
      console.log(`Cache hit for key: ${cacheKey}`);
      return cached.data;
    }
    console.log(`Cache miss for key: ${cacheKey}`);
    return null;
  } catch (error) {
    console.error('Cache retrieval error:', error);
    return null;
  }
}

async function setCachedAnalysis(cacheKey: string, data: any) {
  try {
    await kv.set(`analysis_cache:${cacheKey}`, {
      data,
      expires: Date.now() + (CACHE_TTL * 1000),
      createdAt: new Date().toISOString()
    });
    console.log(`Cached analysis for key: ${cacheKey}`);
  } catch (error) {
    console.error('Cache storage error:', error);
  }
}

// Generate cache key for analysis
function generateCacheKey(type: string, input: string): string {
  const hash = Array.from(new TextEncoder().encode(input))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
    .substring(0, 16);
  return `${type}_${hash}`;
}

// User signup endpoint
app.post("/make-server-e90433f1/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    if (!email || !password || !name) {
      return c.json({ error: "Email, password, and name are required" }, 400);
    }

    // Create Supabase admin client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log(`Signup error for ${email}: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ 
      success: true, 
      message: "User created successfully",
      user: { id: data.user.id, email: data.user.email }
    });

  } catch (error) {
    console.log(`Signup error: ${error}`);
    return c.json({ error: "Internal server error during signup" }, 500);
  }
});

// ===== STRIPE PAYMENT ENDPOINTS =====

// Create payment intent for one-time payments (Core Report: $299, Pro Report: $699)
app.post("/make-server-e90433f1/payments/create-intent", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { amount, currency = 'usd', productType } = await c.req.json();

    if (!amount || !productType) {
      return c.json({ error: "Amount and product type are required" }, 400);
    }

    // Validate product types and amounts
    const validProducts = {
      'core-report': 29900, // $299.00 in cents
      'pro-report': 69900,  // $699.00 in cents
    };

    if (!validProducts[productType] || validProducts[productType] !== amount) {
      return c.json({ error: "Invalid product type or amount" }, 400);
    }

    const customerId = await getOrCreateStripeCustomer(user);

    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency,
      customer: customerId,
      metadata: {
        supabase_user_id: user.id,
        product_type: productType,
      },
      automatic_payment_methods: {
        enabled: true,
      },
    });

    // Store payment intent for tracking
    await kv.set(`payment_intent:${paymentIntent.id}`, {
      paymentIntentId: paymentIntent.id,
      userId: user.id,
      amount,
      productType,
      status: 'created',
      createdAt: new Date().toISOString(),
    });

    return c.json({
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
    });

  } catch (error) {
    console.error('Error creating payment intent:', error);
    return c.json({ error: "Failed to create payment intent" }, 500);
  }
});

// Create subscription for Portfolio tier ($999-$1,499/mo)
app.post("/make-server-e90433f1/payments/create-subscription", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { priceId, paymentMethodId } = await c.req.json();

    if (!priceId || !paymentMethodId) {
      return c.json({ error: "Price ID and payment method are required" }, 400);
    }

    const customerId = await getOrCreateStripeCustomer(user);

    // Attach payment method to customer
    await stripe.paymentMethods.attach(paymentMethodId, {
      customer: customerId,
    });

    // Set as default payment method
    await stripe.customers.update(customerId, {
      invoice_settings: {
        default_payment_method: paymentMethodId,
      },
    });

    // Create subscription
    const subscription = await stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: priceId }],
      payment_behavior: 'default_incomplete',
      payment_settings: { save_default_payment_method: 'on_subscription' },
      expand: ['latest_invoice.payment_intent'],
      metadata: {
        supabase_user_id: user.id,
      },
    });

    // Store subscription for tracking
    await kv.set(`subscription:${subscription.id}`, {
      subscriptionId: subscription.id,
      userId: user.id,
      priceId,
      status: subscription.status,
      createdAt: new Date().toISOString(),
    });

    await kv.set(`user_subscription:${user.id}`, {
      subscriptionId: subscription.id,
      status: subscription.status,
      updatedAt: new Date().toISOString(),
    });

    return c.json({
      subscriptionId: subscription.id,
      clientSecret: subscription.latest_invoice.payment_intent.client_secret,
    });

  } catch (error) {
    console.error('Error creating subscription:', error);
    return c.json({ error: "Failed to create subscription" }, 500);
  }
});

// Get customer's payment methods
app.get("/make-server-e90433f1/payments/payment-methods", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const customerId = await getOrCreateStripeCustomer(user);

    const paymentMethods = await stripe.paymentMethods.list({
      customer: customerId,
      type: 'card',
    });

    return c.json({ paymentMethods: paymentMethods.data });

  } catch (error) {
    console.error('Error fetching payment methods:', error);
    return c.json({ error: "Failed to fetch payment methods" }, 500);
  }
});

// Get customer's subscriptions
app.get("/make-server-e90433f1/payments/subscriptions", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const customerId = await getOrCreateStripeCustomer(user);

    const subscriptions = await stripe.subscriptions.list({
      customer: customerId,
      status: 'all',
      expand: ['data.default_payment_method'],
    });

    return c.json({ subscriptions: subscriptions.data });

  } catch (error) {
    console.error('Error fetching subscriptions:', error);
    return c.json({ error: "Failed to fetch subscriptions" }, 500);
  }
});

// Cancel subscription
app.post("/make-server-e90433f1/payments/cancel-subscription", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { subscriptionId } = await c.req.json();

    if (!subscriptionId) {
      return c.json({ error: "Subscription ID is required" }, 400);
    }

    // Verify user owns this subscription
    const subscription = await kv.get(`subscription:${subscriptionId}`);
    if (!subscription || subscription.userId !== user.id) {
      return c.json({ error: "Subscription not found or unauthorized" }, 404);
    }

    const canceledSubscription = await stripe.subscriptions.cancel(subscriptionId);

    // Update our records
    await kv.set(`subscription:${subscriptionId}`, {
      ...subscription,
      status: 'canceled',
      canceledAt: new Date().toISOString(),
    });

    await kv.set(`user_subscription:${user.id}`, {
      subscriptionId,
      status: 'canceled',
      updatedAt: new Date().toISOString(),
    });

    return c.json({ 
      success: true, 
      subscription: canceledSubscription 
    });

  } catch (error) {
    console.error('Error canceling subscription:', error);
    return c.json({ error: "Failed to cancel subscription" }, 500);
  }
});

// Create customer portal session
app.post("/make-server-e90433f1/payments/create-portal-session", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { returnUrl } = await c.req.json();

    const customerId = await getOrCreateStripeCustomer(user);

    const portalSession = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: returnUrl || `${Deno.env.get('SUPABASE_URL')}/dashboard`,
    });

    return c.json({ url: portalSession.url });

  } catch (error) {
    console.error('Error creating portal session:', error);
    return c.json({ error: "Failed to create portal session" }, 500);
  }
});

// Webhook endpoint for Stripe events
app.post("/make-server-e90433f1/webhooks/stripe", async (c) => {
  try {
    const body = await c.req.text();
    const signature = c.req.header('stripe-signature');

    if (!signature) {
      return c.json({ error: "Missing stripe signature" }, 400);
    }

    // You'll need to set this in your Stripe webhook settings
    const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');
    if (!webhookSecret) {
      console.error('STRIPE_WEBHOOK_SECRET not configured');
      return c.json({ error: "Webhook secret not configured" }, 500);
    }

    const event = stripe.webhooks.constructEvent(body, signature, webhookSecret);

    console.log(`Received Stripe webhook: ${event.type}`);

    switch (event.type) {
      case 'payment_intent.succeeded':
        {
          const paymentIntent = event.data.object;
          const userId = paymentIntent.metadata.supabase_user_id;
          const productType = paymentIntent.metadata.product_type;

          // Update payment intent status
          await kv.set(`payment_intent:${paymentIntent.id}`, {
            paymentIntentId: paymentIntent.id,
            userId,
            amount: paymentIntent.amount,
            productType,
            status: 'succeeded',
            completedAt: new Date().toISOString(),
          });

          // Grant access to the purchased report
          await kv.set(`user_purchase:${userId}:${productType}`, {
            productType,
            purchasedAt: new Date().toISOString(),
            paymentIntentId: paymentIntent.id,
            amount: paymentIntent.amount,
          });

          console.log(`Payment succeeded for user ${userId}, product ${productType}`);
        }
        break;

      case 'customer.subscription.created':
      case 'customer.subscription.updated':
        {
          const subscription = event.data.object;
          const userId = subscription.metadata.supabase_user_id;

          if (userId) {
            await kv.set(`subscription:${subscription.id}`, {
              subscriptionId: subscription.id,
              userId,
              priceId: subscription.items.data[0].price.id,
              status: subscription.status,
              updatedAt: new Date().toISOString(),
            });

            await kv.set(`user_subscription:${userId}`, {
              subscriptionId: subscription.id,
              status: subscription.status,
              updatedAt: new Date().toISOString(),
            });

            console.log(`Subscription ${event.type} for user ${userId}`);
          }
        }
        break;

      case 'customer.subscription.deleted':
        {
          const subscription = event.data.object;
          const userId = subscription.metadata.supabase_user_id;

          if (userId) {
            await kv.set(`subscription:${subscription.id}`, {
              subscriptionId: subscription.id,
              userId,
              status: 'canceled',
              canceledAt: new Date().toISOString(),
            });

            await kv.set(`user_subscription:${userId}`, {
              subscriptionId: subscription.id,
              status: 'canceled',
              updatedAt: new Date().toISOString(),
            });

            console.log(`Subscription canceled for user ${userId}`);
          }
        }
        break;

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return c.json({ received: true });

  } catch (error) {
    console.error('Webhook error:', error);
    return c.json({ error: "Webhook processing failed" }, 400);
  }
});

// Get user's purchase history and subscription status
app.get("/make-server-e90433f1/payments/status", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Get subscription status
    const subscription = await kv.get(`user_subscription:${user.id}`);
    
    // Get purchases
    const purchases = await kv.getByPrefix(`user_purchase:${user.id}:`);
    
    return c.json({
      subscription: subscription || null,
      purchases: purchases.map(p => p.value) || [],
      hasActiveSubscription: subscription?.status === 'active',
      hasCoreReport: purchases.some(p => p.value.productType === 'core-report'),
      hasProReport: purchases.some(p => p.value.productType === 'pro-report'),
    });

  } catch (error) {
    console.error('Error fetching payment status:', error);
    return c.json({ error: "Failed to fetch payment status" }, 500);
  }
});

// Project Management Endpoints
app.post("/make-server-e90433f1/projects", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { name, description, type, codebase } = await c.req.json();

    if (!name || !type) {
      return c.json({ error: "Name and type are required" }, 400);
    }

    const projectId = crypto.randomUUID();
    const project = {
      id: projectId,
      name,
      description,
      type,
      userId: user.id,
      status: 'initializing',
      createdAt: new Date().toISOString(),
      codebase: codebase || null
    };

    await kv.set(`project:${projectId}`, project);
    await kv.set(`user_project:${user.id}:${projectId}`, { projectId, createdAt: project.createdAt });

    return c.json({ success: true, project });
  } catch (error) {
    console.log(`Error creating project: ${error}`);
    return c.json({ error: "Failed to create project" }, 500);
  }
});

app.get("/make-server-e90433f1/projects", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const userProjects = await kv.getByPrefix(`user_project:${user.id}:`);
    const projectIds = userProjects.map(item => item.value.projectId);
    
    const projects = [];
    for (const projectId of projectIds) {
      const project = await kv.get(`project:${projectId}`);
      if (project) {
        projects.push(project);
      }
    }

    return c.json({ projects: projects.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()) });
  } catch (error) {
    console.log(`Error fetching projects: ${error}`);
    return c.json({ error: "Failed to fetch projects" }, 500);
  }
});

// Codebase Intelligence Analysis
app.post("/make-server-e90433f1/analyze/codebase", async (c) => {
  try {
    const requestId = c.get('requestId');
    console.log(`[${requestId}] Starting codebase analysis`);
    
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { projectId, codebase } = await c.req.json();

    if (!projectId || !codebase) {
      return c.json({ error: "Project ID and codebase are required" }, 400);
    }

    const project = await kv.get(`project:${projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: "Project not found or unauthorized" }, 404);
    }

    // Check cache first
    const cacheKey = generateCacheKey('codebase', codebase);
    const cachedResult = await getCachedAnalysis(cacheKey);
    
    if (cachedResult) {
      console.log(`[${requestId}] Returning cached analysis`);
      await kv.set(`project:${projectId}`, { ...project, status: 'completed', lastAnalysis: new Date().toISOString() });
      return c.json({ analysis: cachedResult });
    }

    // Update project status
    await kv.set(`project:${projectId}`, { ...project, status: 'analyzing' });

    const prompt = `Analyze this codebase and provide a comprehensive technical assessment. 

Codebase: ${codebase}

Please provide a detailed analysis in JSON format with the following structure:
{
  "overview": {
    "language": "primary language",
    "framework": "main framework",
    "architecture": "architecture pattern",
    "linesOfCode": number,
    "complexity": number (1-10 scale)
  },
  "components": [
    {
      "name": "component name",
      "type": "component type",
      "complexity": number,
      "maintainability": number,
      "testCoverage": number,
      "issues": ["list of issues"]
    }
  ],
  "dependencies": [
    {
      "name": "dependency name",
      "version": "version",
      "riskLevel": "low|medium|high|critical",
      "description": "description"
    }
  ],
  "qualityMetrics": {
    "maintainabilityIndex": number,
    "cyclomaticComplexity": number,
    "duplicatedCode": number,
    "technicalDebt": number
  },
  "recommendations": ["list of recommendations"],
  "score": number (1-10)
}`;

    const analysis = await callOpenAI([
      { role: "system", content: "You are an expert software architect and code reviewer. Provide thorough, accurate technical analysis." },
      { role: "user", content: prompt }
    ]);

    const parsedAnalysis = JSON.parse(analysis);
    const analysisId = crypto.randomUUID();

    const analysisData = {
      id: analysisId,
      projectId,
      type: 'codebase',
      analysis: parsedAnalysis,
      createdAt: new Date().toISOString(),
      status: 'completed'
    };

    await kv.set(`analysis:${analysisId}`, analysisData);
    await kv.set(`project_analysis:${projectId}:codebase`, analysisId);
    
    // Cache the analysis result for future requests
    await setCachedAnalysis(cacheKey, parsedAnalysis);

    // Update project status
    await kv.set(`project:${projectId}`, { ...project, status: 'analysis_complete', lastAnalysis: new Date().toISOString() });

    console.log(`[${requestId}] Analysis completed and cached`);
    return c.json({ success: true, analysis: parsedAnalysis, analysisId });
  } catch (error) {
    console.log(`Error in codebase analysis: ${error}`);
    return c.json({ error: "Failed to analyze codebase" }, 500);
  }
});

// Architecture Mapping Analysis
app.post("/make-server-e90433f1/analyze/architecture", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { projectId, codebase } = await c.req.json();

    if (!projectId) {
      return c.json({ error: "Project ID is required" }, 400);
    }

    const project = await kv.get(`project:${projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: "Project not found or unauthorized" }, 404);
    }

    const codebaseToAnalyze = codebase || project.codebase;

    const prompt = `Analyze the architecture of this codebase and provide a comprehensive architectural assessment.

Codebase: ${codebaseToAnalyze}

Please provide analysis in JSON format:
{
  "architecturePattern": "pattern name",
  "layers": [
    {
      "name": "layer name",
      "components": number,
      "complexity": number,
      "dependencies": number,
      "responsibilities": ["list of responsibilities"]
    }
  ],
  "components": [
    {
      "name": "component name",
      "layer": "layer name",
      "type": "component type",
      "connections": ["connected components"],
      "responsibilities": ["responsibilities"]
    }
  ],
  "dataFlow": [
    {
      "from": "source component",
      "to": "target component",
      "type": "data type",
      "description": "flow description"
    }
  ],
  "patterns": ["identified patterns"],
  "antiPatterns": ["identified anti-patterns"],
  "recommendations": ["architectural recommendations"],
  "scalabilityAssessment": {
    "currentCapacity": "assessment",
    "bottlenecks": ["potential bottlenecks"],
    "recommendations": ["scalability recommendations"]
  },
  "score": number (1-10)
}`;

    const analysis = await callOpenAI([
      { role: "system", content: "You are an expert software architect. Provide thorough architectural analysis focusing on patterns, data flow, and scalability." },
      { role: "user", content: prompt }
    ]);

    const parsedAnalysis = JSON.parse(analysis);
    const analysisId = crypto.randomUUID();

    const analysisData = {
      id: analysisId,
      projectId,
      type: 'architecture',
      analysis: parsedAnalysis,
      createdAt: new Date().toISOString(),
      status: 'completed'
    };

    await kv.set(`analysis:${analysisId}`, analysisData);
    await kv.set(`project_analysis:${projectId}:architecture`, analysisId);

    return c.json({ success: true, analysis: parsedAnalysis, analysisId });
  } catch (error) {
    console.log(`Error in architecture analysis: ${error}`);
    return c.json({ error: "Failed to analyze architecture" }, 500);
  }
});

// Security Assessment
app.post("/make-server-e90433f1/analyze/security", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { projectId, codebase } = await c.req.json();

    if (!projectId) {
      return c.json({ error: "Project ID is required" }, 400);
    }

    const project = await kv.get(`project:${projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: "Project not found or unauthorized" }, 404);
    }

    const codebaseToAnalyze = codebase || project.codebase;

    const prompt = `Perform a comprehensive security assessment of this codebase.

Codebase: ${codebaseToAnalyze}

Provide analysis in JSON format:
{
  "securityScore": number (1-10),
  "vulnerabilities": [
    {
      "type": "vulnerability type",
      "severity": "low|medium|high|critical",
      "location": "code location",
      "description": "detailed description",
      "recommendation": "how to fix",
      "cwe": "CWE number if applicable"
    }
  ],
  "securityPractices": {
    "authentication": {
      "score": number,
      "issues": ["issues found"],
      "recommendations": ["recommendations"]
    },
    "authorization": {
      "score": number,
      "issues": ["issues found"],
      "recommendations": ["recommendations"]
    },
    "dataProtection": {
      "score": number,
      "issues": ["issues found"],
      "recommendations": ["recommendations"]
    },
    "inputValidation": {
      "score": number,
      "issues": ["issues found"],
      "recommendations": ["recommendations"]
    }
  },
  "complianceAssessment": {
    "gdpr": "compliant|partial|non-compliant",
    "pci": "compliant|partial|non-compliant",
    "hipaa": "compliant|partial|non-compliant",
    "notes": ["compliance notes"]
  },
  "recommendations": ["priority security recommendations"],
  "criticalIssues": number,
  "riskAssessment": "low|medium|high|critical"
}`;

    const analysis = await callOpenAI([
      { role: "system", content: "You are a cybersecurity expert specializing in code security assessment. Focus on identifying vulnerabilities, security best practices, and compliance issues." },
      { role: "user", content: prompt }
    ]);

    const parsedAnalysis = JSON.parse(analysis);
    const analysisId = crypto.randomUUID();

    const analysisData = {
      id: analysisId,
      projectId,
      type: 'security',
      analysis: parsedAnalysis,
      createdAt: new Date().toISOString(),
      status: 'completed'
    };

    await kv.set(`analysis:${analysisId}`, analysisData);
    await kv.set(`project_analysis:${projectId}:security`, analysisId);

    return c.json({ success: true, analysis: parsedAnalysis, analysisId });
  } catch (error) {
    console.log(`Error in security analysis: ${error}`);
    return c.json({ error: "Failed to analyze security" }, 500);
  }
});

// Performance Intelligence
app.post("/make-server-e90433f1/analyze/performance", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { projectId, codebase } = await c.req.json();

    if (!projectId) {
      return c.json({ error: "Project ID is required" }, 400);
    }

    const project = await kv.get(`project:${projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: "Project not found or unauthorized" }, 404);
    }

    const codebaseToAnalyze = codebase || project.codebase;

    const prompt = `Analyze the performance characteristics of this codebase.

Codebase: ${codebaseToAnalyze}

Provide analysis in JSON format:
{
  "performanceScore": number (1-10),
  "bottlenecks": [
    {
      "component": "component name",
      "type": "bottleneck type",
      "severity": "low|medium|high|critical",
      "description": "detailed description",
      "impact": "performance impact",
      "recommendation": "optimization recommendation"
    }
  ],
  "metrics": {
    "estimatedLoadTime": number,
    "memoryUsage": "estimated usage",
    "databaseQueries": {
      "total": number,
      "inefficient": number,
      "nPlusOne": number
    },
    "apiCalls": {
      "total": number,
      "inefficient": number,
      "external": number
    }
  },
  "optimizations": [
    {
      "area": "optimization area",
      "priority": "low|medium|high",
      "description": "optimization description",
      "expectedImprovement": "expected improvement",
      "effort": "implementation effort"
    }
  ],
  "scalabilityAnalysis": {
    "currentCapacity": "estimated capacity",
    "scalingBottlenecks": ["bottlenecks"],
    "recommendations": ["scaling recommendations"]
  },
  "cacheability": {
    "score": number,
    "opportunities": ["caching opportunities"],
    "recommendations": ["caching recommendations"]
  }
}`;

    const analysis = await callOpenAI([
      { role: "system", content: "You are a performance optimization expert. Focus on identifying bottlenecks, scalability issues, and optimization opportunities." },
      { role: "user", content: prompt }
    ]);

    const parsedAnalysis = JSON.parse(analysis);
    const analysisId = crypto.randomUUID();

    const analysisData = {
      id: analysisId,
      projectId,
      type: 'performance',
      analysis: parsedAnalysis,
      createdAt: new Date().toISOString(),
      status: 'completed'
    };

    await kv.set(`analysis:${analysisId}`, analysisData);
    await kv.set(`project_analysis:${projectId}:performance`, analysisId);

    return c.json({ success: true, analysis: parsedAnalysis, analysisId });
  } catch (error) {
    console.log(`Error in performance analysis: ${error}`);
    return c.json({ error: "Failed to analyze performance" }, 500);
  }
});

// Technical Debt Analysis
app.post("/make-server-e90433f1/analyze/technical-debt", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { projectId, codebase } = await c.req.json();

    if (!projectId) {
      return c.json({ error: "Project ID is required" }, 400);
    }

    const project = await kv.get(`project:${projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: "Project not found or unauthorized" }, 404);
    }

    const codebaseToAnalyze = codebase || project.codebase;

    const prompt = `Analyze the technical debt in this codebase and provide a comprehensive assessment.

Codebase: ${codebaseToAnalyze}

Provide analysis in JSON format:
{
  "debtScore": number (1-10, where 10 is highest debt),
  "totalDebtCost": number (estimated cost in USD),
  "debtCategories": [
    {
      "category": "debt category",
      "severity": "low|medium|high|critical",
      "cost": number,
      "timeToFix": "estimated time",
      "issues": ["specific issues"],
      "impact": "business impact"
    }
  ],
  "codeSmells": [
    {
      "type": "smell type",
      "location": "code location",
      "severity": "low|medium|high",
      "description": "description",
      "refactoringEffort": "effort level"
    }
  ],
  "maintainabilityIssues": [
    {
      "component": "component name",
      "complexity": number,
      "maintainabilityIndex": number,
      "issues": ["maintainability issues"],
      "recommendations": ["recommendations"]
    }
  ],
  "testCoverage": {
    "overall": number,
    "byComponent": [
      {
        "component": "component name",
        "coverage": number,
        "missingTests": ["missing test areas"]
      }
    ]
  },
  "prioritizedRemediationPlan": [
    {
      "priority": number,
      "item": "remediation item",
      "cost": number,
      "benefit": "expected benefit",
      "timeframe": "recommended timeframe"
    }
  ],
  "riskAssessment": "low|medium|high|critical"
}`;

    const analysis = await callOpenAI([
      { role: "system", content: "You are a technical debt specialist and software engineering consultant. Focus on identifying debt, quantifying costs, and providing remediation strategies." },
      { role: "user", content: prompt }
    ]);

    const parsedAnalysis = JSON.parse(analysis);
    const analysisId = crypto.randomUUID();

    const analysisData = {
      id: analysisId,
      projectId,
      type: 'technical-debt',
      analysis: parsedAnalysis,
      createdAt: new Date().toISOString(),
      status: 'completed'
    };

    await kv.set(`analysis:${analysisId}`, analysisData);
    await kv.set(`project_analysis:${projectId}:technical-debt`, analysisId);

    return c.json({ success: true, analysis: parsedAnalysis, analysisId });
  } catch (error) {
    console.log(`Error in technical debt analysis: ${error}`);
    return c.json({ error: "Failed to analyze technical debt" }, 500);
  }
});

// Get Analysis Results
app.get("/make-server-e90433f1/analysis/:analysisId", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const analysisId = c.req.param('analysisId');
    const analysis = await kv.get(`analysis:${analysisId}`);

    if (!analysis) {
      return c.json({ error: "Analysis not found" }, 404);
    }

    // Verify user owns the project
    const project = await kv.get(`project:${analysis.projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    return c.json({ analysis });
  } catch (error) {
    console.log(`Error fetching analysis: ${error}`);
    return c.json({ error: "Failed to fetch analysis" }, 500);
  }
});

// Comprehensive Analysis (runs all analysis types)
app.post("/make-server-e90433f1/analyze/comprehensive", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { projectId, codebase } = await c.req.json();

    if (!projectId || !codebase) {
      return c.json({ error: "Project ID and codebase are required" }, 400);
    }

    const project = await kv.get(`project:${projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: "Project not found or unauthorized" }, 404);
    }

    // Update project status
    await kv.set(`project:${projectId}`, { ...project, status: 'comprehensive_analysis', codebase });

    // This would typically be done in parallel, but for simplicity we'll do sequential
    const analysisTypes = ['codebase', 'architecture', 'security', 'performance', 'technical-debt'];
    const results = {};

    for (const type of analysisTypes) {
      try {
        // Create specific prompts for comprehensive analysis
        let prompt = '';
        let systemMessage = '';

        switch (type) {
          case 'codebase':
            systemMessage = "You are an expert software architect and code reviewer. Provide thorough, accurate technical analysis.";
            prompt = `Analyze this codebase and provide a comprehensive technical assessment in JSON format with overview, components, dependencies, qualityMetrics, recommendations, and score (1-10).`;
            break;
          case 'architecture':
            systemMessage = "You are an expert software architect. Provide thorough architectural analysis focusing on patterns, data flow, and scalability.";
            prompt = `Analyze the architecture of this codebase in JSON format with architecturePattern, layers, components, dataFlow, patterns, antiPatterns, recommendations, scalabilityAssessment, and score.`;
            break;
          case 'security':
            systemMessage = "You are a cybersecurity expert specializing in code security assessment.";
            prompt = `Perform comprehensive security assessment in JSON format with securityScore, vulnerabilities, securityPractices, complianceAssessment, recommendations, criticalIssues, and riskAssessment.`;
            break;
          case 'performance':
            systemMessage = "You are a performance optimization expert.";
            prompt = `Analyze performance characteristics in JSON format with performanceScore, bottlenecks, metrics, optimizations, scalabilityAnalysis, and cacheability.`;
            break;
          case 'technical-debt':
            systemMessage = "You are a technical debt specialist and software engineering consultant.";
            prompt = `Analyze technical debt in JSON format with debtScore, totalDebtCost, debtCategories, codeSmells, maintainabilityIssues, testCoverage, prioritizedRemediationPlan, and riskAssessment.`;
            break;
        }

        const fullPrompt = `${prompt}\n\nCodebase: ${codebase}`;
        const analysis = await callOpenAI([
          { role: "system", content: systemMessage },
          { role: "user", content: fullPrompt }
        ]);

        results[type] = JSON.parse(analysis);
      } catch (error) {
        console.log(`Error in ${type} analysis: ${error}`);
        results[type] = { error: `Failed to analyze ${type}` };
      }
    }

    const comprehensiveAnalysisId = crypto.randomUUID();
    const comprehensiveData = {
      id: comprehensiveAnalysisId,
      projectId,
      type: 'comprehensive',
      analysis: results,
      createdAt: new Date().toISOString(),
      status: 'completed'
    };

    await kv.set(`analysis:${comprehensiveAnalysisId}`, comprehensiveData);
    await kv.set(`project_analysis:${projectId}:comprehensive`, comprehensiveAnalysisId);

    // Update project status
    await kv.set(`project:${projectId}`, { 
      ...project, 
      status: 'completed', 
      lastAnalysis: new Date().toISOString(),
      comprehensiveAnalysisId 
    });

    return c.json({ success: true, analysis: results, analysisId: comprehensiveAnalysisId });
  } catch (error) {
    console.log(`Error in comprehensive analysis: ${error}`);
    return c.json({ error: "Failed to perform comprehensive analysis" }, 500);
  }
});

// Data Flow Analysis
app.post("/make-server-e90433f1/analyze/data-flow", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { projectId, codebase } = await c.req.json();

    if (!projectId) {
      return c.json({ error: "Project ID is required" }, 400);
    }

    const project = await kv.get(`project:${projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: "Project not found or unauthorized" }, 404);
    }

    const codebaseToAnalyze = codebase || project.codebase;

    const prompt = `Analyze the data flow patterns in this codebase and provide a comprehensive data flow assessment.

Codebase: ${codebaseToAnalyze}

Provide analysis in JSON format:
{
  "dataFlowScore": number (1-10),
  "dataEntities": [
    {
      "name": "entity name",
      "type": "data type",
      "sources": ["data sources"],
      "destinations": ["data destinations"],
      "transformations": ["transformations applied"],
      "sensitivityLevel": "low|medium|high|critical"
    }
  ],
  "dataFlows": [
    {
      "id": "flow identifier",
      "source": "source component",
      "destination": "destination component",
      "dataType": "type of data",
      "frequency": "flow frequency",
      "volume": "estimated volume",
      "latency": "expected latency",
      "securityRequirements": ["security requirements"],
      "complianceRequirements": ["compliance requirements"]
    }
  ],
  "storageAnalysis": {
    "databases": [
      {
        "name": "database name",
        "type": "database type",
        "entities": ["stored entities"],
        "accessPatterns": ["access patterns"],
        "performance": "performance assessment"
      }
    ],
    "caches": ["cache layers identified"],
    "externalSystems": ["external data sources"]
  },
  "privacyAssessment": {
    "piiHandling": "assessment of PII handling",
    "dataRetention": "data retention policies",
    "consentManagement": "consent management approach",
    "rightToErasure": "right to erasure support"
  },
  "recommendations": ["data flow recommendations"],
  "riskAreas": ["identified risk areas"]
}`;

    const analysis = await callOpenAI([
      { role: "system", content: "You are a data architecture expert specializing in data flow analysis, privacy, and compliance. Focus on data movement, storage patterns, and privacy implications." },
      { role: "user", content: prompt }
    ]);

    const parsedAnalysis = JSON.parse(analysis);
    const analysisId = crypto.randomUUID();

    const analysisData = {
      id: analysisId,
      projectId,
      type: 'data-flow',
      analysis: parsedAnalysis,
      createdAt: new Date().toISOString(),
      status: 'completed'
    };

    await kv.set(`analysis:${analysisId}`, analysisData);
    await kv.set(`project_analysis:${projectId}:data-flow`, analysisId);

    return c.json({ success: true, analysis: parsedAnalysis, analysisId });
  } catch (error) {
    console.log(`Error in data flow analysis: ${error}`);
    return c.json({ error: "Failed to analyze data flow" }, 500);
  }
});

// Dependency Mapping Analysis
app.post("/make-server-e90433f1/analyze/dependencies", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { projectId, codebase } = await c.req.json();

    if (!projectId) {
      return c.json({ error: "Project ID is required" }, 400);
    }

    const project = await kv.get(`project:${projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: "Project not found or unauthorized" }, 404);
    }

    const codebaseToAnalyze = codebase || project.codebase;

    const prompt = `Analyze all dependencies in this codebase and create a comprehensive dependency map.

Codebase: ${codebaseToAnalyze}

Provide analysis in JSON format:
{
  "dependencyScore": number (1-10),
  "totalDependencies": number,
  "directDependencies": [
    {
      "name": "dependency name",
      "version": "version",
      "type": "npm|pip|maven|nuget|etc",
      "license": "license type",
      "maintainedBy": "maintainer info",
      "lastUpdate": "last update date",
      "riskLevel": "low|medium|high|critical",
      "securityVulnerabilities": number,
      "usageAnalysis": "how it's used in codebase"
    }
  ],
  "transitiveDependencies": [
    {
      "name": "dependency name",
      "introducedBy": "parent dependency",
      "depth": number,
      "riskLevel": "low|medium|high|critical"
    }
  ],
  "dependencyTree": {
    "depth": number,
    "complexity": "simple|moderate|complex|very complex",
    "circularDependencies": ["circular dependencies found"],
    "criticalPath": ["dependencies on critical path"]
  },
  "licenseAnalysis": {
    "compatibilityIssues": ["license compatibility issues"],
    "restrictiveLicenses": ["restrictive licenses found"],
    "recommendations": ["license recommendations"]
  },
  "securityAnalysis": {
    "vulnerableDependencies": number,
    "highRiskDependencies": ["high risk dependencies"],
    "outdatedDependencies": number,
    "recommendedUpdates": ["update recommendations"]
  },
  "maintenanceRisk": {
    "abandonedDependencies": ["potentially abandoned dependencies"],
    "singleMaintainerRisk": ["dependencies with single maintainer"],
    "largeVendorDependencies": ["dependencies from large vendors"]
  },
  "recommendations": ["dependency management recommendations"],
  "actionItems": [
    {
      "priority": "low|medium|high|critical",
      "action": "recommended action",
      "dependency": "affected dependency",
      "impact": "expected impact"
    }
  ]
}`;

    const analysis = await callOpenAI([
      { role: "system", content: "You are a software supply chain security expert. Focus on dependency analysis, vulnerability assessment, and supply chain risk management." },
      { role: "user", content: prompt }
    ]);

    const parsedAnalysis = JSON.parse(analysis);
    const analysisId = crypto.randomUUID();

    const analysisData = {
      id: analysisId,
      projectId,
      type: 'dependencies',
      analysis: parsedAnalysis,
      createdAt: new Date().toISOString(),
      status: 'completed'
    };

    await kv.set(`analysis:${analysisId}`, analysisData);
    await kv.set(`project_analysis:${projectId}:dependencies`, analysisId);

    return c.json({ success: true, analysis: parsedAnalysis, analysisId });
  } catch (error) {
    console.log(`Error in dependency analysis: ${error}`);
    return c.json({ error: "Failed to analyze dependencies" }, 500);
  }
});

// Business Logic Documentation Analysis
app.post("/make-server-e90433f1/analyze/business-logic", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { projectId, codebase } = await c.req.json();

    if (!projectId) {
      return c.json({ error: "Project ID is required" }, 400);
    }

    const project = await kv.get(`project:${projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: "Project not found or unauthorized" }, 404);
    }

    const codebaseToAnalyze = codebase || project.codebase;

    const prompt = `Analyze and document the business logic in this codebase.

Codebase: ${codebaseToAnalyze}

Provide analysis in JSON format:
{
  "businessLogicScore": number (1-10),
  "coreBusinessRules": [
    {
      "rule": "business rule description",
      "location": "code location",
      "complexity": "simple|moderate|complex",
      "dependencies": ["rule dependencies"],
      "impact": "business impact if rule fails",
      "testability": "easy|moderate|difficult"
    }
  ],
  "businessWorkflows": [
    {
      "name": "workflow name",
      "description": "workflow description", 
      "steps": ["workflow steps"],
      "participants": ["actors involved"],
      "dataRequired": ["required data"],
      "outputGenerated": ["generated outputs"],
      "exceptionHandling": ["exception scenarios"],
      "businessValue": "value to business"
    }
  ],
  "domainModel": {
    "entities": [
      {
        "name": "entity name",
        "description": "entity description",
        "attributes": ["key attributes"],
        "relationships": ["relationships to other entities"],
        "businessRules": ["rules governing this entity"]
      }
    ],
    "valueObjects": ["identified value objects"],
    "aggregates": ["identified aggregates"]
  },
  "businessLogicComplexity": {
    "distributionAcrossLayers": "how business logic is distributed",
    "separationOfConcerns": "assessment of separation",
    "businessLogicLeakage": ["areas where business logic leaks to other layers"]
  },
  "complianceRequirements": [
    {
      "requirement": "compliance requirement",
      "implementation": "how it's implemented",
      "gaps": ["compliance gaps identified"],
      "riskLevel": "low|medium|high|critical"
    }
  ],
  "documentationGaps": [
    {
      "area": "undocumented area",
      "importance": "business importance",
      "recommendation": "documentation recommendation"
    }
  ],
  "recommendations": ["business logic improvement recommendations"],
  "riskAssessment": "overall business logic risk assessment"
}`;

    const analysis = await callOpenAI([
      { role: "system", content: "You are a business analyst and domain expert specializing in understanding and documenting business logic in software systems." },
      { role: "user", content: prompt }
    ]);

    const parsedAnalysis = JSON.parse(analysis);
    const analysisId = crypto.randomUUID();

    const analysisData = {
      id: analysisId,
      projectId,
      type: 'business-logic',
      analysis: parsedAnalysis,
      createdAt: new Date().toISOString(),
      status: 'completed'
    };

    await kv.set(`analysis:${analysisId}`, analysisData);
    await kv.set(`project_analysis:${projectId}:business-logic`, analysisId);

    return c.json({ success: true, analysis: parsedAnalysis, analysisId });
  } catch (error) {
    console.log(`Error in business logic analysis: ${error}`);
    return c.json({ error: "Failed to analyze business logic" }, 500);
  }
});

// Team Knowledge Transfer Analysis
app.post("/make-server-e90433f1/analyze/knowledge-transfer", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { projectId, codebase } = await c.req.json();

    if (!projectId) {
      return c.json({ error: "Project ID is required" }, 400);
    }

    const project = await kv.get(`project:${projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: "Project not found or unauthorized" }, 404);
    }

    const codebaseToAnalyze = codebase || project.codebase;

    const prompt = `Analyze this codebase from a knowledge transfer perspective to assess onboarding complexity and knowledge risks.

Codebase: ${codebaseToAnalyze}

Provide analysis in JSON format:
{
  "knowledgeTransferScore": number (1-10),
  "complexityAssessment": {
    "overallComplexity": "simple|moderate|complex|very complex",
    "cognitiveLoad": "low|medium|high|overwhelming",
    "learningCurve": "steep|moderate|gentle",
    "prerequisiteKnowledge": ["required background knowledge"]
  },
  "documentationAnalysis": {
    "codeDocumentation": {
      "coverage": number (percentage),
      "quality": "poor|fair|good|excellent",
      "examples": ["areas with good documentation"],
      "gaps": ["documentation gaps"]
    },
    "architecturalDocumentation": {
      "exists": boolean,
      "quality": "poor|fair|good|excellent",
      "completeness": number (percentage)
    },
    "businessContextDocumentation": {
      "exists": boolean,
      "quality": "poor|fair|good|excellent",
      "businessRulesDocumented": number (percentage)
    }
  },
  "knowledgeAreas": [
    {
      "area": "knowledge area",
      "complexity": "simple|moderate|complex",
      "criticalityToSystem": "low|medium|high|critical",
      "documentationLevel": "none|minimal|adequate|comprehensive",
      "keyPersonDependency": "low|medium|high",
      "transferDifficulty": "easy|moderate|difficult|very difficult"
    }
  ],
  "onboardingReadiness": {
    "newDeveloperOnboarding": {
      "estimatedTime": "time estimate",
      "requiredSupport": "support level needed",
      "majorChallenges": ["onboarding challenges"]
    },
    "existingTeamKnowledgeGaps": ["knowledge gaps in current team"],
    "keyPersonRisks": ["risks from key person dependencies"]
  },
  "codebaseNavigation": {
    "entryPoints": ["main entry points for understanding"],
    "coreConcepts": ["core concepts to understand"],
    "architecturalPatterns": ["patterns that need to be understood"],
    "commonPitfalls": ["common mistakes newcomers make"]
  },
  "transferStrategies": [
    {
      "strategy": "knowledge transfer strategy",
      "effectiveness": "low|medium|high",
      "effort": "low|medium|high",
      "timeframe": "time required",
      "description": "strategy description"
    }
  ],
  "riskMitigation": [
    {
      "risk": "identified risk",
      "impact": "low|medium|high|critical",
      "mitigation": "mitigation strategy",
      "priority": number
    }
  ],
  "recommendations": ["knowledge transfer recommendations"]
}`;

    const analysis = await callOpenAI([
      { role: "system", content: "You are an expert in software team management and knowledge transfer, specializing in assessing codebase complexity from an onboarding and knowledge sharing perspective." },
      { role: "user", content: prompt }
    ]);

    const parsedAnalysis = JSON.parse(analysis);
    const analysisId = crypto.randomUUID();

    const analysisData = {
      id: analysisId,
      projectId,
      type: 'knowledge-transfer',
      analysis: parsedAnalysis,
      createdAt: new Date().toISOString(),
      status: 'completed'
    };

    await kv.set(`analysis:${analysisId}`, analysisData);
    await kv.set(`project_analysis:${projectId}:knowledge-transfer`, analysisId);

    return c.json({ success: true, analysis: parsedAnalysis, analysisId });
  } catch (error) {
    console.log(`Error in knowledge transfer analysis: ${error}`);
    return c.json({ error: "Failed to analyze knowledge transfer" }, 500);
  }
});

// Get Project Analyses
app.get("/make-server-e90433f1/projects/:projectId/analyses", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const projectId = c.req.param('projectId');
    const project = await kv.get(`project:${projectId}`);

    if (!project || project.userId !== user.id) {
      return c.json({ error: "Project not found or unauthorized" }, 404);
    }

    const analysisKeys = await kv.getByPrefix(`project_analysis:${projectId}:`);
    const analyses = [];

    for (const key of analysisKeys) {
      const analysis = await kv.get(`analysis:${key.value}`);
      if (analysis) {
        analyses.push(analysis);
      }
    }

    return c.json({ analyses: analyses.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()) });
  } catch (error) {
    console.log(`Error fetching project analyses: ${error}`);
    return c.json({ error: "Failed to fetch analyses" }, 500);
  }
});

// Report Generation
app.post("/make-server-e90433f1/reports/generate", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { projectId, format } = await c.req.json();

    if (!projectId || !format) {
      return c.json({ error: "Project ID and format are required" }, 400);
    }

    const project = await kv.get(`project:${projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: "Project not found or unauthorized" }, 404);
    }

    // Get all analyses for the project
    const analysisKeys = await kv.getByPrefix(`project_analysis:${projectId}:`);
    const analyses = [];

    for (const key of analysisKeys) {
      const analysis = await kv.get(`analysis:${key.value}`);
      if (analysis) {
        analyses.push(analysis);
      }
    }

    if (analyses.length === 0) {
      return c.json({ error: "No analyses found for this project" }, 400);
    }

    // Generate report content based on format
    const reportId = crypto.randomUUID();
    let reportContent;
    let mimeType;
    let fileName;

    if (format === 'json') {
      reportContent = JSON.stringify({
        project,
        analyses,
        generatedAt: new Date().toISOString(),
        reportId
      }, null, 2);
      mimeType = 'application/json';
      fileName = `systems-flow-report-${project.name}-${new Date().toISOString().split('T')[0]}.json`;
    } else if (format === 'csv') {
      // Create CSV summary
      const csvRows = [
        ['Analysis Type', 'Score', 'Status', 'Created At', 'Key Findings']
      ];
      
      analyses.forEach(analysis => {
        const score = analysis.analysis.score || analysis.analysis.securityScore || analysis.analysis.performanceScore || 'N/A';
        const keyFindings = JSON.stringify(analysis.analysis.recommendations || []).substring(0, 100);
        csvRows.push([
          analysis.type,
          score.toString(),
          analysis.status,
          analysis.createdAt,
          keyFindings
        ]);
      });

      reportContent = csvRows.map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
      mimeType = 'text/csv';
      fileName = `systems-flow-report-${project.name}-${new Date().toISOString().split('T')[0]}.csv`;
    } else {
      return c.json({ error: "Unsupported format. Use 'json' or 'csv'" }, 400);
    }

    // Store report data (in a real app, you'd upload to storage and return a signed URL)
    const reportData = {
      id: reportId,
      projectId,
      format,
      content: reportContent,
      mimeType,
      fileName,
      generatedAt: new Date().toISOString(),
      userId: user.id
    };

    await kv.set(`report:${reportId}`, reportData);

    // Return a mock URL (in a real app, this would be a signed URL to the stored file)
    const reportUrl = `/api/reports/${reportId}/download`;

    return c.json({ success: true, reportUrl, reportId });
  } catch (error) {
    console.log(`Error generating report: ${error}`);
    return c.json({ error: "Failed to generate report" }, 500);
  }
});

// Project Comparison
app.post("/make-server-e90433f1/analyze/compare", async (c) => {
  try {
    const user = await authenticateUser(c.req.header('Authorization'));
    if (!user) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { projectIds } = await c.req.json();

    if (!projectIds || !Array.isArray(projectIds) || projectIds.length < 2) {
      return c.json({ error: "At least 2 project IDs are required for comparison" }, 400);
    }

    const projects = [];
    const allAnalyses = [];

    // Verify user owns all projects and get their analyses
    for (const projectId of projectIds) {
      const project = await kv.get(`project:${projectId}`);
      if (!project || project.userId !== user.id) {
        return c.json({ error: `Project ${projectId} not found or unauthorized` }, 404);
      }
      projects.push(project);

      // Get analyses for this project
      const analysisKeys = await kv.getByPrefix(`project_analysis:${projectId}:`);
      const projectAnalyses = [];
      
      for (const key of analysisKeys) {
        const analysis = await kv.get(`analysis:${key.value}`);
        if (analysis) {
          projectAnalyses.push(analysis);
        }
      }
      allAnalyses.push({ projectId, analyses: projectAnalyses });
    }

    // Generate comparison analysis
    const comparison = {
      projects: projects.map(p => ({
        id: p.id,
        name: p.name,
        type: p.type,
        status: p.status
      })),
      scoreComparison: {},
      strengthsWeaknesses: {},
      riskComparison: {},
      recommendations: []
    };

    // Compare scores across analysis types
    const analysisTypes = ['codebase', 'architecture', 'security', 'performance', 'technical-debt'];
    
    for (const type of analysisTypes) {
      comparison.scoreComparison[type] = [];
      
      for (let i = 0; i < projects.length; i++) {
        const analysis = allAnalyses[i].analyses.find(a => a.type === type);
        const score = analysis?.analysis?.score || analysis?.analysis?.securityScore || analysis?.analysis?.performanceScore || 0;
        
        comparison.scoreComparison[type].push({
          projectId: projects[i].id,
          projectName: projects[i].name,
          score
        });
      }
    }

    return c.json({ success: true, comparison });
  } catch (error) {
    console.log(`Error in project comparison: ${error}`);
    return c.json({ error: "Failed to compare projects" }, 500);
  }
});

Deno.serve(app.fetch);